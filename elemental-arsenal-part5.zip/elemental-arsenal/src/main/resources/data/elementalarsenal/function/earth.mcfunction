give @s elementalarsenal:earth_sword
give @s elementalarsenal:earth_helmet
give @s elementalarsenal:earth_chestplate
give @s elementalarsenal:earth_leggings
give @s elementalarsenal:earth_boots
