give @s elementalarsenal:ice_sword
give @s elementalarsenal:ice_helmet
give @s elementalarsenal:ice_chestplate
give @s elementalarsenal:ice_leggings
give @s elementalarsenal:ice_boots
