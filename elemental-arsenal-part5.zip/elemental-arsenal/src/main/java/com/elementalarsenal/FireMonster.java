package com.elementalarsenal;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathType;

/**
 * The Inferno Colossus: a Nether fire boss with a unique boss bar and three particle special attacks
 * (see {@link FireMonsterAttackGoal}).
 */
public class FireMonster extends Monster {
	/** Melee damage: 14 hearts = 28 health points. Change this one number to tune it. */
	public static final double MELEE_DAMAGE = 28.0D;
	/** Max health: 300 hearts = 600 health points. */
	public static final double MAX_HEALTH = 600.0D;

	public static final int STATE_IDLE = 0;
	public static final int STATE_NOVA = 1;
	public static final int STATE_LANCE = 2;
	public static final int STATE_ERUPTION = 3;

	private static final EntityDataAccessor<Integer> DATA_ATTACK_STATE =
			SynchedEntityData.defineId(FireMonster.class, EntityDataSerializers.INT);

	/**
	 * Unique boss bar: the YELLOW bar is not used by any vanilla boss, and this mod replaces its sprites
	 * (assets/minecraft/textures/gui/sprites/boss_bar/yellow_*.png) with a molten-lava bar.
	 */
	private final ServerBossEvent bossEvent = new ServerBossEvent(
			Component.translatable("entity.elementalarsenal.fire_monster")
					.withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
			BossEvent.BossBarColor.YELLOW,
			BossEvent.BossBarOverlay.PROGRESS);

	/** Ticks until the next special attack may start. */
	private int specialCooldown = 60;

	public FireMonster(EntityType<? extends FireMonster> type, Level level) {
		super(type, level);
		this.bossEvent.setDarkenScreen(false);
		this.setPathfindingMalus(PathType.LAVA, 8.0F);
		this.setPathfindingMalus(PathType.DANGER_FIRE, 0.0F);
		this.setPathfindingMalus(PathType.DAMAGE_FIRE, 0.0F);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, MAX_HEALTH)
				.add(Attributes.ATTACK_DAMAGE, MELEE_DAMAGE)
				.add(Attributes.MOVEMENT_SPEED, 0.3D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
				.add(Attributes.FOLLOW_RANGE, 48.0D)
				.add(Attributes.ARMOR, 10.0D)
				.add(Attributes.STEP_HEIGHT, 1.0D);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_ATTACK_STATE, STATE_IDLE);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new FireMonsterAttackGoal(this));
		this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	public int getAttackState() {
		return this.entityData.get(DATA_ATTACK_STATE);
	}

	public void setAttackState(int state) {
		this.entityData.set(DATA_ATTACK_STATE, state);
	}

	public boolean isSpecialReady() {
		return this.specialCooldown <= 0;
	}

	public void setSpecialCooldown(int ticks) {
		this.specialCooldown = ticks;
	}

	// ------------------------------------------------------------------ boss bar

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		this.bossEvent.addPlayer(player);
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		this.bossEvent.removePlayer(player);
	}

	@Override
	protected void customServerAiStep(ServerLevel level) {
		super.customServerAiStep(level);
		this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
		if (this.specialCooldown > 0) {
			this.specialCooldown--;
		}
		// Fiery aura
		if (this.tickCount % 3 == 0) {
			level.sendParticles(ParticleTypes.FLAME,
					this.getX(), this.getY() + 1.8D, this.getZ(), 3, 0.9D, 1.4D, 0.9D, 0.01D);
		}
		if (this.tickCount % 12 == 0) {
			level.sendParticles(ParticleTypes.LAVA,
					this.getX(), this.getY() + 3.0D, this.getZ(), 1, 0.6D, 0.2D, 0.6D, 0.0D);
		}
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	// ------------------------------------------------------------------ sounds

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.BLAZE_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.BLAZE_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.BLAZE_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.IRON_GOLEM_STEP, 1.0F, 0.6F);
	}
}
