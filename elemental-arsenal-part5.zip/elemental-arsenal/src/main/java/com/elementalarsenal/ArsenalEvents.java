package com.elementalarsenal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

public final class ArsenalEvents {
	private ArsenalEvents() {
	}

	/** Extra damage dealt by the fire sword against ice armor and by the ice sword against fire armor (12 -> 15). */
	private static final float COUNTER_BONUS_DAMAGE = 3.0F;

	/** Prevents the bonus hit from triggering the sword effects again. */
	private static boolean applyingBonus = false;

	/** How long the ice sword slowness lasts (5 seconds). */
	private static final int FREEZE_TICKS = 100;

	/** Fire pickaxe: dropped item -> smelted item (same count, so Fortune still counts). */
	private static final Map<Item, Item> SMELTS = new HashMap<>();
	static {
		SMELTS.put(Items.RAW_IRON, Items.IRON_INGOT);
		SMELTS.put(Items.RAW_GOLD, Items.GOLD_INGOT);
		SMELTS.put(Items.RAW_COPPER, Items.COPPER_INGOT);
		SMELTS.put(Items.ANCIENT_DEBRIS, Items.NETHERITE_SCRAP);
		SMELTS.put(Items.COBBLESTONE, Items.STONE);
		SMELTS.put(Items.COBBLED_DEEPSLATE, Items.DEEPSLATE);
		SMELTS.put(Items.SAND, Items.GLASS);
		SMELTS.put(Items.RED_SAND, Items.GLASS);
		SMELTS.put(Items.CLAY_BALL, Items.BRICK);
		// the element ores now drop raw crystals, so the fire pickaxe smelts those too
		SMELTS.put(ModItems.RAW_FIRE_CRYSTAL, ModItems.FIRE_CRYSTAL);
		SMELTS.put(ModItems.RAW_ICE_CRYSTAL, ModItems.ICE_CRYSTAL);
		SMELTS.put(ModItems.RAW_WIND_CRYSTAL, ModItems.WIND_CRYSTAL);
		SMELTS.put(ModItems.RAW_EARTH_CRYSTAL, ModItems.EARTH_CRYSTAL);
	}

	private record PendingSmelt(ServerLevel level, BlockPos pos) {
	}

	private static final List<PendingSmelt> PENDING_SMELTS = new ArrayList<>();

	/** Entities currently slowed by the ice sword -> server tick when the slowness ends. */
	private static final Map<LivingEntity, Integer> FROZEN = new LinkedHashMap<>();

	// ------------------------------------------------------------------ Glacial Spear: freeze + ice block look
	/** Slowness / freeze / ice block duration (5 seconds). */
	private static final int GLACIAL_TICKS = FREEZE_TICKS;
	private static final String CUBE_TAG = "ea_ice_cube";

	private static final class IceCube {
		final UUID id;
		int endTick;

		IceCube(UUID id, int endTick) {
			this.id = id;
			this.endTick = endTick;
		}
	}

	/** Entities currently wrapped in a (purely visual) ice block -> that block's display entity. */
	private static final Map<LivingEntity, IceCube> CUBES = new LinkedHashMap<>();

	public static void init() {
		IceSpikes.init();
		ServerLivingEntityEvents.ALLOW_DAMAGE.register(ArsenalEvents::allowDamage);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(ArsenalEvents::afterDamage);
		ServerTickEvents.END_SERVER_TICK.register(ArsenalEvents::onServerTick);
		PlayerBlockBreakEvents.AFTER.register(ArsenalEvents::afterBlockBreak);
		ServerEntityEvents.ENTITY_UNLOAD.register(ArsenalEvents::onEntityUnload);
		ServerLifecycleEvents.SERVER_STARTED.register(server -> runCommand(server,
				"kill @e[type=minecraft:block_display,tag=" + CUBE_TAG + "]"));
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			for (IceCube cube : CUBES.values()) {
				runCommand(server, "kill " + cube.id);
			}
			CUBES.clear();
			FROZEN.clear();
			PENDING_SMELTS.clear();
		});
	}

	// ------------------------------------------------------------------ damage immunities
	private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
		// Wind boots: no fall damage
		if (source.is(DamageTypeTags.IS_FALL) && entity.getItemBySlot(EquipmentSlot.FEET).is(ModItems.WIND_BOOTS)) {
			return false;
		}
		// Ice armor (full set): immune to freezing damage
		if (source.is(DamageTypeTags.IS_FREEZING) && hasFullSet(entity, ModItems.ICE_SET)) {
			return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ sword effects
	private static void afterDamage(LivingEntity target, DamageSource source, float baseDamageTaken, float damageTaken, boolean blocked) {
		if (applyingBonus || blocked) {
			return;
		}
		Entity attackerEntity = source.getEntity();
		if (!(attackerEntity instanceof LivingEntity attacker)) {
			return;
		}
		// melee only (not arrows, tridents, magic ...)
		if (source.getDirectEntity() != attacker) {
			return;
		}
		if (!(target.level() instanceof ServerLevel level)) {
			return;
		}

		ItemStack weapon = attacker.getMainHandItem();

		if (weapon.is(ModItems.FIRE_SWORD)) {
			fireHit(level, attacker, target, source);
		} else if (weapon.is(ModItems.ICE_SWORD)) {
			iceHit(level, attacker, target, source);
		} else if (weapon.is(ModItems.GLACIAL_SPEAR)) {
			glacialHit(level, target);
		} else if (weapon.is(ModItems.WIND_SWORD)) {
			windHit(level, attacker, target);
		} else if (weapon.is(ModItems.EARTH_SWORD)) {
			earthHit(level, target);
		}
	}

	private static void fireHit(ServerLevel level, LivingEntity attacker, LivingEntity target, DamageSource source) {
		// Fire Aspect V = 4 seconds per level = 20 seconds
		target.igniteForSeconds(20.0F);
		level.sendParticles(ParticleTypes.FLAME,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				25, 0.4, 0.5, 0.4, 0.05);
		level.sendParticles(ParticleTypes.LAVA,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				6, 0.3, 0.4, 0.3, 0.0);

		if (wearsAnyPiece(target, ModItems.ICE_SET)) {
			applyBonusDamage(level, target, source);
		}
	}

	private static void iceHit(ServerLevel level, LivingEntity attacker, LivingEntity target, DamageSource source) {
		// bonus damage first, so a killed target does not get an ice shell
		if (wearsAnyPiece(target, ModItems.FIRE_SET)) {
			applyBonusDamage(level, target, source);
		}
		if (!target.isAlive()) {
			return;
		}

		// Ice armor wearers are immune to the slowness
		if (hasFullSet(target, ModItems.ICE_SET)) {
			level.sendParticles(ParticleTypes.SNOWFLAKE,
					target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
					10, 0.4, 0.5, 0.4, 0.02);
			return;
		}

		// Slowness II + ice particles around the target + an ice block look (visual only, no real freezing)
		target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, FREEZE_TICKS, 1, false, true, true));
		iceBurst(level, target);
		FROZEN.put(target, level.getServer().getTickCount() + FREEZE_TICKS);
		encase(level, target, level.getServer().getTickCount() + FREEZE_TICKS);
	}

	private static void iceBurst(ServerLevel level, LivingEntity target) {
		level.sendParticles(ParticleTypes.SNOWFLAKE,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				40, 0.5, 0.7, 0.5, 0.05);
	}

	/** Keeps ice particles around frozen targets until the freeze ends. */
	private static void tickFrozen(MinecraftServer server) {
		if (FROZEN.isEmpty()) {
			return;
		}
		int now = server.getTickCount();
		Iterator<Map.Entry<LivingEntity, Integer>> it = FROZEN.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<LivingEntity, Integer> entry = it.next();
			LivingEntity entity = entry.getKey();
			if (now >= entry.getValue() || !entity.isAlive() || entity.isRemoved()) {
				it.remove();
				continue;
			}
			if (now % 2 == 0 && entity.level() instanceof ServerLevel level) {
				level.sendParticles(ParticleTypes.SNOWFLAKE,
						entity.getX(), entity.getY() + entity.getBbHeight() * 0.5, entity.getZ(),
						4, 0.4, entity.getBbHeight() * 0.4, 0.4, 0.01);
			}
		}
	}

	private static void glacialHit(ServerLevel level, LivingEntity target) {
		if (!target.isAlive()) {
			return;
		}
		// Ice armor wearers are immune to the freeze, like with the ice sword
		if (hasFullSet(target, ModItems.ICE_SET)) {
			level.sendParticles(ParticleTypes.SNOWFLAKE,
					target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
					10, 0.4, 0.5, 0.4, 0.02);
			return;
		}
		MinecraftServer server = level.getServer();
		int end = server.getTickCount() + GLACIAL_TICKS;

		// Slowness II + the ice block look (the target gets no freeze overlay on its own screen)
		target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, GLACIAL_TICKS, 1, false, true, true));
		encase(level, target, end);
	}

	/** Wraps the target in a translucent ice block that is only a visual (a block_display entity: nothing solid). */
	private static void encase(ServerLevel level, LivingEntity target, int end) {
		MinecraftServer server = level.getServer();
		// Hit again while still in the ice block: just extend it
		IceCube cube = CUBES.get(target);
		if (cube != null) {
			cube.endTick = Math.max(cube.endTick, end);
			return;
		}
		UUID id = UUID.randomUUID();
		double w = target.getBbWidth() + 0.3D;
		double h = target.getBbHeight() + 0.2D;
		long most = id.getMostSignificantBits();
		long least = id.getLeastSignificantBits();
		String nbt = String.format(Locale.ROOT,
				"{UUID:[I;%d,%d,%d,%d],block_state:{Name:\"minecraft:ice\"},teleport_duration:2,Tags:[\"%s\"],"
						+ "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
						+ "scale:[%.3ff,%.3ff,%.3ff],translation:[%.3ff,-0.1f,%.3ff]}}",
				(int) (most >> 32), (int) most, (int) (least >> 32), (int) least, CUBE_TAG,
				w, h, w, -w / 2.0D, -w / 2.0D);
		runCommand(server, "execute at " + target.getStringUUID() + " run summon minecraft:block_display ~ ~ ~ " + nbt);
		CUBES.put(target, new IceCube(id, end));
	}

	/** Keeps every ice block on its target and removes the block when the freeze ends. */
	private static void tickCubes(MinecraftServer server) {
		if (CUBES.isEmpty()) {
			return;
		}
		int now = server.getTickCount();
		Iterator<Map.Entry<LivingEntity, IceCube>> it = CUBES.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<LivingEntity, IceCube> entry = it.next();
			LivingEntity entity = entry.getKey();
			IceCube cube = entry.getValue();
			if (now >= cube.endTick || !entity.isAlive() || entity.isRemoved()) {
				runCommand(server, "kill " + cube.id);
				it.remove();
				continue;
			}
			runCommand(server, "execute as " + cube.id + " at " + entity.getStringUUID() + " run tp @s ~ ~ ~ 0 0");
		}
	}

	private static void runCommand(MinecraftServer server, String command) {
		server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
	}

	private static void windHit(ServerLevel level, LivingEntity attacker, LivingEntity target) {
		// Knockback III = 3 * 0.5 push strength, same direction vanilla uses for the attacker's facing
		double yaw = attacker.getYRot() * (Math.PI / 180.0);
		target.knockback(1.5F, Math.sin(yaw), -Math.cos(yaw));
		level.sendParticles(ParticleTypes.CLOUD,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				20, 0.4, 0.4, 0.4, 0.08);
	}

	private static void earthHit(ServerLevel level, LivingEntity target) {
		level.sendParticles(ParticleTypes.POOF,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				12, 0.4, 0.4, 0.4, 0.03);
		level.sendParticles(ParticleTypes.HAPPY_VILLAGER,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				8, 0.5, 0.5, 0.5, 0.0);
	}

	private static void applyBonusDamage(ServerLevel level, LivingEntity target, DamageSource source) {
		applyingBonus = true;
		try {
			target.invulnerableTime = 0;
			target.hurtServer(level, source, COUNTER_BONUS_DAMAGE);
		} finally {
			applyingBonus = false;
		}
	}

	// ------------------------------------------------------------------ Ender Dragon: dragon scales
	/** Dragon scales dropped once when the dragon dies: random 10..20 (inclusive). */
	private static final int SCALES_MIN = 10;
	private static final int SCALES_EXTRA = 11;

	private static void onEntityUnload(Entity entity, ServerLevel level) {
		if (entity.getType() != EntityType.ENDER_DRAGON || entity.getRemovalReason() != Entity.RemovalReason.KILLED) {
			return;
		}
		int count = SCALES_MIN + level.getRandom().nextInt(SCALES_EXTRA);
		// drop next to the closest player so the scales can never fall into the void
		// (if nobody is near, they drop where the dragon died)
		Player nearest = level.getNearestPlayer(entity, 192.0);
		double x = nearest != null ? nearest.getX() : entity.getX();
		double y = nearest != null ? nearest.getY() + 0.5 : entity.getY();
		double z = nearest != null ? nearest.getZ() : entity.getZ();
		level.addFreshEntity(new ItemEntity(level, x, y, z, new ItemStack(ModItems.DRAGON_SCALE, count)));
		for (ServerPlayer player : level.players()) {
			if (player.distanceTo(entity) <= 192.0F) {
				player.sendSystemMessage(Component.literal("التنين انكتل! نزلت " + count + " حرشفة تنين")
						.withStyle(ChatFormatting.LIGHT_PURPLE));
			}
		}
	}

	// ------------------------------------------------------------------ fire pickaxe: auto-smelt
	private static void afterBlockBreak(Level world, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity) {
		if (world instanceof ServerLevel level && player.getMainHandItem().is(ModItems.FIRE_PICKAXE)) {
			PENDING_SMELTS.add(new PendingSmelt(level, pos.immutable()));
		}
	}

	/** Runs at the end of the tick, when the drops of the broken block already exist as item entities. */
	private static void processSmelts() {
		if (PENDING_SMELTS.isEmpty()) {
			return;
		}
		for (PendingSmelt pending : PENDING_SMELTS) {
			ServerLevel level = pending.level();
			AABB box = new AABB(pending.pos()).inflate(1.0);
			for (ItemEntity drop : level.getEntitiesOfClass(ItemEntity.class, box, e -> e.tickCount < 5)) {
				ItemStack stack = drop.getItem();
				Item result = SMELTS.get(stack.getItem());
				if (result != null) {
					drop.setItem(new ItemStack(result, stack.getCount()));
					level.sendParticles(ParticleTypes.FLAME, drop.getX(), drop.getY() + 0.2, drop.getZ(), 6, 0.2, 0.2, 0.2, 0.01);
				}
			}
		}
		PENDING_SMELTS.clear();
	}

	// ------------------------------------------------------------------ passive perks (every 5 ticks)
	private static void onServerTick(MinecraftServer server) {
		tickFrozen(server);
		tickCubes(server);
		processSmelts();
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.tickCount % 5 == 0) {
				applyPerks(player);
			}
		}
	}

	private static void applyPerks(ServerPlayer player) {
		// Pickaxes: Haste while held (fire I, ice II, wind III, earth I)
		ItemStack held = player.getMainHandItem();
		if (held.is(ModItems.FIRE_PICKAXE) || held.is(ModItems.EARTH_PICKAXE)) {
			player.addEffect(new MobEffectInstance(MobEffects.HASTE, 30, 0, true, false, false));
		} else if (held.is(ModItems.ICE_PICKAXE)) {
			player.addEffect(new MobEffectInstance(MobEffects.HASTE, 30, 1, true, false, false));
		} else if (held.is(ModItems.WIND_PICKAXE)) {
			player.addEffect(new MobEffectInstance(MobEffects.HASTE, 30, 2, true, false, false));
		}
		// Earth sword: Strength II while held
		if (player.getMainHandItem().is(ModItems.EARTH_SWORD) || player.getOffhandItem().is(ModItems.EARTH_SWORD)) {
			player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 30, 1, true, false, false));
		}
		// Fire armor (full set): Fire Resistance
		if (hasFullSet(player, ModItems.FIRE_SET)) {
			player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, true, false, false));
		}
		// Earth armor (full set): Resistance II
		if (hasFullSet(player, ModItems.EARTH_SET)) {
			player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 40, 1, true, false, false));
		}
		// Ice armor (full set): never frozen (powder snow, ice sword)
		if (hasFullSet(player, ModItems.ICE_SET) && player.getTicksFrozen() > 0) {
			player.setTicksFrozen(0);
		}
	}

	// ------------------------------------------------------------------ helpers
	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
	};

	/** set = {helmet, chestplate, leggings, boots} */
	private static boolean hasFullSet(LivingEntity entity, Item[] set) {
		for (int i = 0; i < ARMOR_SLOTS.length; i++) {
			if (!entity.getItemBySlot(ARMOR_SLOTS[i]).is(set[i])) {
				return false;
			}
		}
		return true;
	}

	private static boolean wearsAnyPiece(LivingEntity entity, Item[] set) {
		for (int i = 0; i < ARMOR_SLOTS.length; i++) {
			if (entity.getItemBySlot(ARMOR_SLOTS[i]).is(set[i])) {
				return true;
			}
		}
		return false;
	}
}
