package com.elementalarsenal;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModItems {
	private ModItems() {
	}

	/** Every item of the mod, in creative-tab order. */
	private static final List<Item> ALL = new ArrayList<>();

	// Attack damage passed to Item.Properties#sword. Total damage = 1 (player base) + this = 12.
	private static final float SWORD_DAMAGE = 11.0F;
	private static final float SWORD_SPEED = -2.4F;
	// Dragon sword: total damage 26 = 1 (player base) + 25.
	private static final float DRAGON_SWORD_DAMAGE = 25.0F;

	// ---------------------------------------------------------------- swords
	public static final Item FIRE_SWORD = sword("fire_sword", ChatFormatting.GOLD,
			"Fire Aspect V", "Sets enemies ablaze for 20 seconds", "+3 damage against Ice armor");
	public static final Item ICE_SWORD = sword("ice_sword", ChatFormatting.AQUA,
			"Slows enemies with icy frost", "Slowness II", "Encases them in a block of ice", "+3 damage against Fire armor");
	public static final Item WIND_SWORD = sword("wind_sword", ChatFormatting.WHITE,
			"Knockback III", "Blows enemies away");
	public static final Item EARTH_SWORD = sword("earth_sword", ChatFormatting.GREEN,
			"Strength II while held", "The strength of the mountain");

	// Glacial Spear: dropped by the Glacial Warlord only (no recipe). Vanilla spear range and timing, damage 14.
	public static final Item GLACIAL_SPEAR = glacialSpear("glacial_spear",
			"Torn from the grip of the Glacial Warlord", "Damage 14",
			"Applies Slowness II", "Encases them in a block of ice");

	// ---------------------------------------------------------------- dragon set (scales drop from the Ender Dragon)
	public static final Item DRAGON_SCALE = register("dragon_scale", Item::new, new Item.Properties().rarity(Rarity.EPIC));
	public static final Item DRAGON_SWORD = dragonSword("dragon_sword",
			"Forged from Ender Dragon scales", "Damage 26");
	public static final Item DRAGON_HELMET = dragonArmor("dragon_helmet", ArmorType.HELMET);
	public static final Item DRAGON_CHESTPLATE = dragonArmor("dragon_chestplate", ArmorType.CHESTPLATE);
	public static final Item DRAGON_LEGGINGS = dragonArmor("dragon_leggings", ArmorType.LEGGINGS);
	public static final Item DRAGON_BOOTS = dragonArmor("dragon_boots", ArmorType.BOOTS);

	// ---------------------------------------------------------------- pickaxes
	public static final Item FIRE_PICKAXE = pickaxe("fire_pickaxe", ChatFormatting.GOLD,
			"Haste I while held", "Auto-smelts ores (Fortune works)");
	public static final Item ICE_PICKAXE = pickaxe("ice_pickaxe", ChatFormatting.AQUA,
			"Haste II while held");
	public static final Item WIND_PICKAXE = pickaxe("wind_pickaxe", ChatFormatting.WHITE,
			"Haste III while held");
	public static final Item EARTH_PICKAXE = pickaxe("earth_pickaxe", ChatFormatting.GREEN,
			"Haste I while held");

	// ---------------------------------------------------------------- armor
	public static final Item FIRE_HELMET = armor("fire_helmet", ModMaterials.FIRE_ARMOR, ArmorType.HELMET, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_CHESTPLATE = armor("fire_chestplate", ModMaterials.FIRE_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_LEGGINGS = armor("fire_leggings", ModMaterials.FIRE_ARMOR, ArmorType.LEGGINGS, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_BOOTS = armor("fire_boots", ModMaterials.FIRE_ARMOR, ArmorType.BOOTS, ChatFormatting.GOLD, "Full set: Fire Resistance");

	public static final Item ICE_HELMET = armor("ice_helmet", ModMaterials.ICE_ARMOR, ArmorType.HELMET, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_CHESTPLATE = armor("ice_chestplate", ModMaterials.ICE_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_LEGGINGS = armor("ice_leggings", ModMaterials.ICE_ARMOR, ArmorType.LEGGINGS, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_BOOTS = armor("ice_boots", ModMaterials.ICE_ARMOR, ArmorType.BOOTS, ChatFormatting.AQUA, "Full set: immune to ice and freezing");

	public static final Item WIND_HELMET = armor("wind_helmet", ModMaterials.WIND_ARMOR, ArmorType.HELMET, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_CHESTPLATE = armor("wind_chestplate", ModMaterials.WIND_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_LEGGINGS = armor("wind_leggings", ModMaterials.WIND_ARMOR, ArmorType.LEGGINGS, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_BOOTS = armor("wind_boots", ModMaterials.WIND_ARMOR, ArmorType.BOOTS, ChatFormatting.WHITE, "No fall damage");

	public static final Item EARTH_HELMET = armor("earth_helmet", ModMaterials.EARTH_ARMOR, ArmorType.HELMET, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_CHESTPLATE = armor("earth_chestplate", ModMaterials.EARTH_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_LEGGINGS = armor("earth_leggings", ModMaterials.EARTH_ARMOR, ArmorType.LEGGINGS, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_BOOTS = armor("earth_boots", ModMaterials.EARTH_ARMOR, ArmorType.BOOTS, ChatFormatting.GREEN, "Full set: Resistance II");

	public static final Item[] FIRE_SET = {FIRE_HELMET, FIRE_CHESTPLATE, FIRE_LEGGINGS, FIRE_BOOTS};
	public static final Item[] ICE_SET = {ICE_HELMET, ICE_CHESTPLATE, ICE_LEGGINGS, ICE_BOOTS};
	public static final Item[] WIND_SET = {WIND_HELMET, WIND_CHESTPLATE, WIND_LEGGINGS, WIND_BOOTS};
	public static final Item[] EARTH_SET = {EARTH_HELMET, EARTH_CHESTPLATE, EARTH_LEGGINGS, EARTH_BOOTS};
	public static final Item[] DRAGON_SET = {DRAGON_HELMET, DRAGON_CHESTPLATE, DRAGON_LEGGINGS, DRAGON_BOOTS};

	// ---------------------------------------------------------------- resources (crafting materials)
	public static final Item FIRE_CRYSTAL = resource("fire_crystal");
	public static final Item ICE_CRYSTAL = resource("ice_crystal");
	public static final Item WIND_CRYSTAL = resource("wind_crystal");
	public static final Item EARTH_CRYSTAL = resource("earth_crystal");

	// raw form: this is what the ores drop. Smelt it (furnace or blast furnace) to get the crystal above.
	public static final Item RAW_FIRE_CRYSTAL = resource("raw_fire_crystal");
	public static final Item RAW_ICE_CRYSTAL = resource("raw_ice_crystal");
	public static final Item RAW_WIND_CRYSTAL = resource("raw_wind_crystal");
	public static final Item RAW_EARTH_CRYSTAL = resource("raw_earth_crystal");

	// ores that generate in the world (see worldgen/ in the data folder) and drop the crystals
	public static final Block FIRE_ORE = ore("fire_ore", 7);
	public static final Block ICE_ORE = ore("ice_ore", 0);
	public static final Block WIND_ORE = ore("wind_ore", 0);
	public static final Block EARTH_ORE = ore("earth_ore", 0);

	// ---------------------------------------------------------------- creative tab
	public static final ResourceKey<CreativeModeTab> TAB_KEY =
			ResourceKey.create(Registries.CREATIVE_MODE_TAB, ElementalArsenal.id("arsenal"));

	public static final CreativeModeTab TAB = FabricItemGroup.builder()
			.icon(() -> new ItemStack(FIRE_SWORD))
			.title(Component.translatable("itemGroup.elementalarsenal"))
			.displayItems((params, output) -> {
				for (Item item : ALL) {
					output.accept(item);
				}
			})
			.build();

	/** Called from the mod initializer so that the static fields above are registered. */
	public static void init() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_KEY, TAB);
	}

	// ---------------------------------------------------------------- helpers
	private static Item resource(String name) {
		return register(name, Item::new, new Item.Properties().rarity(Rarity.RARE));
	}

	private static Block ore(String name, int light) {
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, ElementalArsenal.id(name));
		Block block = new Block(BlockBehaviour.Properties.of()
				.strength(3.0F, 3.0F)
				.requiresCorrectToolForDrops()
				.sound(SoundType.STONE)
				.lightLevel(state -> light)
				.setId(blockKey));
		Registry.register(BuiltInRegistries.BLOCK, blockKey, block);

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, ElementalArsenal.id(name));
		BlockItem item = new BlockItem(block, new Item.Properties().useBlockDescriptionPrefix().setId(itemKey));
		Registry.register(BuiltInRegistries.ITEM, itemKey, item);
		ALL.add(item);
		return block;
	}

	private static Item sword(String name, ChatFormatting color, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.sword(ModMaterials.SWORD_MATERIAL, SWORD_DAMAGE, SWORD_SPEED)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(color, loreLines));
		return register(name, Item::new, props);
	}

	private static Item glacialSpear(String name, String... loreLines) {
		// same attack timing, charge and lunge values as the vanilla iron spear; range comes from the spear itself
		Item.Properties props = new Item.Properties()
				.spear(ModMaterials.GLACIAL_MATERIAL, 0.95F, 0.95F, 0.6F, 2.5F, 11.0F, 6.75F, 5.1F, 11.25F, 4.6F)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(ChatFormatting.AQUA, loreLines));
		return register(name, Item::new, props);
	}

	private static Item dragonSword(String name, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.sword(ModMaterials.DRAGON_MATERIAL, DRAGON_SWORD_DAMAGE, SWORD_SPEED)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(ChatFormatting.LIGHT_PURPLE, loreLines));
		return register(name, Item::new, props);
	}

	private static Item dragonArmor(String name, ArmorType type) {
		Item.Properties props = new Item.Properties()
				.humanoidArmor(ModMaterials.DRAGON_ARMOR, type)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(ChatFormatting.LIGHT_PURPLE, "Forged from Ender Dragon scales"));
		return register(name, Item::new, props);
	}

	private static Item pickaxe(String name, ChatFormatting color, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.pickaxe(ModMaterials.SWORD_MATERIAL, 1.0F, -2.8F)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(color, loreLines));
		return register(name, Item::new, props);
	}

	private static Item armor(String name, ArmorMaterial material, ArmorType type, ChatFormatting color, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.humanoidArmor(material, type)
				.durability(type.getDurability(ModMaterials.ARMOR_DURABILITY))
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(color, loreLines));
		return register(name, Item::new, props);
	}

	private static ItemLore lore(ChatFormatting color, String... lines) {
		List<Component> out = new ArrayList<>();
		for (String line : lines) {
			out.add(Component.literal(line).withStyle(color));
		}
		return new ItemLore(out);
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ElementalArsenal.id(name));
		T item = factory.apply(props.setId(key));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		ALL.add(item);
		return item;
	}
}
