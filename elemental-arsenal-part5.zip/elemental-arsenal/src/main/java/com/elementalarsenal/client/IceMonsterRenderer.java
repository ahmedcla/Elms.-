package com.elementalarsenal.client;

import com.elementalarsenal.ElementalArsenal;
import com.elementalarsenal.IceMonster;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class IceMonsterRenderer extends MobRenderer<IceMonster, IceMonsterRenderState, IceMonsterModel> {
	private static final Identifier TEXTURE = ElementalArsenal.id("textures/entity/ice_monster.png");

	public IceMonsterRenderer(EntityRendererProvider.Context context) {
		super(context, new IceMonsterModel(IceMonsterModel.createBodyLayer().bakeRoot()), 1.4F);
	}

	@Override
	public IceMonsterRenderState createRenderState() {
		return new IceMonsterRenderState();
	}

	@Override
	public Identifier getTextureLocation(IceMonsterRenderState state) {
		return TEXTURE;
	}
}
