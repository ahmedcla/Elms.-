package com.elementalarsenal.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Model of the Inferno Colossus.
 * NOTE: this file is generated together with the texture (tools/gen_monster.py) so every UV offset matches the PNG.
 */
public class FireMonsterModel extends EntityModel<FireMonsterRenderState> {
	private final ModelPart head;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;
	private final ModelPart body;

	public FireMonsterModel(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.head = root.getChild("head");
		this.rightArm = root.getChild("arm_r");
		this.leftArm = root.getChild("arm_l");
		this.rightLeg = root.getChild("leg_r");
		this.leftLeg = root.getChild("leg_l");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		PartDefinition p_body = root.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(0, 0).addBox(-12F, -24F, -6F, 24F, 24F, 12F),
				PartPose.offset(0F, 4F, 0F));
		PartDefinition p_belt = p_body.addOrReplaceChild("belt",
				CubeListBuilder.create().texOffs(0, 36).addBox(-11F, -3F, -7F, 22F, 5F, 14F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_core = p_body.addOrReplaceChild("core",
				CubeListBuilder.create().texOffs(224, 55).addBox(-3.5F, -17.5F, -8F, 7F, 7F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_backplate = p_body.addOrReplaceChild("backplate",
				CubeListBuilder.create().texOffs(56, 55).addBox(-8F, -20F, 6F, 16F, 14F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_head = root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(136, 0).addBox(-6F, -12F, -6F, 12F, 12F, 12F),
				PartPose.offset(0F, -20F, 0F));
		PartDefinition p_crown = p_head.addOrReplaceChild("crown",
				CubeListBuilder.create().texOffs(0, 55).addBox(-7F, -15F, -7F, 14F, 3F, 14F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_horn_a_r = p_head.addOrReplaceChild("horn_a_r",
				CubeListBuilder.create().texOffs(176, 55).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(-4.5F, -14F, 0F, 0F, 0F, -0.22F));
		PartDefinition p_horn_a2_r = p_horn_a_r.addOrReplaceChild("horn_a2_r",
				CubeListBuilder.create().texOffs(242, 55).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F),
				PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, -0.3F));
		PartDefinition p_horn_a3_r = p_horn_a2_r.addOrReplaceChild("horn_a3_r",
				CubeListBuilder.create().texOffs(80, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -6F, 0F));
		PartDefinition p_horn_b_r = p_head.addOrReplaceChild("horn_b_r",
				CubeListBuilder.create().texOffs(0, 72).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F),
				PartPose.offsetAndRotation(-7.5F, -13F, 0F, 0F, 0F, -0.75F));
		PartDefinition p_horn_b2_r = p_horn_b_r.addOrReplaceChild("horn_b2_r",
				CubeListBuilder.create().texOffs(96, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -6F, 0F));
		PartDefinition p_horn_a_l = p_head.addOrReplaceChild("horn_a_l",
				CubeListBuilder.create().texOffs(188, 55).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(4.5F, -14F, 0F, 0F, 0F, 0.22F));
		PartDefinition p_horn_a2_l = p_horn_a_l.addOrReplaceChild("horn_a2_l",
				CubeListBuilder.create().texOffs(12, 72).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F),
				PartPose.offsetAndRotation(0F, -8F, 0F, 0F, 0F, 0.3F));
		PartDefinition p_horn_a3_l = p_horn_a2_l.addOrReplaceChild("horn_a3_l",
				CubeListBuilder.create().texOffs(112, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -6F, 0F));
		PartDefinition p_horn_b_l = p_head.addOrReplaceChild("horn_b_l",
				CubeListBuilder.create().texOffs(24, 72).addBox(-1.5F, -6F, -1.5F, 3F, 6F, 3F),
				PartPose.offsetAndRotation(7.5F, -13F, 0F, 0F, 0F, 0.75F));
		PartDefinition p_horn_b2_l = p_horn_b_l.addOrReplaceChild("horn_b2_l",
				CubeListBuilder.create().texOffs(128, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -6F, 0F));
		PartDefinition p_arm_r = root.addOrReplaceChild("arm_r",
				CubeListBuilder.create().texOffs(72, 0).addBox(-4F, -2F, -4F, 8F, 18F, 8F),
				PartPose.offset(-16F, -18F, 0F));
		PartDefinition p_pad_r = p_arm_r.addOrReplaceChild("pad_r",
				CubeListBuilder.create().texOffs(72, 36).addBox(-6F, -6F, -6F, 12F, 6F, 12F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_padhorn_r = p_pad_r.addOrReplaceChild("padhorn_r",
				CubeListBuilder.create().texOffs(200, 55).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F),
				PartPose.offsetAndRotation(-2.5F, -6F, 0F, 0F, 0F, -0.45F));
		PartDefinition p_padhorn2_r = p_padhorn_r.addOrReplaceChild("padhorn2_r",
				CubeListBuilder.create().texOffs(144, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -7F, 0F));
		PartDefinition p_fist_r = p_arm_r.addOrReplaceChild("fist_r",
				CubeListBuilder.create().texOffs(120, 36).addBox(-5F, 0F, -5F, 10F, 8F, 10F),
				PartPose.offset(0F, 16F, 0F));
		PartDefinition p_arm_l = root.addOrReplaceChild("arm_l",
				CubeListBuilder.create().texOffs(104, 0).addBox(-4F, -2F, -4F, 8F, 18F, 8F),
				PartPose.offset(16F, -18F, 0F));
		PartDefinition p_pad_l = p_arm_l.addOrReplaceChild("pad_l",
				CubeListBuilder.create().texOffs(160, 36).addBox(-6F, -6F, -6F, 12F, 6F, 12F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_padhorn_l = p_pad_l.addOrReplaceChild("padhorn_l",
				CubeListBuilder.create().texOffs(212, 55).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F),
				PartPose.offsetAndRotation(2.5F, -6F, 0F, 0F, 0F, 0.45F));
		PartDefinition p_padhorn2_l = p_padhorn_l.addOrReplaceChild("padhorn2_l",
				CubeListBuilder.create().texOffs(160, 72).addBox(-2F, -3F, -2F, 4F, 3F, 4F),
				PartPose.offset(0F, -7F, 0F));
		PartDefinition p_fist_l = p_arm_l.addOrReplaceChild("fist_l",
				CubeListBuilder.create().texOffs(208, 36).addBox(-5F, 0F, -5F, 10F, 8F, 10F),
				PartPose.offset(0F, 16F, 0F));
		PartDefinition p_leg_r = root.addOrReplaceChild("leg_r",
				CubeListBuilder.create().texOffs(184, 0).addBox(-4F, 0F, -4F, 8F, 16F, 8F),
				PartPose.offset(-5.5F, 4F, 0F));
		PartDefinition p_knee_r = p_leg_r.addOrReplaceChild("knee_r",
				CubeListBuilder.create().texOffs(36, 72).addBox(-4.5F, 6F, -5.5F, 9F, 6F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_boot_r = p_leg_r.addOrReplaceChild("boot_r",
				CubeListBuilder.create().texOffs(92, 55).addBox(-5F, 16F, -6F, 10F, 4F, 11F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_leg_l = root.addOrReplaceChild("leg_l",
				CubeListBuilder.create().texOffs(216, 0).addBox(-4F, 0F, -4F, 8F, 16F, 8F),
				PartPose.offset(5.5F, 4F, 0F));
		PartDefinition p_knee_l = p_leg_l.addOrReplaceChild("knee_l",
				CubeListBuilder.create().texOffs(58, 72).addBox(-4.5F, 6F, -5.5F, 9F, 6F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_boot_l = p_leg_l.addOrReplaceChild("boot_l",
				CubeListBuilder.create().texOffs(134, 55).addBox(-5F, 16F, -6F, 10F, 4F, 11F),
				PartPose.offset(0F, 0F, 0F));

		return LayerDefinition.create(mesh, 256, 128);
	}

	@Override
	public void setupAnim(FireMonsterRenderState state) {
		super.setupAnim(state);

		float walkPos = state.walkAnimationPos;
		float walkSpeed = Math.min(state.walkAnimationSpeed, 1.0F);
		float age = state.ageInTicks;

		// Look direction
		this.head.yRot = state.yRot * Mth.DEG_TO_RAD;
		this.head.xRot = state.xRot * Mth.DEG_TO_RAD;

		// Heavy, slow walk cycle
		this.rightLeg.xRot = Mth.cos(walkPos * 0.5F) * 1.1F * walkSpeed;
		this.leftLeg.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 1.1F * walkSpeed;
		this.rightArm.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 0.7F * walkSpeed;
		this.leftArm.xRot = Mth.cos(walkPos * 0.5F) * 0.7F * walkSpeed;
		this.body.yRot = Mth.cos(walkPos * 0.5F) * 0.06F * walkSpeed;

		// Idle breathing
		this.rightArm.zRot = -0.05F - Mth.sin(age * 0.08F) * 0.03F;
		this.leftArm.zRot = 0.05F + Mth.sin(age * 0.08F) * 0.03F;

		switch (state.attackState) {
			case FireMonsterRenderState.STATE_NOVA -> {
				// Arms raised high while gathering energy
				float shake = Mth.sin(age * 1.6F) * 0.04F;
				this.rightArm.xRot = -2.6F + shake;
				this.leftArm.xRot = -2.6F - shake;
				this.rightArm.zRot = -0.35F;
				this.leftArm.zRot = 0.35F;
				this.head.xRot -= 0.35F;
			}
			case FireMonsterRenderState.STATE_LANCE -> {
				// Both fists pointed forward
				this.rightArm.xRot = -1.55F;
				this.leftArm.xRot = -1.55F;
				this.rightArm.zRot = -0.12F;
				this.leftArm.zRot = 0.12F;
			}
			case FireMonsterRenderState.STATE_ERUPTION -> {
				// Fists slammed down toward the ground
				float pulse = Mth.sin(age * 0.9F) * 0.12F;
				this.rightArm.xRot = -0.9F + pulse;
				this.leftArm.xRot = -0.9F - pulse;
				this.rightArm.zRot = -0.5F;
				this.leftArm.zRot = 0.5F;
				this.head.xRot += 0.25F;
			}
			default -> {
				// Regular melee swing
				if (state.attackAnim > 0.0F) {
					float swing = Mth.sin(state.attackAnim * Mth.PI);
					this.rightArm.xRot = -swing * 2.2F;
					this.leftArm.xRot = -swing * 2.2F;
				}
			}
		}
	}
}
