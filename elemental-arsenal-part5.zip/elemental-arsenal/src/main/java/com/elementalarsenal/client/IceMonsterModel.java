package com.elementalarsenal.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Model of the Glacial Warlord (ice boss): a crowned ice king with crystal wings, a halo, a cape,
 * a scepter and shards that orbit his body.
 * NOTE: this file is generated together with the texture (tools/gen_ice_monster.py) so every UV offset matches the PNG.
 */
public class IceMonsterModel extends EntityModel<IceMonsterRenderState> {
	private final ModelPart body;
	private final ModelPart head;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;
	private final ModelPart cape;
	private final ModelPart rightWing;
	private final ModelPart leftWing;
	private final ModelPart halo;
	private final ModelPart orbit;

	public IceMonsterModel(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.head = root.getChild("head");
		this.rightArm = root.getChild("arm_r");
		this.leftArm = root.getChild("arm_l");
		this.rightLeg = root.getChild("leg_r");
		this.leftLeg = root.getChild("leg_l");
		this.cape = root.getChild("cape");
		this.rightWing = root.getChild("wing_r");
		this.leftWing = root.getChild("wing_l");
		this.halo = root.getChild("halo");
		this.orbit = root.getChild("orbit");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		PartDefinition p_body = root.addOrReplaceChild("body",
				CubeListBuilder.create().texOffs(116, 0).addBox(-7F, -20F, -5F, 14F, 20F, 10F),
				PartPose.offset(0F, 4F, 0F));
		PartDefinition p_chest = p_body.addOrReplaceChild("chest",
				CubeListBuilder.create().texOffs(78, 58).addBox(-8F, -19F, -6F, 16F, 11F, 12F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_belt = p_body.addOrReplaceChild("belt",
				CubeListBuilder.create().texOffs(168, 102).addBox(-8F, -3F, -6F, 16F, 4F, 12F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_buckle = p_body.addOrReplaceChild("buckle",
				CubeListBuilder.create().texOffs(172, 186).addBox(-3F, -3F, -8F, 6F, 4F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_core_main = p_body.addOrReplaceChild("core_main",
				CubeListBuilder.create().texOffs(108, 151).addBox(-2F, -5F, -3F, 4F, 10F, 3F),
				PartPose.offset(0F, -14F, -6F));
		PartDefinition p_core_side_l = p_body.addOrReplaceChild("core_side_l",
				CubeListBuilder.create().texOffs(0, 176).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F),
				PartPose.offsetAndRotation(5F, -11F, -6.5F, 0F, 0F, 0.6F));
		PartDefinition p_core_side_r = p_body.addOrReplaceChild("core_side_r",
				CubeListBuilder.create().texOffs(12, 176).addBox(-1.5F, -7F, -1.5F, 3F, 7F, 3F),
				PartPose.offsetAndRotation(-5F, -11F, -6.5F, 0F, 0F, -0.6F));
		PartDefinition p_collar = p_body.addOrReplaceChild("collar",
				CubeListBuilder.create().texOffs(48, 83).addBox(-10F, -20F, -6.5F, 20F, 5F, 13F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_spire_a_l = p_body.addOrReplaceChild("spire_a_l",
				CubeListBuilder.create().texOffs(100, 136).addBox(-2F, -12F, -1F, 4F, 12F, 2F),
				PartPose.offsetAndRotation(7F, -20F, 3F, 0.2F, 0F, 0.3F));
		PartDefinition p_spire_b_l = p_body.addOrReplaceChild("spire_b_l",
				CubeListBuilder.create().texOffs(24, 176).addBox(-1.5F, -8F, -1F, 3F, 8F, 2F),
				PartPose.offsetAndRotation(10F, -19F, 2F, 0.15F, 0F, 0.75F));
		PartDefinition p_spire_a_r = p_body.addOrReplaceChild("spire_a_r",
				CubeListBuilder.create().texOffs(112, 136).addBox(-2F, -12F, -1F, 4F, 12F, 2F),
				PartPose.offsetAndRotation(-7F, -20F, 3F, 0.2F, 0F, -0.3F));
		PartDefinition p_spire_b_r = p_body.addOrReplaceChild("spire_b_r",
				CubeListBuilder.create().texOffs(34, 176).addBox(-1.5F, -8F, -1F, 3F, 8F, 2F),
				PartPose.offsetAndRotation(-10F, -19F, 2F, 0.15F, 0F, -0.75F));
		PartDefinition p_skirt_f = p_body.addOrReplaceChild("skirt_f",
				CubeListBuilder.create().texOffs(228, 136).addBox(-6F, 0F, -1F, 12F, 11F, 2F),
				PartPose.offsetAndRotation(0F, 0F, -6F, -0.1F, 0F, 0F));
		PartDefinition p_hem_f = p_skirt_f.addOrReplaceChild("hem_f",
				CubeListBuilder.create().texOffs(40, 186).addBox(-7F, 0F, -2F, 14F, 3F, 4F),
				PartPose.offset(0F, 9F, 0F));
		PartDefinition p_skirt_b = p_body.addOrReplaceChild("skirt_b",
				CubeListBuilder.create().texOffs(0, 151).addBox(-6F, 0F, -1F, 12F, 11F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 6F, 0.1F, 0F, 0F));
		PartDefinition p_hem_b = p_skirt_b.addOrReplaceChild("hem_b",
				CubeListBuilder.create().texOffs(76, 186).addBox(-7F, 0F, -2F, 14F, 3F, 4F),
				PartPose.offset(0F, 9F, 0F));
		PartDefinition p_head = root.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(10, 58).addBox(-6F, -12F, -6F, 12F, 12F, 12F),
				PartPose.offset(0F, -16F, 0F));
		PartDefinition p_helm_back = p_head.addOrReplaceChild("helm_back",
				CubeListBuilder.create().texOffs(134, 58).addBox(-7F, -13F, -1F, 14F, 14F, 8F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_brow = p_head.addOrReplaceChild("brow",
				CubeListBuilder.create().texOffs(112, 194).addBox(-7F, -10F, -8F, 14F, 3F, 2F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_cheek_l = p_head.addOrReplaceChild("cheek_l",
				CubeListBuilder.create().texOffs(88, 102).addBox(6F, -8F, -4F, 3F, 8F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_cheek_r = p_head.addOrReplaceChild("cheek_r",
				CubeListBuilder.create().texOffs(112, 102).addBox(-9F, -8F, -4F, 3F, 8F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_chin = p_head.addOrReplaceChild("chin",
				CubeListBuilder.create().texOffs(28, 151).addBox(-2F, 0F, -2F, 4F, 9F, 4F),
				PartPose.offsetAndRotation(0F, 0F, -5F, -0.22F, 0F, 0F));
		PartDefinition p_chin_l = p_head.addOrReplaceChild("chin_l",
				CubeListBuilder.create().texOffs(156, 186).addBox(-1F, 0F, -1F, 2F, 5F, 2F),
				PartPose.offsetAndRotation(3.5F, 0F, -5F, -0.2F, 0F, 0.2F));
		PartDefinition p_chin_r = p_head.addOrReplaceChild("chin_r",
				CubeListBuilder.create().texOffs(164, 186).addBox(-1F, 0F, -1F, 2F, 5F, 2F),
				PartPose.offsetAndRotation(-3.5F, 0F, -5F, -0.2F, 0F, -0.2F));
		PartDefinition p_crown_ring = p_head.addOrReplaceChild("crown_ring",
				CubeListBuilder.create().texOffs(114, 83).addBox(-7.5F, -15F, -7.5F, 15F, 3F, 15F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_crown_gem = p_head.addOrReplaceChild("crown_gem",
				CubeListBuilder.create().texOffs(144, 186).addBox(-2F, -5F, -1F, 4F, 5F, 2F),
				PartPose.offset(0F, -12.5F, -8F));
		PartDefinition p_crown_c = p_head.addOrReplaceChild("crown_c",
				CubeListBuilder.create().texOffs(72, 102).addBox(-2F, -14F, -2F, 4F, 14F, 4F),
				PartPose.offset(0F, -15F, 0F));
		PartDefinition p_crown_f_l = p_head.addOrReplaceChild("crown_f_l",
				CubeListBuilder.create().texOffs(124, 136).addBox(-1.5F, -11F, -1.5F, 3F, 11F, 3F),
				PartPose.offsetAndRotation(4.5F, -15F, 0F, 0F, 0F, 0.3F));
		PartDefinition p_crown_o_l = p_head.addOrReplaceChild("crown_o_l",
				CubeListBuilder.create().texOffs(36, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(6.5F, -14F, 0F, 0F, 0F, 0.62F));
		PartDefinition p_crown_b_l = p_head.addOrReplaceChild("crown_b_l",
				CubeListBuilder.create().texOffs(236, 151).addBox(-1.5F, -9F, -1.5F, 3F, 9F, 3F),
				PartPose.offsetAndRotation(3.5F, -15F, 5F, -0.45F, 0F, 0.15F));
		PartDefinition p_crown_f_r = p_head.addOrReplaceChild("crown_f_r",
				CubeListBuilder.create().texOffs(136, 136).addBox(-1.5F, -11F, -1.5F, 3F, 11F, 3F),
				PartPose.offsetAndRotation(-4.5F, -15F, 0F, 0F, 0F, -0.3F));
		PartDefinition p_crown_o_r = p_head.addOrReplaceChild("crown_o_r",
				CubeListBuilder.create().texOffs(48, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(-6.5F, -14F, 0F, 0F, 0F, -0.62F));
		PartDefinition p_crown_b_r = p_head.addOrReplaceChild("crown_b_r",
				CubeListBuilder.create().texOffs(0, 164).addBox(-1.5F, -9F, -1.5F, 3F, 9F, 3F),
				PartPose.offsetAndRotation(-3.5F, -15F, 5F, -0.45F, 0F, -0.15F));
		PartDefinition p_crown_bc = p_head.addOrReplaceChild("crown_bc",
				CubeListBuilder.create().texOffs(122, 151).addBox(-1.5F, -10F, -1.5F, 3F, 10F, 3F),
				PartPose.offsetAndRotation(0F, -15F, 6F, -0.6F, 0F, 0F));
		PartDefinition p_arm_l = root.addOrReplaceChild("arm_l",
				CubeListBuilder.create().texOffs(0, 102).addBox(-3F, -2F, -3F, 6F, 12F, 6F),
				PartPose.offset(11F, -12F, 0F));
		PartDefinition p_fore_l = p_arm_l.addOrReplaceChild("fore_l",
				CubeListBuilder.create().texOffs(222, 58).addBox(-3.5F, 9F, -3.5F, 7F, 12F, 7F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_hand_l = p_arm_l.addOrReplaceChild("hand_l",
				CubeListBuilder.create().texOffs(88, 176).addBox(-3F, 21F, -3F, 6F, 3F, 6F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_finger0_l = p_arm_l.addOrReplaceChild("finger0_l",
				CubeListBuilder.create().texOffs(242, 176).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(-2F, 24F, -1.5F, -0.1F, 0F, 0F));
		PartDefinition p_finger1_l = p_arm_l.addOrReplaceChild("finger1_l",
				CubeListBuilder.create().texOffs(0, 186).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(0F, 24F, -2F, -0.25F, 0F, 0F));
		PartDefinition p_finger2_l = p_arm_l.addOrReplaceChild("finger2_l",
				CubeListBuilder.create().texOffs(8, 186).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(2F, 24F, -1.5F, -0.1F, 0F, 0F));
		PartDefinition p_pauld1_l = p_arm_l.addOrReplaceChild("pauld1_l",
				CubeListBuilder.create().texOffs(176, 120).addBox(-5.5F, -7F, -5.5F, 11F, 4F, 11F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_pauld2_l = p_arm_l.addOrReplaceChild("pauld2_l",
				CubeListBuilder.create().texOffs(164, 151).addBox(-4.5F, -10F, -4.5F, 9F, 3F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_pspike_a_l = p_arm_l.addOrReplaceChild("pspike_a_l",
				CubeListBuilder.create().texOffs(136, 102).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
				PartPose.offsetAndRotation(1F, -10F, 0F, 0F, 0F, 0.45F));
		PartDefinition p_pspike_b_l = p_arm_l.addOrReplaceChild("pspike_b_l",
				CubeListBuilder.create().texOffs(12, 164).addBox(-1.5F, -9F, -1.5F, 3F, 9F, 3F),
				PartPose.offsetAndRotation(0F, -9F, 3F, -0.5F, 0F, 0.2F));
		PartDefinition p_pspike_c_l = p_arm_l.addOrReplaceChild("pspike_c_l",
				CubeListBuilder.create().texOffs(60, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(1F, -9F, -3F, 0.4F, 0F, 0.2F));
		PartDefinition p_elbow_l = p_arm_l.addOrReplaceChild("elbow_l",
				CubeListBuilder.create().texOffs(72, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(3F, 9F, 0F, -0.3F, 0F, 1.45F));
		PartDefinition p_arm_r = root.addOrReplaceChild("arm_r",
				CubeListBuilder.create().texOffs(24, 102).addBox(-3F, -2F, -3F, 6F, 12F, 6F),
				PartPose.offset(-11F, -12F, 0F));
		PartDefinition p_fore_r = p_arm_r.addOrReplaceChild("fore_r",
				CubeListBuilder.create().texOffs(0, 83).addBox(-3.5F, 9F, -3.5F, 7F, 12F, 7F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_hand_r = p_arm_r.addOrReplaceChild("hand_r",
				CubeListBuilder.create().texOffs(112, 176).addBox(-3F, 21F, -3F, 6F, 3F, 6F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_finger0_r = p_arm_r.addOrReplaceChild("finger0_r",
				CubeListBuilder.create().texOffs(16, 186).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(-2F, 24F, -1.5F, -0.1F, 0F, 0F));
		PartDefinition p_finger1_r = p_arm_r.addOrReplaceChild("finger1_r",
				CubeListBuilder.create().texOffs(24, 186).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(0F, 24F, -2F, -0.25F, 0F, 0F));
		PartDefinition p_finger2_r = p_arm_r.addOrReplaceChild("finger2_r",
				CubeListBuilder.create().texOffs(32, 186).addBox(-1F, 0F, -1F, 2F, 6F, 2F),
				PartPose.offsetAndRotation(2F, 24F, -1.5F, -0.1F, 0F, 0F));
		PartDefinition p_pauld1_r = p_arm_r.addOrReplaceChild("pauld1_r",
				CubeListBuilder.create().texOffs(0, 136).addBox(-5.5F, -7F, -5.5F, 11F, 4F, 11F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_pauld2_r = p_arm_r.addOrReplaceChild("pauld2_r",
				CubeListBuilder.create().texOffs(200, 151).addBox(-4.5F, -10F, -4.5F, 9F, 3F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_pspike_a_r = p_arm_r.addOrReplaceChild("pspike_a_r",
				CubeListBuilder.create().texOffs(152, 102).addBox(-2F, -13F, -2F, 4F, 13F, 4F),
				PartPose.offsetAndRotation(-1F, -10F, 0F, 0F, 0F, -0.45F));
		PartDefinition p_pspike_b_r = p_arm_r.addOrReplaceChild("pspike_b_r",
				CubeListBuilder.create().texOffs(24, 164).addBox(-1.5F, -9F, -1.5F, 3F, 9F, 3F),
				PartPose.offsetAndRotation(0F, -9F, 3F, -0.5F, 0F, -0.2F));
		PartDefinition p_pspike_c_r = p_arm_r.addOrReplaceChild("pspike_c_r",
				CubeListBuilder.create().texOffs(84, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(-1F, -9F, -3F, 0.4F, 0F, -0.2F));
		PartDefinition p_elbow_r = p_arm_r.addOrReplaceChild("elbow_r",
				CubeListBuilder.create().texOffs(96, 164).addBox(-1.5F, -8F, -1.5F, 3F, 8F, 3F),
				PartPose.offsetAndRotation(-3F, 9F, 0F, -0.3F, 0F, -1.45F));
		PartDefinition p_scepter = p_arm_r.addOrReplaceChild("scepter",
				CubeListBuilder.create().texOffs(0, 0).addBox(-1F, -45F, -1F, 2F, 56F, 2F),
				PartPose.offset(0F, 23F, -6F));
		PartDefinition p_scepter_grip = p_scepter.addOrReplaceChild("scepter_grip",
				CubeListBuilder.create().texOffs(172, 164).addBox(-2F, -3F, -2F, 4F, 6F, 4F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_scepter_guard = p_scepter.addOrReplaceChild("scepter_guard",
				CubeListBuilder.create().texOffs(140, 164).addBox(-4F, -1F, -4F, 8F, 2F, 8F),
				PartPose.offset(0F, -45F, 0F));
		PartDefinition p_scepter_gem = p_scepter.addOrReplaceChild("scepter_gem",
				CubeListBuilder.create().texOffs(48, 102).addBox(-3F, -12F, -3F, 6F, 12F, 6F),
				PartPose.offset(0F, -46F, 0F));
		PartDefinition p_scepter_prong_l = p_scepter.addOrReplaceChild("scepter_prong_l",
				CubeListBuilder.create().texOffs(108, 164).addBox(-1F, -9F, -1F, 2F, 9F, 2F),
				PartPose.offsetAndRotation(4F, -45F, 0F, 0F, 0F, 0.6F));
		PartDefinition p_scepter_prong_r = p_scepter.addOrReplaceChild("scepter_prong_r",
				CubeListBuilder.create().texOffs(116, 164).addBox(-1F, -9F, -1F, 2F, 9F, 2F),
				PartPose.offsetAndRotation(-4F, -45F, 0F, 0F, 0F, -0.6F));
		PartDefinition p_scepter_prong_f = p_scepter.addOrReplaceChild("scepter_prong_f",
				CubeListBuilder.create().texOffs(124, 164).addBox(-1F, -9F, -1F, 2F, 9F, 2F),
				PartPose.offsetAndRotation(0F, -45F, -4F, 0.6F, 0F, 0F));
		PartDefinition p_scepter_prong_b = p_scepter.addOrReplaceChild("scepter_prong_b",
				CubeListBuilder.create().texOffs(132, 164).addBox(-1F, -9F, -1F, 2F, 9F, 2F),
				PartPose.offsetAndRotation(0F, -45F, 4F, -0.6F, 0F, 0F));
		PartDefinition p_leg_l = root.addOrReplaceChild("leg_l",
				CubeListBuilder.create().texOffs(188, 0).addBox(-3.5F, 0F, -3.5F, 7F, 20F, 7F),
				PartPose.offset(5F, 4F, 0F));
		PartDefinition p_thigh_l = p_leg_l.addOrReplaceChild("thigh_l",
				CubeListBuilder.create().texOffs(174, 83).addBox(-4.5F, 0F, -4.5F, 9F, 9F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_cuff_l = p_leg_l.addOrReplaceChild("cuff_l",
				CubeListBuilder.create().texOffs(148, 136).addBox(-5F, 13F, -5F, 10F, 3F, 10F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_boot_l = p_leg_l.addOrReplaceChild("boot_l",
				CubeListBuilder.create().texOffs(0, 120).addBox(-4.5F, 15F, -6.5F, 9F, 5F, 11F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_knee_l = p_leg_l.addOrReplaceChild("knee_l",
				CubeListBuilder.create().texOffs(210, 176).addBox(-1.5F, -1.5F, -5F, 3F, 3F, 5F),
				PartPose.offsetAndRotation(0F, 11F, -4.5F, 0.4F, 0F, 0F));
		PartDefinition p_toe_l = p_leg_l.addOrReplaceChild("toe_l",
				CubeListBuilder.create().texOffs(112, 186).addBox(-1.5F, 0F, -5F, 3F, 2F, 5F),
				PartPose.offsetAndRotation(0F, 17F, -6.5F, -0.2F, 0F, 0F));
		PartDefinition p_leg_r = root.addOrReplaceChild("leg_r",
				CubeListBuilder.create().texOffs(216, 0).addBox(-3.5F, 0F, -3.5F, 7F, 20F, 7F),
				PartPose.offset(-5F, 4F, 0F));
		PartDefinition p_thigh_r = p_leg_r.addOrReplaceChild("thigh_r",
				CubeListBuilder.create().texOffs(210, 83).addBox(-4.5F, 0F, -4.5F, 9F, 9F, 9F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_cuff_r = p_leg_r.addOrReplaceChild("cuff_r",
				CubeListBuilder.create().texOffs(188, 136).addBox(-5F, 13F, -5F, 10F, 3F, 10F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_boot_r = p_leg_r.addOrReplaceChild("boot_r",
				CubeListBuilder.create().texOffs(40, 120).addBox(-4.5F, 15F, -6.5F, 9F, 5F, 11F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_knee_r = p_leg_r.addOrReplaceChild("knee_r",
				CubeListBuilder.create().texOffs(226, 176).addBox(-1.5F, -1.5F, -5F, 3F, 3F, 5F),
				PartPose.offsetAndRotation(0F, 11F, -4.5F, 0.4F, 0F, 0F));
		PartDefinition p_toe_r = p_leg_r.addOrReplaceChild("toe_r",
				CubeListBuilder.create().texOffs(128, 186).addBox(-1.5F, 0F, -5F, 3F, 2F, 5F),
				PartPose.offsetAndRotation(0F, 17F, -6.5F, -0.2F, 0F, 0F));
		PartDefinition p_cape = root.addOrReplaceChild("cape",
				CubeListBuilder.create().texOffs(56, 0).addBox(-8F, 0F, 0F, 16F, 30F, 2F),
				PartPose.offsetAndRotation(0F, -15F, 6.5F, 0.08F, 0F, 0F));
		PartDefinition p_cape_hem = p_cape.addOrReplaceChild("cape_hem",
				CubeListBuilder.create().texOffs(166, 176).addBox(-9F, 0F, -1F, 18F, 4F, 4F),
				PartPose.offset(0F, 28F, 0F));
		PartDefinition p_cape_mantle = p_cape.addOrReplaceChild("cape_mantle",
				CubeListBuilder.create().texOffs(44, 176).addBox(-9F, -1F, -1F, 18F, 5F, 4F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_wing_l = root.addOrReplaceChild("wing_l",
				CubeListBuilder.create(),
				PartPose.offsetAndRotation(4F, -13F, 9F, 0F, -0.55F, 0F));
		PartDefinition p_wroot_l = p_wing_l.addOrReplaceChild("wroot_l",
				CubeListBuilder.create().texOffs(44, 136).addBox(-3.5F, -3.5F, -3.5F, 7F, 7F, 7F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_wb0_l = p_wing_l.addOrReplaceChild("wb0_l",
				CubeListBuilder.create().texOffs(202, 58).addBox(-1.5F, -20F, -1F, 3F, 20F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, 0.9599F));
		PartDefinition p_wb1_l = p_wing_l.addOrReplaceChild("wb1_l",
				CubeListBuilder.create().texOffs(244, 0).addBox(-1.5F, -23F, -1F, 3F, 23F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, 1.3963F));
		PartDefinition p_wb2_l = p_wing_l.addOrReplaceChild("wb2_l",
				CubeListBuilder.create().texOffs(58, 58).addBox(-1.5F, -22F, -1F, 3F, 22F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, 1.8326F));
		PartDefinition p_wb3_l = p_wing_l.addOrReplaceChild("wb3_l",
				CubeListBuilder.create().texOffs(28, 83).addBox(-1.5F, -17F, -1F, 3F, 17F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, 2.2689F));
		PartDefinition p_wf0_l = p_wing_l.addOrReplaceChild("wf0_l",
				CubeListBuilder.create().texOffs(92, 0).addBox(-2F, -30F, -1F, 4F, 30F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 0.733F));
		PartDefinition p_wf1_l = p_wing_l.addOrReplaceChild("wf1_l",
				CubeListBuilder.create().texOffs(8, 0).addBox(-2F, -36F, -1F, 4F, 36F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 1.1519F));
		PartDefinition p_wf2_l = p_wing_l.addOrReplaceChild("wf2_l",
				CubeListBuilder.create().texOffs(32, 0).addBox(-2F, -34F, -1F, 4F, 34F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 1.6057F));
		PartDefinition p_wf3_l = p_wing_l.addOrReplaceChild("wf3_l",
				CubeListBuilder.create().texOffs(164, 0).addBox(-2F, -28F, -1F, 4F, 28F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 2.0595F));
		PartDefinition p_wf4_l = p_wing_l.addOrReplaceChild("wf4_l",
				CubeListBuilder.create().texOffs(178, 58).addBox(-2F, -20F, -1F, 4F, 20F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, 2.4435F));
		PartDefinition p_wing_r = root.addOrReplaceChild("wing_r",
				CubeListBuilder.create(),
				PartPose.offsetAndRotation(-4F, -13F, 9F, 0F, 0.55F, 0F));
		PartDefinition p_wroot_r = p_wing_r.addOrReplaceChild("wroot_r",
				CubeListBuilder.create().texOffs(72, 136).addBox(-3.5F, -3.5F, -3.5F, 7F, 7F, 7F),
				PartPose.offset(0F, 0F, 0F));
		PartDefinition p_wb0_r = p_wing_r.addOrReplaceChild("wb0_r",
				CubeListBuilder.create().texOffs(212, 58).addBox(-1.5F, -20F, -1F, 3F, 20F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, -0.9599F));
		PartDefinition p_wb1_r = p_wing_r.addOrReplaceChild("wb1_r",
				CubeListBuilder.create().texOffs(0, 58).addBox(-1.5F, -23F, -1F, 3F, 23F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, -1.3963F));
		PartDefinition p_wb2_r = p_wing_r.addOrReplaceChild("wb2_r",
				CubeListBuilder.create().texOffs(68, 58).addBox(-1.5F, -22F, -1F, 3F, 22F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, -1.8326F));
		PartDefinition p_wb3_r = p_wing_r.addOrReplaceChild("wb3_r",
				CubeListBuilder.create().texOffs(38, 83).addBox(-1.5F, -17F, -1F, 3F, 17F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 3F, 0F, 0F, -2.2689F));
		PartDefinition p_wf0_r = p_wing_r.addOrReplaceChild("wf0_r",
				CubeListBuilder.create().texOffs(104, 0).addBox(-2F, -30F, -1F, 4F, 30F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, -0.733F));
		PartDefinition p_wf1_r = p_wing_r.addOrReplaceChild("wf1_r",
				CubeListBuilder.create().texOffs(20, 0).addBox(-2F, -36F, -1F, 4F, 36F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, -1.1519F));
		PartDefinition p_wf2_r = p_wing_r.addOrReplaceChild("wf2_r",
				CubeListBuilder.create().texOffs(44, 0).addBox(-2F, -34F, -1F, 4F, 34F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, -1.6057F));
		PartDefinition p_wf3_r = p_wing_r.addOrReplaceChild("wf3_r",
				CubeListBuilder.create().texOffs(176, 0).addBox(-2F, -28F, -1F, 4F, 28F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, -2.0595F));
		PartDefinition p_wf4_r = p_wing_r.addOrReplaceChild("wf4_r",
				CubeListBuilder.create().texOffs(190, 58).addBox(-2F, -20F, -1F, 4F, 20F, 2F),
				PartPose.offsetAndRotation(0F, 0F, 0F, 0F, 0F, -2.4435F));
		PartDefinition p_halo = root.addOrReplaceChild("halo",
				CubeListBuilder.create(),
				PartPose.offset(0F, -25F, 11F));
		PartDefinition p_halo_seg0 = p_halo.addOrReplaceChild("halo_seg0",
				CubeListBuilder.create().texOffs(188, 186).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offset(0F, -12F, 0F));
		PartDefinition p_halo_ray0 = p_halo.addOrReplaceChild("halo_ray0",
				CubeListBuilder.create().texOffs(134, 151).addBox(-1.5F, -11F, -1F, 3F, 11F, 2F),
				PartPose.offset(0F, -12F, 0F));
		PartDefinition p_halo_seg1 = p_halo.addOrReplaceChild("halo_seg1",
				CubeListBuilder.create().texOffs(202, 186).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(6F, -10.3923F, 0F, 0F, 0F, 0.5236F));
		PartDefinition p_halo_seg2 = p_halo.addOrReplaceChild("halo_seg2",
				CubeListBuilder.create().texOffs(216, 186).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(10.3923F, -6F, 0F, 0F, 0F, 1.0472F));
		PartDefinition p_halo_ray2 = p_halo.addOrReplaceChild("halo_ray2",
				CubeListBuilder.create().texOffs(136, 176).addBox(-1.5F, -7F, -1F, 3F, 7F, 2F),
				PartPose.offsetAndRotation(10.3923F, -6F, 0F, 0F, 0F, 1.0472F));
		PartDefinition p_halo_seg3 = p_halo.addOrReplaceChild("halo_seg3",
				CubeListBuilder.create().texOffs(230, 186).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(12F, 0F, 0F, 0F, 0F, 1.5708F));
		PartDefinition p_halo_seg4 = p_halo.addOrReplaceChild("halo_seg4",
				CubeListBuilder.create().texOffs(0, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(10.3923F, 6F, 0F, 0F, 0F, 2.0944F));
		PartDefinition p_halo_ray4 = p_halo.addOrReplaceChild("halo_ray4",
				CubeListBuilder.create().texOffs(144, 151).addBox(-1.5F, -11F, -1F, 3F, 11F, 2F),
				PartPose.offsetAndRotation(10.3923F, 6F, 0F, 0F, 0F, 2.0944F));
		PartDefinition p_halo_seg5 = p_halo.addOrReplaceChild("halo_seg5",
				CubeListBuilder.create().texOffs(14, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(6F, 10.3923F, 0F, 0F, 0F, 2.618F));
		PartDefinition p_halo_seg6 = p_halo.addOrReplaceChild("halo_seg6",
				CubeListBuilder.create().texOffs(28, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(0F, 12F, 0F, 0F, 0F, 3.1416F));
		PartDefinition p_halo_ray6 = p_halo.addOrReplaceChild("halo_ray6",
				CubeListBuilder.create().texOffs(146, 176).addBox(-1.5F, -7F, -1F, 3F, 7F, 2F),
				PartPose.offsetAndRotation(0F, 12F, 0F, 0F, 0F, 3.1416F));
		PartDefinition p_halo_seg7 = p_halo.addOrReplaceChild("halo_seg7",
				CubeListBuilder.create().texOffs(42, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(-6F, 10.3923F, 0F, 0F, 0F, 3.6652F));
		PartDefinition p_halo_seg8 = p_halo.addOrReplaceChild("halo_seg8",
				CubeListBuilder.create().texOffs(56, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(-10.3923F, 6F, 0F, 0F, 0F, 4.1888F));
		PartDefinition p_halo_ray8 = p_halo.addOrReplaceChild("halo_ray8",
				CubeListBuilder.create().texOffs(154, 151).addBox(-1.5F, -11F, -1F, 3F, 11F, 2F),
				PartPose.offsetAndRotation(-10.3923F, 6F, 0F, 0F, 0F, 4.1888F));
		PartDefinition p_halo_seg9 = p_halo.addOrReplaceChild("halo_seg9",
				CubeListBuilder.create().texOffs(70, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(-12F, 0F, 0F, 0F, 0F, 4.7124F));
		PartDefinition p_halo_seg10 = p_halo.addOrReplaceChild("halo_seg10",
				CubeListBuilder.create().texOffs(84, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(-10.3923F, -6F, 0F, 0F, 0F, 5.236F));
		PartDefinition p_halo_ray10 = p_halo.addOrReplaceChild("halo_ray10",
				CubeListBuilder.create().texOffs(156, 176).addBox(-1.5F, -7F, -1F, 3F, 7F, 2F),
				PartPose.offsetAndRotation(-10.3923F, -6F, 0F, 0F, 0F, 5.236F));
		PartDefinition p_halo_seg11 = p_halo.addOrReplaceChild("halo_seg11",
				CubeListBuilder.create().texOffs(98, 194).addBox(-2.5F, -2F, -1F, 5F, 4F, 2F),
				PartPose.offsetAndRotation(-6F, -10.3923F, 0F, 0F, 0F, 5.7596F));
		PartDefinition p_orbit = root.addOrReplaceChild("orbit",
				CubeListBuilder.create(),
				PartPose.offset(0F, -6F, 0F));
		PartDefinition p_shard0 = p_orbit.addOrReplaceChild("shard0",
				CubeListBuilder.create().texOffs(80, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(24F, -9F, 0F, 0.35F, -1.5708F, 0F));
		PartDefinition p_shard1 = p_orbit.addOrReplaceChild("shard1",
				CubeListBuilder.create().texOffs(96, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(12F, 5F, 20.7846F, 0.35F, -2.618F, 0F));
		PartDefinition p_shard2 = p_orbit.addOrReplaceChild("shard2",
				CubeListBuilder.create().texOffs(112, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(-12F, -9F, 20.7846F, 0.35F, 2.618F, 0F));
		PartDefinition p_shard3 = p_orbit.addOrReplaceChild("shard3",
				CubeListBuilder.create().texOffs(128, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(-24F, 5F, 0F, 0.35F, 1.5708F, 0F));
		PartDefinition p_shard4 = p_orbit.addOrReplaceChild("shard4",
				CubeListBuilder.create().texOffs(144, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(-12F, -9F, -20.7846F, 0.35F, 0.5236F, 0F));
		PartDefinition p_shard5 = p_orbit.addOrReplaceChild("shard5",
				CubeListBuilder.create().texOffs(160, 120).addBox(-2F, -6F, -2F, 4F, 12F, 4F),
				PartPose.offsetAndRotation(12F, 5F, -20.7846F, 0.35F, -0.5236F, 0F));
		PartDefinition p_floor0 = root.addOrReplaceChild("floor0",
				CubeListBuilder.create().texOffs(44, 151).addBox(-2F, -9F, -2F, 4F, 9F, 4F),
				PartPose.offsetAndRotation(15.706F, 24F, 6.5056F, 0.4F, -1.9635F, 0F));
		PartDefinition p_floor1 = root.addOrReplaceChild("floor1",
				CubeListBuilder.create().texOffs(188, 164).addBox(-2F, -6F, -2F, 4F, 6F, 4F),
				PartPose.offsetAndRotation(6.5056F, 24F, 15.706F, 0.4F, -2.7489F, 0F));
		PartDefinition p_floor2 = root.addOrReplaceChild("floor2",
				CubeListBuilder.create().texOffs(60, 151).addBox(-2F, -9F, -2F, 4F, 9F, 4F),
				PartPose.offsetAndRotation(-6.5056F, 24F, 15.706F, 0.4F, 2.7489F, 0F));
		PartDefinition p_floor3 = root.addOrReplaceChild("floor3",
				CubeListBuilder.create().texOffs(204, 164).addBox(-2F, -6F, -2F, 4F, 6F, 4F),
				PartPose.offsetAndRotation(-15.706F, 24F, 6.5056F, 0.4F, 1.9635F, 0F));
		PartDefinition p_floor4 = root.addOrReplaceChild("floor4",
				CubeListBuilder.create().texOffs(76, 151).addBox(-2F, -9F, -2F, 4F, 9F, 4F),
				PartPose.offsetAndRotation(-15.706F, 24F, -6.5056F, 0.4F, 1.1781F, 0F));
		PartDefinition p_floor5 = root.addOrReplaceChild("floor5",
				CubeListBuilder.create().texOffs(220, 164).addBox(-2F, -6F, -2F, 4F, 6F, 4F),
				PartPose.offsetAndRotation(-6.5056F, 24F, -15.706F, 0.4F, 0.3927F, 0F));
		PartDefinition p_floor6 = root.addOrReplaceChild("floor6",
				CubeListBuilder.create().texOffs(92, 151).addBox(-2F, -9F, -2F, 4F, 9F, 4F),
				PartPose.offsetAndRotation(6.5056F, 24F, -15.706F, 0.4F, -0.3927F, 0F));
		PartDefinition p_floor7 = root.addOrReplaceChild("floor7",
				CubeListBuilder.create().texOffs(236, 164).addBox(-2F, -6F, -2F, 4F, 6F, 4F),
				PartPose.offsetAndRotation(15.706F, 24F, -6.5056F, 0.4F, -1.1781F, 0F));

		return LayerDefinition.create(mesh, 256, 256);
	}

	@Override
	public void setupAnim(IceMonsterRenderState state) {
		super.setupAnim(state);

		float walkPos = state.walkAnimationPos;
		float walkSpeed = Math.min(state.walkAnimationSpeed, 1.0F);
		float age = state.ageInTicks;

		// Look direction
		this.head.yRot = state.yRot * Mth.DEG_TO_RAD;
		this.head.xRot = state.xRot * Mth.DEG_TO_RAD;

		// Smooth, regal walk (the right arm holds the scepter, so it swings less)
		this.rightLeg.xRot = Mth.cos(walkPos * 0.5F) * 1.0F * walkSpeed;
		this.leftLeg.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 1.0F * walkSpeed;
		this.rightArm.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 0.25F * walkSpeed;
		this.leftArm.xRot = Mth.cos(walkPos * 0.5F) * 0.6F * walkSpeed;
		this.body.yRot = Mth.cos(walkPos * 0.5F) * 0.05F * walkSpeed;

		// Idle breathing
		this.rightArm.zRot = -0.05F - Mth.sin(age * 0.07F) * 0.03F;
		this.leftArm.zRot = 0.05F + Mth.sin(age * 0.07F) * 0.03F;

		// Cape billows when he moves
		this.cape.xRot += walkSpeed * 0.35F + Mth.sin(age * 0.05F) * 0.03F;

		// Slow crystal wing beat
		float flap = Mth.sin(age * 0.09F) * 0.10F;
		this.rightWing.zRot += flap;
		this.leftWing.zRot -= flap;
		this.rightWing.yRot += flap * 0.6F;
		this.leftWing.yRot -= flap * 0.6F;

		// Halo turns, shards orbit and bob
		this.halo.zRot += age * 0.02F;
		this.orbit.yRot += age * 0.035F;
		this.orbit.y += Mth.sin(age * 0.06F) * 2.0F;
	}
}
