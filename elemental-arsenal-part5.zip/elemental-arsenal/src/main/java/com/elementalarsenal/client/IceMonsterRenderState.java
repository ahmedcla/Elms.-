package com.elementalarsenal.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class IceMonsterRenderState extends LivingEntityRenderState {
}
