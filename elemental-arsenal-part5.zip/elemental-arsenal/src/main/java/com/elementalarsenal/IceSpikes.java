package com.elementalarsenal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The glacial spikes of the {@link IceMonster}: tall crystal spires that burst out of the ground, hold for a moment
 * and sink back, like the fangs of an Evoker. They are only a visual (an item_display entity wearing the
 * elementalarsenal:ice_spike model), so nothing about them is solid or can be touched; the damage is dealt by this
 * class to everybody standing in the spike when it bursts out.
 */
public final class IceSpikes {
	private IceSpikes() {
	}

	public static final String TAG = "ea_ice_spike";

	// ticks after the spike is due
	private static final int EMERGE = 1;
	private static final int STRIKE = 2;
	private static final int RETRACT = 16;
	private static final int REMOVE = 21;

	private static final class Spike {
		final ServerLevel level;
		final IceMonster owner;
		final Set<LivingEntity> hit;
		final double x, y, z;
		final float sx, sy, yaw;
		final int due;
		final UUID id = UUID.randomUUID();

		Spike(ServerLevel level, IceMonster owner, Set<LivingEntity> hit, Vec3 pos, float sx, float sy, float yaw, int due) {
			this.level = level;
			this.owner = owner;
			this.hit = hit;
			this.x = pos.x;
			this.y = pos.y;
			this.z = pos.z;
			this.sx = sx;
			this.sy = sy;
			this.yaw = yaw;
			this.due = due;
		}
	}

	private static final List<Spike> ACTIVE = new ArrayList<>();

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(IceSpikes::tick);
		ServerLifecycleEvents.SERVER_STARTED.register(server -> killAll(server));
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			killAll(server);
			ACTIVE.clear();
		});
	}

	/** Schedules a spike at pos (ground level) that bursts out after delayTicks. hit = victims already struck by this attack. */
	public static void queue(ServerLevel level, IceMonster owner, Set<LivingEntity> hit, Vec3 pos, int delayTicks) {
		// no spikes inside walls: a spike whose cell is solid is skipped
		net.minecraft.core.BlockPos cell = net.minecraft.core.BlockPos.containing(pos.x, pos.y + 0.5D, pos.z);
		if (!level.getBlockState(cell).getCollisionShape(level, cell).isEmpty()) {
			return;
		}
		float sy = 2.0F + level.getRandom().nextFloat() * 1.0F;     // height = 1.25 * sy  ->  2.5 .. 3.75 blocks
		float sx = 1.7F + level.getRandom().nextFloat() * 0.8F;
		float yaw = level.getRandom().nextFloat() * 360.0F;
		ACTIVE.add(new Spike(level, owner, hit, pos, sx, sy, yaw, level.getServer().getTickCount() + delayTicks));
	}

	private static void tick(MinecraftServer server) {
		if (ACTIVE.isEmpty()) {
			return;
		}
		int now = server.getTickCount();
		Iterator<Spike> it = ACTIVE.iterator();
		while (it.hasNext()) {
			Spike s = it.next();
			int age = now - s.due;
			if (age < 0) {
				continue;
			}
			if (age == 0) {
				summon(server, s);
			} else if (age == EMERGE) {
				command(server, s.level, "data merge entity " + s.id + " {start_interpolation:0,interpolation_duration:3,transformation:"
						+ transform(s.sx, s.sy) + "}");
			} else if (age == STRIKE) {
				strike(s);
			} else if (age == RETRACT) {
				command(server, s.level, "data merge entity " + s.id + " {start_interpolation:0,interpolation_duration:4,transformation:"
						+ transform(s.sx, 0.02F) + "}");
			} else if (age >= REMOVE) {
				command(server, s.level, "kill " + s.id);
				it.remove();
			}
		}
	}

	private static void summon(MinecraftServer server, Spike s) {
		long most = s.id.getMostSignificantBits();
		long least = s.id.getLeastSignificantBits();
		String cmd = String.format(Locale.ROOT,
				"summon minecraft:item_display %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],Rotation:[%.1ff,0.0f],Tags:[\"%s\"],"
						+ "item:{id:\"minecraft:stick\",count:1,components:{\"minecraft:item_model\":\"elementalarsenal:ice_spike\"}},"
						+ "item_display:\"none\",interpolation_duration:3,transformation:%s}",
				s.x, s.y, s.z, (int) (most >> 32), (int) most, (int) (least >> 32), (int) least, s.yaw, TAG,
				transform(s.sx, 0.02F));
		command(server, s.level, cmd);
		s.level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PACKED_ICE.defaultBlockState()),
				s.x, s.y + 0.2D, s.z, 14, 0.5D, 0.2D, 0.5D, 0.12D);
		s.level.sendParticles(ParticleTypes.SNOWFLAKE, s.x, s.y + 0.3D, s.z, 10, 0.5D, 0.3D, 0.5D, 0.05D);
		s.level.playSound(null, s.x, s.y, s.z, SoundEvents.GLASS_BREAK, SoundSource.HOSTILE, 1.2F, 0.6F);
	}

	private static void strike(Spike s) {
		s.level.sendParticles(ParticleTypes.SNOWFLAKE, s.x, s.y + 1.5D, s.z, 16, 0.5D, 1.2D, 0.5D, 0.03D);
		if (!s.owner.isAlive()) {
			return;
		}
		AABB box = new AABB(s.x - 1.6D, s.y - 1.0D, s.z - 1.6D, s.x + 1.6D, s.y + 3.5D, s.z + 1.6D);
		for (LivingEntity e : s.level.getEntitiesOfClass(LivingEntity.class, box,
				v -> v != s.owner && v.isAlive() && !(v instanceof Enemy))) {
			double dx = e.getX() - s.x;
			double dz = e.getZ() - s.z;
			if (dx * dx + dz * dz <= 1.5D * 1.5D && s.hit.add(e)) {
				IceMonster.frostHit(s.level, s.owner, e, IceMonster.SPECIAL_DAMAGE);
				e.setDeltaMovement(e.getDeltaMovement().add(0.0D, 0.5D, 0.0D));
			}
		}
	}

	/** Unit scale of the model is 1.25 blocks tall; translation lifts it so that its base sits on the entity's position. */
	private static String transform(float sx, float sy) {
		return String.format(Locale.ROOT,
				"{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[%.3ff,%.3ff,%.3ff],translation:[0f,%.3ff,0f]}",
				sx, sy, sx, sy * 0.5F);
	}

	private static void killAll(MinecraftServer server) {
		command(server, null, "kill @e[type=minecraft:item_display,tag=" + TAG + "]");
	}

	private static void command(MinecraftServer server, ServerLevel level, String command) {
		var source = server.createCommandSourceStack();
		if (level != null) {
			source = source.withLevel(level);
		}
		server.getCommands().performPrefixedCommand(source.withSuppressedOutput(), command);
	}
}
