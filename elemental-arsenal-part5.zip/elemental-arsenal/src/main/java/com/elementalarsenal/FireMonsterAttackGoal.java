package com.elementalarsenal;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The three special attacks of the {@link FireMonster}. While one runs the monster stands still and
 * shows a clear particle warning first, so every attack can be dodged:
 * <ul>
 *   <li><b>Magma Nova</b> - spirals of fire gather, then a ring of flames expands (jump over it).</li>
 *   <li><b>Flame Lance</b> - a thin warning line, then a long beam of fire (sidestep it).</li>
 *   <li><b>Eruption</b> - fire circles mark the ground, then fire pillars erupt (leave the circles).</li>
 * </ul>
 */
public class FireMonsterAttackGoal extends Goal {
	private static final int NOVA = 0;
	private static final int LANCE = 1;
	private static final int ERUPTION = 2;

	// Damage values (health points, 2 = 1 heart)
	private static final float NOVA_DAMAGE = 16.0F;
	private static final float LANCE_DAMAGE = 14.0F;
	private static final float ERUPTION_DAMAGE = 14.0F;

	private final FireMonster mob;
	private int attack;
	private int tick;
	private int duration;

	// Lance
	private Vec3 lanceOrigin = Vec3.ZERO;
	private Vec3 lanceDir = new Vec3(0, 0, 1);
	private double lanceLength = 24.0D;

	// Eruption
	private final List<Vec3> spots = new ArrayList<>();

	// Entities already hit by the current attack
	private final Set<LivingEntity> hit = new HashSet<>();

	public FireMonsterAttackGoal(FireMonster mob) {
		this.mob = mob;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		LivingEntity target = this.mob.getTarget();
		return target != null && target.isAlive() && this.mob.isSpecialReady()
				&& this.mob.distanceToSqr(target) < 28.0D * 28.0D
				&& this.mob.hasLineOfSight(target);
	}

	@Override
	public boolean canContinueToUse() {
		LivingEntity target = this.mob.getTarget();
		return target != null && target.isAlive() && this.tick < this.duration;
	}

	@Override
	public void start() {
		LivingEntity target = this.mob.getTarget();
		double dist = target == null ? 0.0D : this.mob.distanceTo(target);
		int roll = this.mob.getRandom().nextInt(100);
		if (dist <= 8.0D) {
			this.attack = roll < 55 ? NOVA : (roll < 80 ? ERUPTION : LANCE);
		} else {
			this.attack = roll < 55 ? LANCE : (roll < 90 ? ERUPTION : NOVA);
		}
		this.tick = 0;
		this.hit.clear();
		this.spots.clear();
		this.mob.getNavigation().stop();

		switch (this.attack) {
			case NOVA -> {
				this.duration = 56;
				this.mob.setAttackState(FireMonster.STATE_NOVA);
			}
			case LANCE -> {
				this.duration = 46;
				this.mob.setAttackState(FireMonster.STATE_LANCE);
			}
			default -> {
				this.duration = 62;
				this.mob.setAttackState(FireMonster.STATE_ERUPTION);
				this.pickEruptionSpots(target);
			}
		}
		this.mob.playSound(SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 0.6F);
	}

	@Override
	public void stop() {
		this.mob.setAttackState(FireMonster.STATE_IDLE);
		this.mob.setSpecialCooldown(70 + this.mob.getRandom().nextInt(50));
		this.hit.clear();
		this.spots.clear();
	}

	@Override
	public void tick() {
		if (!(this.mob.level() instanceof ServerLevel level)) {
			return;
		}
		LivingEntity target = this.mob.getTarget();
		if (target != null && this.attack != ERUPTION) {
			this.mob.getLookControl().setLookAt(target, 40.0F, 40.0F);
		}
		this.mob.getNavigation().stop();

		switch (this.attack) {
			case NOVA -> this.tickNova(level);
			case LANCE -> this.tickLance(level, target);
			default -> this.tickEruption(level);
		}
		this.tick++;
	}

	// ================================================================== MAGMA NOVA

	private static final int NOVA_CHARGE = 30;

	private void tickNova(ServerLevel level) {
		double x = this.mob.getX();
		double y = this.mob.getY();
		double z = this.mob.getZ();

		if (this.tick < NOVA_CHARGE) {
			// Four flame spirals converging on the chest while the arms are raised
			float progress = this.tick / (float) NOVA_CHARGE;
			double radius = 4.5D * (1.0D - progress) + 0.6D;
			for (int i = 0; i < 4; i++) {
				double angle = this.tick * 0.45D + i * (Math.PI / 2.0D);
				double height = 0.3D + progress * 2.4D;
				level.sendParticles(ParticleTypes.FLAME,
						x + Math.cos(angle) * radius, y + height, z + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
				level.sendParticles(ParticleTypes.SMALL_FLAME,
						x + Math.cos(angle + 0.5D) * radius, y + height + 0.3D, z + Math.sin(angle + 0.5D) * radius,
						1, 0, 0, 0, 0);
			}
			level.sendParticles(ParticleTypes.LAVA, x, y + 2.7D, z, 1, 0.4D, 0.3D, 0.4D, 0);
			if (this.tick % 8 == 0) {
				this.mob.playSound(SoundEvents.FIRECHARGE_USE, 2.0F, 0.5F + progress);
			}
			return;
		}

		int step = this.tick - NOVA_CHARGE;
		if (step == 0) {
			this.mob.playSound(SoundEvents.BLAZE_SHOOT, 3.0F, 0.5F);
			this.mob.playSound(SoundEvents.ENDER_DRAGON_GROWL, 2.5F, 1.0F);
			level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1.0D, z, 1, 0, 0, 0, 0);
		}
		// The ring expands 0.55 blocks per tick up to ~11 blocks
		double radius = 1.5D + step * 0.55D;
		int points = Math.max(24, (int) (radius * 9));
		for (int i = 0; i < points; i++) {
			double angle = (Math.PI * 2.0D) * i / points;
			double px = x + Math.cos(angle) * radius;
			double pz = z + Math.sin(angle) * radius;
			level.sendParticles(ParticleTypes.FLAME, px, y + 0.15D, pz, 1, 0.0D, 0.15D, 0.0D, 0.04D);
			if (i % 3 == 0) {
				level.sendParticles(ParticleTypes.LARGE_SMOKE, px, y + 0.4D, pz, 1, 0.1D, 0.2D, 0.1D, 0.01D);
			}
			if (i % 7 == 0) {
				level.sendParticles(ParticleTypes.LAVA, px, y + 0.5D, pz, 1, 0.1D, 0.1D, 0.1D, 0.0D);
			}
		}

		AABB area = new AABB(x - radius - 1.5D, y - 1.0D, z - radius - 1.5D, x + radius + 1.5D, y + 4.0D, z + radius + 1.5D);
		for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, this::isVictim)) {
			if (this.hit.contains(e)) {
				continue;
			}
			double dx = e.getX() - x;
			double dz = e.getZ() - z;
			double dist = Math.sqrt(dx * dx + dz * dz);
			// The ring is low: jumping over it avoids the damage
			if (Math.abs(dist - radius) <= 1.4D && e.getY() < y + 1.2D) {
				this.hit.add(e);
				this.damage(level, e, NOVA_DAMAGE, 5.0F);
				e.knockback(1.3D, -dx, -dz);
				e.setDeltaMovement(e.getDeltaMovement().add(0.0D, 0.45D, 0.0D));
			}
		}
	}

	// ================================================================== FLAME LANCE

	private static final int LANCE_LOCK = 22;
	private static final int LANCE_FIRE = 26;

	private void tickLance(ServerLevel level, LivingEntity target) {
		if (this.tick < LANCE_LOCK) {
			// Still tracking the target
			if (target != null) {
				this.aimLance(level, target);
			}
			// Gathering sparks at the fists
			Vec3 o = this.lanceOrigin;
			level.sendParticles(ParticleTypes.FLAME, o.x, o.y, o.z, 3, 0.35D, 0.35D, 0.35D, 0.02D);
			if (this.tick > 8) {
				this.drawLance(level, ParticleTypes.SMALL_FLAME, 1.4D, 0.05D);
			}
			return;
		}
		if (this.tick < LANCE_FIRE) {
			// Locked: a bright warning line, no more tracking
			this.drawLance(level, ParticleTypes.SMALL_FLAME, 0.7D, 0.0D);
			if (this.tick == LANCE_FIRE - 1) {
				this.mob.playSound(SoundEvents.BLAZE_SHOOT, 3.0F, 0.6F);
			}
			return;
		}
		// Firing
		this.drawLance(level, ParticleTypes.FLAME, 0.45D, 0.03D);
		this.drawLance(level, ParticleTypes.LARGE_SMOKE, 1.5D, 0.02D);
		if (this.tick == LANCE_FIRE + 1) {
			this.mob.playSound(SoundEvents.GHAST_SHOOT, 3.0F, 0.5F);
			level.sendParticles(ParticleTypes.EXPLOSION, this.lanceOrigin.x, this.lanceOrigin.y, this.lanceOrigin.z,
					1, 0, 0, 0, 0);
			AABB box = new AABB(this.lanceOrigin, this.lanceOrigin.add(this.lanceDir.scale(this.lanceLength))).inflate(1.4D);
			for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isVictim)) {
				Vec3 p = e.position().add(0.0D, e.getBbHeight() * 0.5D, 0.0D);
				Vec3 rel = p.subtract(this.lanceOrigin);
				double along = rel.dot(this.lanceDir);
				if (along < 0.0D || along > this.lanceLength) {
					continue;
				}
				double off = rel.subtract(this.lanceDir.scale(along)).length();
				if (off <= 1.5D) {
					this.damage(level, e, LANCE_DAMAGE, 6.0F);
					e.knockback(0.8D, -this.lanceDir.x, -this.lanceDir.z);
				}
			}
		}
	}

	private void aimLance(ServerLevel level, LivingEntity target) {
		this.lanceOrigin = this.mob.getEyePosition().add(0.0D, -0.4D, 0.0D);
		Vec3 aim = target.position().add(0.0D, target.getBbHeight() * 0.6D, 0.0D);
		this.lanceDir = aim.subtract(this.lanceOrigin).normalize();
		Vec3 end = this.lanceOrigin.add(this.lanceDir.scale(24.0D));
		// The beam stops at the first block in its way
		var hitResult = level.clip(new ClipContext(this.lanceOrigin, end,
				ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this.mob));
		this.lanceLength = hitResult.getLocation().distanceTo(this.lanceOrigin);
	}

	private void drawLance(ServerLevel level, ParticleOptions particle, double spacing, double speed) {
		for (double d = 1.0D; d < this.lanceLength; d += spacing) {
			Vec3 p = this.lanceOrigin.add(this.lanceDir.scale(d));
			level.sendParticles(particle, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, speed);
		}
	}

	// ================================================================== ERUPTION

	private static final int ERUPTION_WARN = 34;

	private void pickEruptionSpots(LivingEntity target) {
		if (target == null) {
			return;
		}
		// One pillar directly under the target's current position, the rest scattered around it
		this.spots.add(this.groundAt(target.position()));
		for (int i = 0; i < 5; i++) {
			double angle = this.mob.getRandom().nextDouble() * Math.PI * 2.0D;
			double dist = 2.5D + this.mob.getRandom().nextDouble() * 5.0D;
			this.spots.add(this.groundAt(target.position().add(Math.cos(angle) * dist, 0.0D, Math.sin(angle) * dist)));
		}
	}

	private Vec3 groundAt(Vec3 pos) {
		BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(pos.x, pos.y + 1.0D, pos.z);
		for (int i = 0; i < 6; i++) {
			BlockPos below = p.below();
			if (!this.mob.level().getBlockState(below).getCollisionShape(this.mob.level(), below).isEmpty()) {
				break;
			}
			p.move(0, -1, 0);
		}
		return new Vec3(pos.x, p.getY(), pos.z);
	}

	private void tickEruption(ServerLevel level) {
		// The monster slams its fists down
		if (this.tick == 4) {
			this.mob.playSound(SoundEvents.IRON_GOLEM_ATTACK, 2.5F, 0.5F);
		}
		if (this.tick >= 6 && this.tick < ERUPTION_WARN) {
			// Warning circles on the ground
			for (Vec3 s : this.spots) {
				double r = 2.2D;
				int points = 20;
				for (int i = 0; i < points; i++) {
					double angle = (Math.PI * 2.0D) * i / points + this.tick * 0.1D;
					level.sendParticles(ParticleTypes.FLAME,
							s.x + Math.cos(angle) * r, s.y + 0.1D, s.z + Math.sin(angle) * r, 1, 0, 0, 0, 0);
				}
				if (this.tick % 4 == 0) {
					level.sendParticles(ParticleTypes.LAVA, s.x, s.y + 0.2D, s.z, 1, 0.8D, 0.0D, 0.8D, 0);
					level.sendParticles(ParticleTypes.SMALL_FLAME, s.x, s.y + 0.1D, s.z, 6, 1.2D, 0.0D, 1.2D, 0.0D);
				}
			}
			return;
		}
		if (this.tick < ERUPTION_WARN) {
			return;
		}
		int step = this.tick - ERUPTION_WARN;
		if (step == 0) {
			this.mob.playSound(SoundEvents.BLAZE_SHOOT, 3.0F, 0.4F);
			for (Vec3 s : this.spots) {
				level.sendParticles(ParticleTypes.EXPLOSION, s.x, s.y + 0.5D, s.z, 1, 0, 0, 0, 0);
			}
			this.mob.playSound(SoundEvents.LAVA_POP, 3.0F, 0.6F);
		}
		if (step < 12) {
			// Pillars rise for 12 ticks
			double top = Math.min(9.0D, 1.5D + step * 1.2D);
			for (Vec3 s : this.spots) {
				for (double h = 0.0D; h <= top; h += 1.0D) {
					level.sendParticles(ParticleTypes.FLAME, s.x, s.y + h, s.z, 5, 0.7D, 0.3D, 0.7D, 0.03D);
				}
				level.sendParticles(ParticleTypes.LAVA, s.x, s.y + top, s.z, 2, 0.5D, 0.3D, 0.5D, 0.0D);
				level.sendParticles(ParticleTypes.LARGE_SMOKE, s.x, s.y + top, s.z, 2, 0.5D, 0.3D, 0.5D, 0.02D);
			}
			if (step == 0 || step == 4) {
				for (Vec3 s : this.spots) {
					AABB box = new AABB(s.x - 2.2D, s.y - 1.0D, s.z - 2.2D, s.x + 2.2D, s.y + 7.0D, s.z + 2.2D);
					for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isVictim)) {
						if (this.hit.add(e)) {
							this.damage(level, e, ERUPTION_DAMAGE, 5.0F);
							e.setDeltaMovement(e.getDeltaMovement().add(0.0D, 0.9D, 0.0D));
						}
					}
				}
			}
		}
	}

	// ================================================================== helpers

	/** Only players and non-hostile creatures are hurt; the monster never hurts other monsters. */
	private boolean isVictim(LivingEntity e) {
		return e != this.mob && e.isAlive() && !(e instanceof Enemy) && !(e instanceof FireMonster);
	}

	private void damage(ServerLevel level, LivingEntity e, float amount, float fireSeconds) {
		e.hurtServer(level, this.mob.damageSources().mobAttack(this.mob), amount);
		e.igniteForSeconds(fireSeconds);
	}
}
