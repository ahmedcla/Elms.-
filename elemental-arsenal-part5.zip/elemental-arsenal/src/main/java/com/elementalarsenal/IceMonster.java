package com.elementalarsenal;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * The Glacial Warlord: the ice boss.
 * He chases players, hits in melee and uses three special attacks (see {@link IceMonsterAttackGoal}) and has an icy boss bar.
 */
public class IceMonster extends Monster {
	/** Max health: 300 hearts = 600 health points. */
	public static final double MAX_HEALTH = 600.0D;
	public static final double MELEE_DAMAGE = 28.0D;

	/** Damage of every special attack: 7 hearts = 14 health points. */
	public static final float SPECIAL_DAMAGE = 14.0F;
	/** Slowness V and Weakness II last 7 seconds. */
	private static final int DEBUFF_TICKS = 140;

	/**
	 * Unique boss bar: the WHITE bar is not used by any vanilla boss, and this mod replaces its sprites
	 * (assets/minecraft/textures/gui/sprites/boss_bar/white_*.png) with a glowing frost bar.
	 */
	private final ServerBossEvent bossEvent = new ServerBossEvent(
			Component.literal("\u2744 ").append(Component.translatable("entity.elementalarsenal.ice_monster"))
					.append(Component.literal(" \u2744")).withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD),
			BossEvent.BossBarColor.WHITE,
			BossEvent.BossBarOverlay.PROGRESS);

	/** Ticks until the next special attack may start. */
	private int specialCooldown = 60;

	/** True while the Warlord is entombed in the ice of the Glacial Citadel (no AI, invulnerable, no boss bar). */
	private boolean frozen;
	/** Seal centre of the citadel he guards; the locked rooms open around it when he dies. */
	private BlockPos home;

	public IceMonster(EntityType<? extends IceMonster> type, Level level) {
		super(type, level);
		this.bossEvent.setDarkenScreen(false);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return Monster.createMonsterAttributes()
				.add(Attributes.MAX_HEALTH, MAX_HEALTH)
				.add(Attributes.ATTACK_DAMAGE, MELEE_DAMAGE)
				.add(Attributes.MOVEMENT_SPEED, 0.28D)
				.add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
				.add(Attributes.FOLLOW_RANGE, 48.0D)
				.add(Attributes.ARMOR, 10.0D)
				.add(Attributes.STEP_HEIGHT, 1.0D);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new IceMonsterAttackGoal(this));
		this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0D, true));
		this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
		this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
	}

	/** Entombs the Warlord in the ice; {@link IceHallTrigger} builds the ice around him. */
	public void freeze(BlockPos home) {
		this.frozen = true;
		this.home = home;
		this.setNoAi(true);
		this.setInvulnerable(true);
		this.setSilent(true);
		this.setPersistenceRequired();
	}

	public boolean isFrozen() {
		return this.frozen;
	}

	/** Breaks the ice: he wakes up, shows his boss bar and goes for the player. */
	public void thaw(ServerPlayer target) {
		this.frozen = false;
		this.setNoAi(false);
		this.setInvulnerable(false);
		this.setSilent(false);
		this.setTarget(target);
		this.specialCooldown = 80;
		if (this.level() instanceof ServerLevel level) {
			for (ServerPlayer player : level.players()) {
				if (player.distanceToSqr(this) < 64.0D * 64.0D) {
					this.bossEvent.addPlayer(player);
				}
			}
		}
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		if (this.home != null && this.level() instanceof ServerLevel level) {
			IceHallTrigger.onWarlordDefeated(level, this.home);
		}
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		super.addAdditionalSaveData(output);
		output.putBoolean("Frozen", this.frozen);
		if (this.home != null) {
			output.putInt("HomeX", this.home.getX());
			output.putInt("HomeY", this.home.getY());
			output.putInt("HomeZ", this.home.getZ());
		}
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		this.frozen = input.getBooleanOr("Frozen", false);
		if (input.getIntOr("HomeY", Integer.MIN_VALUE) != Integer.MIN_VALUE) {
			this.home = new BlockPos(input.getIntOr("HomeX", 0), input.getIntOr("HomeY", 0), input.getIntOr("HomeZ", 0));
		}
	}

	@Override
	public void startSeenByPlayer(ServerPlayer player) {
		super.startSeenByPlayer(player);
		if (!this.frozen) {
			this.bossEvent.addPlayer(player);
		}
	}

	@Override
	public void stopSeenByPlayer(ServerPlayer player) {
		super.stopSeenByPlayer(player);
		this.bossEvent.removePlayer(player);
	}

	public boolean isSpecialReady() {
		return this.specialCooldown <= 0;
	}

	public void setSpecialCooldown(int ticks) {
		this.specialCooldown = ticks;
	}

	@Override
	protected void customServerAiStep(ServerLevel level) {
		super.customServerAiStep(level);
		this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
		if (this.specialCooldown > 0) {
			this.specialCooldown--;
		}
	}

	/** Damage of a special attack plus Slowness V and Weakness II for 7 seconds. */
	public static void frostHit(ServerLevel level, IceMonster mob, LivingEntity victim, float amount) {
		victim.hurtServer(level, mob.damageSources().mobAttack(mob), amount);
		if (victim.isAlive()) {
			victim.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, DEBUFF_TICKS, 4));
			victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, DEBUFF_TICKS, 1));
		}
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	// ------------------------------------------------------------------ sounds

	@Override
	protected SoundEvent getAmbientSound() {
		return SoundEvents.STRAY_AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return SoundEvents.STRAY_HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return SoundEvents.STRAY_DEATH;
	}

	@Override
	protected void playStepSound(BlockPos pos, BlockState state) {
		this.playSound(SoundEvents.IRON_GOLEM_STEP, 1.0F, 0.7F);
	}
}
