package com.elementalarsenal;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
	private ModBlocks() {
	}

	private static final ResourceKey<Block> INFERNO_SEAL_KEY =
			ResourceKey.create(Registries.BLOCK, ElementalArsenal.id("inferno_seal"));

	/**
	 * The glowing seal in the centre of the Infernal Hall. It is only placed by the structure (no item).
	 * {@link FireHallTrigger} removes it and awakens the Inferno Colossus when a player gets close.
	 */
	public static final Block INFERNO_SEAL = Registry.register(BuiltInRegistries.BLOCK, INFERNO_SEAL_KEY,
			new Block(BlockBehaviour.Properties.of()
					.strength(-1.0F, 3600000.0F)
					.sound(SoundType.NETHER_BRICKS)
					.lightLevel(state -> 12)
					.setId(INFERNO_SEAL_KEY)));

	private static final ResourceKey<Block> FROSTBOUND_BRICKS_KEY =
			ResourceKey.create(Registries.BLOCK, ElementalArsenal.id("frostbound_bricks"));
	private static final ResourceKey<Block> GLACIAL_SEAL_KEY =
			ResourceKey.create(Registries.BLOCK, ElementalArsenal.id("glacial_seal"));

	/** Unbreakable walls of the Glacial Citadel's sealed rooms. Only placed by the structure (no item). */
	public static final Block FROSTBOUND_BRICKS = Registry.register(BuiltInRegistries.BLOCK, FROSTBOUND_BRICKS_KEY,
			new Block(BlockBehaviour.Properties.of()
					.strength(-1.0F, 3600000.0F)
					.sound(SoundType.DEEPSLATE_BRICKS)
					.setId(FROSTBOUND_BRICKS_KEY)));

	/** The seal in the centre of the Glacial Citadel's main hall; {@link IceHallTrigger} wakes the Warlord. */
	public static final Block GLACIAL_SEAL = Registry.register(BuiltInRegistries.BLOCK, GLACIAL_SEAL_KEY,
			new Block(BlockBehaviour.Properties.of()
					.strength(-1.0F, 3600000.0F)
					.sound(SoundType.GLASS)
					.lightLevel(state -> 12)
					.setId(GLACIAL_SEAL_KEY)));

	private static final ResourceKey<Block> FROSTBOUND_GATE_KEY =
			ResourceKey.create(Registries.BLOCK, ElementalArsenal.id("frostbound_gate"));

	/**
	 * Looks exactly like the frostbound bricks and is just as unbreakable, but {@link IceHallTrigger} removes
	 * it when the Glacial Warlord dies, which opens the six locked rooms.
	 */
	public static final Block FROSTBOUND_GATE = Registry.register(BuiltInRegistries.BLOCK, FROSTBOUND_GATE_KEY,
			new Block(BlockBehaviour.Properties.of()
					.strength(-1.0F, 3600000.0F)
					.sound(SoundType.DEEPSLATE_BRICKS)
					.setId(FROSTBOUND_GATE_KEY)));

	/** Called from the mod initializer so that the static fields above are registered. */
	public static void init() {
	}
}
