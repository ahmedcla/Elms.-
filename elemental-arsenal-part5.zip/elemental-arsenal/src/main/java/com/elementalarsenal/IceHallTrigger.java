package com.elementalarsenal;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * The life cycle of the Glacial Warlord in the Glacial Citadel:
 * <ol>
 *   <li>A player comes near the citadel: the Warlord is placed on the seal, entombed in a cage of ice (frozen, harmless).</li>
 *   <li>A player walks into the main hall: an animation cracks and shatters the ice, then the Warlord wakes up.</li>
 *   <li>The Warlord dies: the gates plugging the six locked rooms open one after another.</li>
 * </ol>
 */
public final class IceHallTrigger {
	private IceHallTrigger() {
	}

	/** A player this close to the seal makes the frozen Warlord appear. */
	private static final int NEAR_RADIUS = 30;
	/** A player this close to the seal is inside the main hall: the Warlord wakes up. */
	private static final int HALL_RADIUS = 15;
	private static final int HEIGHT = 8;
	/** Length of the awakening animation in ticks. */
	private static final int WAKE_TICKS = 80;
	/** The ice cage: 5x5 footprint, 6 blocks high above the seal plate. */
	private static final int CAGE_HALF = 2;
	private static final int CAGE_HEIGHT = 6;

	private static final List<Awakening> WAKING = new ArrayList<>();
	private static final List<Opening> OPENING = new ArrayList<>();

	private static final class Awakening {
		final ServerLevel level;
		final BlockPos center;
		final UUID boss;
		final UUID player;
		int age;

		Awakening(ServerLevel level, BlockPos center, UUID boss, UUID player) {
			this.level = level;
			this.center = center;
			this.boss = boss;
			this.player = player;
		}
	}

	private static final class Opening {
		final ServerLevel level;
		final List<BlockPos> gates;
		final BlockPos center;
		int age;

		Opening(ServerLevel level, BlockPos center, List<BlockPos> gates) {
			this.level = level;
			this.center = center;
			this.gates = gates;
		}
	}

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(IceHallTrigger::onServerTick);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
			WAKING.clear();
			OPENING.clear();
		});
	}

	private static void onServerTick(MinecraftServer server) {
		tickWaking();
		tickOpening();
		if (server.getTickCount() % 20 != 0) {
			return;
		}
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.isSpectator() || !player.isAlive()) {
				continue;
			}
			if (!(player.level() instanceof ServerLevel level) || level.dimension() != Level.OVERWORLD) {
				continue;
			}
			// The Warlord despawns at once on Peaceful, so the seal stays intact there
			if (level.getDifficulty() == Difficulty.PEACEFUL) {
				continue;
			}
			BlockPos seal = findSeal(level, player.blockPosition());
			if (seal != null) {
				handleSeal(level, plateCenter(level, seal), player);
			}
		}
	}

	// ------------------------------------------------------------------ finding the seal

	/**
	 * The seal is a 3x3 plate, so sampling every 3rd block in x and z always hits it.
	 * That keeps this check cheap enough to run for every player each second.
	 */
	private static BlockPos findSeal(ServerLevel level, BlockPos center) {
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int x = center.getX() - NEAR_RADIUS; x <= center.getX() + NEAR_RADIUS; x += 3) {
			for (int z = center.getZ() - NEAR_RADIUS; z <= center.getZ() + NEAR_RADIUS; z += 3) {
				int dx = x - center.getX();
				int dz = z - center.getZ();
				if (dx * dx + dz * dz > NEAR_RADIUS * NEAR_RADIUS) {
					continue;
				}
				for (int y = center.getY() - HEIGHT; y <= center.getY() + HEIGHT; y++) {
					pos.set(x, y, z);
					if (level.hasChunkAt(pos) && level.getBlockState(pos).is(ModBlocks.GLACIAL_SEAL)) {
						return pos.immutable();
					}
				}
			}
		}
		return null;
	}

	/** Centre block of the 3x3 seal plate that contains {@code found}. */
	private static BlockPos plateCenter(ServerLevel level, BlockPos found) {
		long sumX = 0;
		long sumZ = 0;
		int count = 0;
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				BlockPos p = found.offset(dx, 0, dz);
				if (level.getBlockState(p).is(ModBlocks.GLACIAL_SEAL)) {
					sumX += p.getX();
					sumZ += p.getZ();
					count++;
				}
			}
		}
		return new BlockPos((int) Math.round((double) sumX / count), found.getY(), (int) Math.round((double) sumZ / count));
	}

	// ------------------------------------------------------------------ stage 1 + 2: frozen boss, awakening

	private static void handleSeal(ServerLevel level, BlockPos center, ServerPlayer player) {
		AABB area = new AABB(center).inflate(8.0D, 10.0D, 8.0D);
		List<IceMonster> bosses = level.getEntitiesOfClass(IceMonster.class, area);
		if (bosses.isEmpty()) {
			spawnFrozenWarlord(level, center);
			return;
		}
		IceMonster boss = bosses.get(0);
		if (!boss.isFrozen() || isWaking(center)) {
			return;
		}
		double dx = player.getX() - (center.getX() + 0.5D);
		double dz = player.getZ() - (center.getZ() + 0.5D);
		if (dx * dx + dz * dz <= HALL_RADIUS * HALL_RADIUS && Math.abs(player.getY() - center.getY()) <= HEIGHT) {
			WAKING.add(new Awakening(level, center, boss.getUUID(), player.getUUID()));
			level.playSound(null, center.getX() + 0.5D, center.getY() + 1.0D, center.getZ() + 0.5D,
					SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 4.0F, 0.5F);
		}
	}

	private static boolean isWaking(BlockPos center) {
		for (Awakening a : WAKING) {
			if (a.center.equals(center)) {
				return true;
			}
		}
		return false;
	}

	private static void spawnFrozenWarlord(ServerLevel level, BlockPos center) {
		buildCage(level, center);
		IceMonster boss = new IceMonster(ModEntities.ICE_MONSTER, level);
		boss.setPos(center.getX() + 0.5D, center.getY() + 1.0D, center.getZ() + 0.5D);
		boss.freeze(center);
		level.addFreshEntity(boss);
	}

	/** Hollow cage around the Warlord: light-blue glass walls and a blue ice frame. Only fills empty cells. */
	private static void buildCage(ServerLevel level, BlockPos center) {
		for (int dx = -CAGE_HALF; dx <= CAGE_HALF; dx++) {
			for (int dz = -CAGE_HALF; dz <= CAGE_HALF; dz++) {
				for (int dy = 1; dy <= CAGE_HEIGHT; dy++) {
					boolean wall = Math.abs(dx) == CAGE_HALF || Math.abs(dz) == CAGE_HALF || dy == CAGE_HEIGHT;
					if (!wall) {
						continue;
					}
					boolean edgeX = Math.abs(dx) == CAGE_HALF;
					boolean edgeZ = Math.abs(dz) == CAGE_HALF;
					boolean edgeY = dy == CAGE_HEIGHT;
					boolean frame = (edgeX ? 1 : 0) + (edgeZ ? 1 : 0) + (edgeY ? 1 : 0) >= 2;
					BlockPos p = center.offset(dx, dy, dz);
					if (level.getBlockState(p).isAir()) {
						level.setBlock(p, (frame ? Blocks.BLUE_ICE : Blocks.LIGHT_BLUE_STAINED_GLASS).defaultBlockState(), 3);
					}
				}
			}
		}
	}

	private static boolean isCageBlock(BlockState state) {
		return state.is(Blocks.BLUE_ICE) || state.is(Blocks.LIGHT_BLUE_STAINED_GLASS);
	}

	private static void tickWaking() {
		Iterator<Awakening> it = WAKING.iterator();
		while (it.hasNext()) {
			Awakening a = it.next();
			ServerLevel level = a.level;
			Entity e = level.getEntity(a.boss);
			if (!(e instanceof IceMonster boss) || !boss.isAlive()) {
				it.remove();
				continue;
			}
			a.age++;
			double x = a.center.getX() + 0.5D;
			double y = a.center.getY() + 3.0D;
			double z = a.center.getZ() + 0.5D;

			// cracking: frost mist and glints, with crystal cracks that get faster
			if (a.age < WAKE_TICKS - 10) {
				level.sendParticles(ParticleTypes.SNOWFLAKE, x, y, z, 8, 1.6D, 2.0D, 1.6D, 0.02D);
				level.sendParticles(ParticleTypes.END_ROD, x, y, z, 2, 1.4D, 1.8D, 1.4D, 0.01D);
				if (a.age % Math.max(3, 12 - a.age / 8) == 0) {
					level.playSound(null, x, y, z, SoundEvents.GLASS_BREAK, SoundSource.HOSTILE, 1.2F, 0.5F + a.age / 120.0F);
					level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BLUE_ICE.defaultBlockState()),
							x, y, z, 14, 1.6D, 2.0D, 1.6D, 0.05D);
				}
			}
			// shattering: the cage falls apart from the top layer down
			int shatterStart = WAKE_TICKS - 40;
			if (a.age >= shatterStart && (a.age - shatterStart) % 5 == 0) {
				int layer = CAGE_HEIGHT - (a.age - shatterStart) / 5;
				if (layer >= 1) {
					for (int dx = -CAGE_HALF; dx <= CAGE_HALF; dx++) {
						for (int dz = -CAGE_HALF; dz <= CAGE_HALF; dz++) {
							BlockPos p = a.center.offset(dx, layer, dz);
							if (isCageBlock(level.getBlockState(p))) {
								level.destroyBlock(p, false);
							}
						}
					}
				}
			}
			if (a.age >= WAKE_TICKS) {
				finishAwakening(level, a, boss);
				it.remove();
			}
		}
	}

	private static void finishAwakening(ServerLevel level, Awakening a, IceMonster boss) {
		// make sure nothing of the cage is left
		for (int dx = -CAGE_HALF; dx <= CAGE_HALF; dx++) {
			for (int dz = -CAGE_HALF; dz <= CAGE_HALF; dz++) {
				for (int dy = 1; dy <= CAGE_HEIGHT; dy++) {
					BlockPos p = a.center.offset(dx, dy, dz);
					if (isCageBlock(level.getBlockState(p))) {
						level.destroyBlock(p, false);
					}
				}
			}
		}
		// the seal melts into blue ice
		for (int dx = -1; dx <= 1; dx++) {
			for (int dz = -1; dz <= 1; dz++) {
				BlockPos p = a.center.offset(dx, 0, dz);
				if (level.getBlockState(p).is(ModBlocks.GLACIAL_SEAL)) {
					level.setBlock(p, Blocks.BLUE_ICE.defaultBlockState(), 3);
				}
			}
		}
		ServerPlayer target = null;
		for (ServerPlayer p : level.players()) {
			if (p.getUUID().equals(a.player) && p.isAlive() && !p.isSpectator()) {
				target = p;
			}
		}
		if (target != null) {
			boss.setYRot((float) (Math.toDegrees(Math.atan2(target.getZ() - boss.getZ(), target.getX() - boss.getX())) - 90.0D));
		}
		boss.thaw(target);
		double x = a.center.getX() + 0.5D;
		double y = a.center.getY() + 1.0D;
		double z = a.center.getZ() + 0.5D;
		level.playSound(null, x, y, z, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 3.0F, 1.2F);
		level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1.5D, z, 1, 0, 0, 0, 0);
		level.sendParticles(ParticleTypes.SNOWFLAKE, x, y + 1.5D, z, 200, 2.0D, 2.0D, 2.0D, 0.15D);
		level.sendParticles(ParticleTypes.END_ROD, x, y + 1.0D, z, 80, 1.5D, 1.5D, 1.5D, 0.15D);
	}

	// ------------------------------------------------------------------ stage 3: the rooms open

	/** Called by {@link IceMonster} when a Warlord that guards a citadel dies. */
	public static void onWarlordDefeated(ServerLevel level, BlockPos center) {
		List<BlockPos> gates = new ArrayList<>();
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int x = center.getX() - 22; x <= center.getX() + 22; x++) {
			for (int z = center.getZ() - 22; z <= center.getZ() + 22; z++) {
				for (int y = center.getY() + 1; y <= center.getY() + 4; y++) {
					pos.set(x, y, z);
					if (level.hasChunkAt(pos) && level.getBlockState(pos).is(ModBlocks.FROSTBOUND_GATE)) {
						gates.add(pos.immutable());
					}
				}
			}
		}
		if (gates.isEmpty()) {
			return;
		}
		// each doorway opens from the hall inwards: the closest cells first
		gates.sort(Comparator.comparingDouble(p -> p.distSqr(center)));
		OPENING.add(new Opening(level, center, gates));
		level.playSound(null, center.getX() + 0.5D, center.getY() + 2.0D, center.getZ() + 0.5D,
				SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 4.0F, 0.6F);
	}

	private static void tickOpening() {
		Iterator<Opening> it = OPENING.iterator();
		while (it.hasNext()) {
			Opening o = it.next();
			o.age++;
			// start after a short pause; the cells are removed in order of distance from the seal
			int due = (o.age - 30) * 14;
			if (due <= 0) {
				continue;
			}
			int removed = 0;
			while (!o.gates.isEmpty() && removed < due) {
				BlockPos p = o.gates.remove(0);
				if (o.level.getBlockState(p).is(ModBlocks.FROSTBOUND_GATE)) {
					o.level.destroyBlock(p, false);
				}
				removed++;
			}
			if (o.gates.isEmpty()) {
				it.remove();
			}
		}
	}
}
