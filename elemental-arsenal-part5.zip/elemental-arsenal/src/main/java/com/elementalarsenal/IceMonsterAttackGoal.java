package com.elementalarsenal;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The three special attacks of the {@link IceMonster}. Each one shows a clear warning on the ground first, so it can
 * be dodged. Everything they hit takes {@link IceMonster#SPECIAL_DAMAGE} (7 hearts), Slowness V and Weakness II for 7 s.
 * <ul>
 *   <li><b>Glacial Fangs</b> - he slams the ground and three lines of ice spikes burst out toward you, one after another.</li>
 *   <li><b>Permafrost Rings</b> - rings of spikes burst out around him, one ring after the other (stand between the rings).</li>
 *   <li><b>Frost Lance</b> - a thin warning line, then a beam of ice with spikes erupting along it (sidestep it).</li>
 * </ul>
 */
public class IceMonsterAttackGoal extends Goal {
	private static final int FANGS = 0;
	private static final int RINGS = 1;
	private static final int LANCE = 2;

	private final IceMonster mob;
	private int attack;
	private int tick;
	private int duration;
	private Set<LivingEntity> hit = new HashSet<>();

	// Fangs / Lance: horizontal direction (fangs) or full 3D line (lance)
	private Vec3 dir = new Vec3(0, 0, 1);
	private Vec3 lanceOrigin = Vec3.ZERO;
	private Vec3 lanceDir = new Vec3(0, 0, 1);
	private double lanceLength = 22.0D;

	public IceMonsterAttackGoal(IceMonster mob) {
		this.mob = mob;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		LivingEntity target = this.mob.getTarget();
		return target != null && target.isAlive() && this.mob.isSpecialReady()
				&& this.mob.distanceToSqr(target) < 26.0D * 26.0D
				&& this.mob.hasLineOfSight(target);
	}

	@Override
	public boolean canContinueToUse() {
		LivingEntity target = this.mob.getTarget();
		return target != null && target.isAlive() && this.tick < this.duration;
	}

	@Override
	public void start() {
		LivingEntity target = this.mob.getTarget();
		double dist = target == null ? 0.0D : this.mob.distanceTo(target);
		int roll = this.mob.getRandom().nextInt(100);
		if (dist <= 8.0D) {
			this.attack = roll < 45 ? RINGS : (roll < 85 ? FANGS : LANCE);
		} else {
			this.attack = roll < 50 ? FANGS : (roll < 85 ? LANCE : RINGS);
		}
		this.tick = 0;
		this.hit = new HashSet<>();   // spikes still bursting out after this goal stops keep their own set
		this.mob.getNavigation().stop();
		this.duration = switch (this.attack) {
			case FANGS -> 52;
			case RINGS -> 62;
			default -> 50;
		};
		this.mob.playSound(SoundEvents.ENDER_DRAGON_GROWL, 2.0F, 1.4F);
	}

	@Override
	public void stop() {
		this.mob.setSpecialCooldown(70 + this.mob.getRandom().nextInt(50));
	}

	@Override
	public void tick() {
		if (!(this.mob.level() instanceof ServerLevel level)) {
			return;
		}
		LivingEntity target = this.mob.getTarget();
		if (target != null && this.attack != RINGS) {
			this.mob.getLookControl().setLookAt(target, 40.0F, 40.0F);
		}
		this.mob.getNavigation().stop();
		switch (this.attack) {
			case FANGS -> this.tickFangs(level, target);
			case RINGS -> this.tickRings(level);
			default -> this.tickLance(level, target);
		}
		this.tick++;
	}

	// ================================================================== GLACIAL FANGS

	private static final int FANGS_LOCK = 18;
	private static final int FANGS_SLAM = 26;
	private static final double[] FANGS_ANGLES = {-0.42D, 0.0D, 0.42D};

	private void tickFangs(ServerLevel level, LivingEntity target) {
		double x = this.mob.getX();
		double y = this.mob.getY();
		double z = this.mob.getZ();
		if (this.tick < FANGS_LOCK && target != null) {
			Vec3 to = new Vec3(target.getX() - x, 0.0D, target.getZ() - z);
			if (to.lengthSqr() > 1.0E-4D) {
				this.dir = to.normalize();
			}
		}
		if (this.tick < FANGS_SLAM) {
			// Frost gathers at his feet while the three lines are marked on the ground
			float progress = this.tick / (float) FANGS_SLAM;
			for (int i = 0; i < 3; i++) {
				double angle = this.tick * 0.5D + i * (Math.PI * 2.0D / 3.0D);
				double r = 2.4D * (1.0D - progress) + 0.8D;
				level.sendParticles(ParticleTypes.SNOWFLAKE, x + Math.cos(angle) * r, y + 0.2D + progress * 1.8D,
						z + Math.sin(angle) * r, 1, 0, 0, 0, 0);
			}
			if (this.tick >= 6) {
				for (double a : FANGS_ANGLES) {
					Vec3 d = rotate(this.dir, a);
					for (double dd = 2.5D; dd <= 2.5D + 8 * 1.9D; dd += 1.9D) {
						Vec3 p = this.groundAt(new Vec3(x + d.x * dd, y, z + d.z * dd));
						level.sendParticles(ParticleTypes.SNOWFLAKE, p.x, p.y + 0.15D, p.z, 1, 0.25D, 0.0D, 0.25D, 0.0D);
					}
				}
			}
			if (this.tick % 8 == 0) {
				this.mob.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 2.0F, 0.5F + progress);
			}
			return;
		}
		if (this.tick == FANGS_SLAM) {
			// The slam: three lines of spikes burst out one after another
			this.mob.playSound(SoundEvents.IRON_GOLEM_ATTACK, 3.0F, 0.5F);
			this.mob.playSound(SoundEvents.GLASS_BREAK, 3.0F, 0.5F);
			level.sendParticles(ParticleTypes.EXPLOSION, x, y + 0.3D, z, 1, 0, 0, 0, 0);
			for (double a : FANGS_ANGLES) {
				Vec3 d = rotate(this.dir, a);
				for (int i = 0; i < 9; i++) {
					double dd = 2.5D + i * 1.9D;
					IceSpikes.queue(level, this.mob, this.hit, this.groundAt(new Vec3(x + d.x * dd, y, z + d.z * dd)), i * 2);
				}
			}
		}
	}

	// ================================================================== PERMAFROST RINGS

	private static final int RINGS_SLAM = 30;
	private static final double[] RING_RADII = {3.0D, 6.0D, 8.5D};   // the rings fit inside the 19-wide main hall

	private void tickRings(ServerLevel level) {
		double x = this.mob.getX();
		double y = this.mob.getY();
		double z = this.mob.getZ();
		if (this.tick < RINGS_SLAM) {
			// Frost circles on the ground mark where every ring will burst out
			if (this.tick >= 4) {
				for (double r : RING_RADII) {
					int points = (int) (r * 5.0D) + 10;
					for (int i = 0; i < points; i++) {
						double angle = (Math.PI * 2.0D) * i / points + this.tick * 0.08D;
						level.sendParticles(ParticleTypes.SNOWFLAKE, x + Math.cos(angle) * r, y + 0.15D,
								z + Math.sin(angle) * r, 1, 0, 0, 0, 0);
					}
				}
			}
			level.sendParticles(ParticleTypes.SNOWFLAKE, x, y + 2.8D, z, 3, 0.6D, 0.3D, 0.6D, 0.02D);
			if (this.tick % 8 == 0) {
				this.mob.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 2.0F, 0.5F + this.tick / 60.0F);
			}
			return;
		}
		if (this.tick == RINGS_SLAM) {
			this.mob.playSound(SoundEvents.IRON_GOLEM_ATTACK, 3.0F, 0.5F);
			this.mob.playSound(SoundEvents.ENDER_DRAGON_GROWL, 2.5F, 1.2F);
			level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 0.5D, z, 1, 0, 0, 0, 0);
			for (int k = 0; k < RING_RADII.length; k++) {
				double r = RING_RADII[k];
				int count = Math.max(6, (int) (Math.PI * 2.0D * r / 2.4D));
				double offset = this.mob.getRandom().nextDouble() * Math.PI * 2.0D;
				for (int i = 0; i < count; i++) {
					double angle = offset + (Math.PI * 2.0D) * i / count;
					Vec3 p = this.groundAt(new Vec3(x + Math.cos(angle) * r, y, z + Math.sin(angle) * r));
					IceSpikes.queue(level, this.mob, this.hit, p, k * 10);
				}
			}
		}
	}

	// ================================================================== FROST LANCE

	private static final int LANCE_LOCK = 20;
	private static final int LANCE_FIRE = 26;

	private void tickLance(ServerLevel level, LivingEntity target) {
		if (this.tick < LANCE_LOCK) {
			if (target != null) {
				this.aimLance(level, target);
			}
			Vec3 o = this.lanceOrigin;
			level.sendParticles(ParticleTypes.SNOWFLAKE, o.x, o.y, o.z, 4, 0.35D, 0.35D, 0.35D, 0.03D);
			if (this.tick > 6) {
				this.drawLance(level, ParticleTypes.SNOWFLAKE, 1.6D, 0.0D);
			}
			return;
		}
		if (this.tick < LANCE_FIRE) {
			// Locked: a bright warning line
			this.drawLance(level, ParticleTypes.END_ROD, 0.9D, 0.0D);
			return;
		}
		if (this.tick == LANCE_FIRE) {
			this.mob.playSound(SoundEvents.GLASS_BREAK, 3.0F, 0.4F);
			this.mob.playSound(SoundEvents.GHAST_SHOOT, 3.0F, 1.5F);
			level.sendParticles(ParticleTypes.EXPLOSION, this.lanceOrigin.x, this.lanceOrigin.y, this.lanceOrigin.z,
					1, 0, 0, 0, 0);
			// the beam hurts everybody on the line
			AABB box = new AABB(this.lanceOrigin, this.lanceOrigin.add(this.lanceDir.scale(this.lanceLength))).inflate(1.4D);
			for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, this::isVictim)) {
				Vec3 p = e.position().add(0.0D, e.getBbHeight() * 0.5D, 0.0D);
				Vec3 rel = p.subtract(this.lanceOrigin);
				double along = rel.dot(this.lanceDir);
				if (along < 0.0D || along > this.lanceLength) {
					continue;
				}
				double off = rel.subtract(this.lanceDir.scale(along)).length();
				if (off <= 1.5D && this.hit.add(e)) {
					IceMonster.frostHit(level, this.mob, e, IceMonster.SPECIAL_DAMAGE);
					e.knockback(0.8D, -this.lanceDir.x, -this.lanceDir.z);
				}
			}
			// ice spikes erupt along the beam, one after another
			int n = 0;
			for (double d = 3.0D; d < this.lanceLength; d += 3.0D) {
				Vec3 p = this.lanceOrigin.add(this.lanceDir.scale(d));
				IceSpikes.queue(level, this.mob, this.hit, this.groundAt(p), n++);
			}
		}
		if (this.tick < LANCE_FIRE + 8) {
			this.drawLance(level, ParticleTypes.END_ROD, 0.5D, 0.02D);
			this.drawLance(level, ParticleTypes.SNOWFLAKE, 0.8D, 0.06D);
		}
	}

	private void aimLance(ServerLevel level, LivingEntity target) {
		this.lanceOrigin = this.mob.getEyePosition().add(0.0D, -0.4D, 0.0D);
		Vec3 aim = target.position().add(0.0D, target.getBbHeight() * 0.6D, 0.0D);
		this.lanceDir = aim.subtract(this.lanceOrigin).normalize();
		Vec3 end = this.lanceOrigin.add(this.lanceDir.scale(22.0D));
		var hitResult = level.clip(new ClipContext(this.lanceOrigin, end,
				ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this.mob));
		this.lanceLength = hitResult.getLocation().distanceTo(this.lanceOrigin);
	}

	private void drawLance(ServerLevel level, ParticleOptions particle, double spacing, double speed) {
		for (double d = 1.0D; d < this.lanceLength; d += spacing) {
			Vec3 p = this.lanceOrigin.add(this.lanceDir.scale(d));
			level.sendParticles(particle, p.x, p.y, p.z, 1, 0.05D, 0.05D, 0.05D, speed);
		}
	}

	// ================================================================== helpers

	private static Vec3 rotate(Vec3 v, double angle) {
		double c = Math.cos(angle);
		double s = Math.sin(angle);
		return new Vec3(v.x * c - v.z * s, 0.0D, v.x * s + v.z * c);
	}

	/** Finds the ground below (or just above) a position. */
	private Vec3 groundAt(Vec3 pos) {
		BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(pos.x, pos.y + 1.0D, pos.z);
		for (int i = 0; i < 6; i++) {
			BlockPos below = p.below();
			if (!this.mob.level().getBlockState(below).getCollisionShape(this.mob.level(), below).isEmpty()) {
				break;
			}
			p.move(0, -1, 0);
		}
		return new Vec3(pos.x, p.getY(), pos.z);
	}

	private boolean isVictim(LivingEntity e) {
		return e != this.mob && e.isAlive() && !(e instanceof Enemy);
	}
}
