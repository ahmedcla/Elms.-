#!/usr/bin/env python3
"""Glacial Spear item texture (32x32), drawn like the Glacial Warlord's staff: a long silver shaft with navy bindings,
a navy collar with a cyan gem, silver crystal spikes and a glowing cyan crystal head. Diagonal, tip at the top right,
like every vanilla spear sprite (the vanilla spear_in_hand model rotates it into the hand).

usage: gen_glacial_spear.py <out_texture.png> [preview.png]
"""
import math, random, sys
from PIL import Image

OUT = sys.argv[1]
random.seed(5)
W = 32
im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
px = im.load()


def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


WHITE = (255, 255, 255)
NAVY = (30, 49, 98)
DARK = (14, 26, 68)
CYAN = (110, 236, 255)
BLUE = (30, 104, 226)
SILVER_L = (226, 232, 244)
SILVER = (168, 180, 204)
SILVER_D = (96, 112, 148)

TIP = (30.5, 1.5)             # pixel centre of the tip
D = (-math.sqrt(0.5), math.sqrt(0.5))   # along the spear (towards the butt)
N = (math.sqrt(0.5), math.sqrt(0.5))    # across (towards the lower right)


def put(x, y, c):
    if 0 <= x < W and 0 <= y < W:
        px[x, y] = tuple(c) + (255,)


def draw_shape(profile, color):
    """profile(t) -> half width or None; color(t, s) -> rgb (s = signed distance across)."""
    for y in range(W):
        for x in range(W):
            dx, dy = x + 0.5 - TIP[0], y + 0.5 - TIP[1]
            t = dx * D[0] + dy * D[1]
            s = dx * N[0] + dy * N[1]
            hw = profile(t)
            if hw is None or abs(s) > hw:
                continue
            c = color(t, s, hw)
            if c is not None:
                put(x, y, c)


# ---- shaft (drawn first so the head and collar overlap it)
def shaft_profile(t):
    return 0.95 if 13.0 <= t <= 38.5 else None


def shaft_color(t, s, hw):
    c = lerp(SILVER_L, SILVER_D, (s + hw) / (2 * hw))          # lit from the upper left
    for b in (17.5, 26.0, 33.5):                                 # navy bindings
        if b <= t < b + 1.8:
            return NAVY if abs(s) < hw - 0.1 else DARK
    if abs(s) >= hw - 0.15:
        c = lerp(c, DARK, 0.45)
    return c


draw_shape(shaft_profile, shaft_color)


# ---- butt crystal
def butt_profile(t):
    if 38.0 <= t <= 42.0:
        return 1.8 - abs(t - 40.0) * 0.55
    return None


draw_shape(butt_profile, lambda t, s, hw: lerp(SILVER_L, BLUE, (t - 38) / 4) if abs(s) < hw - 0.3 else DARK)


# ---- collar: navy with a cyan gem in the middle
def collar_profile(t):
    return 3.9 if 12.0 <= t <= 14.6 else None


def collar_color(t, s, hw):
    if abs(s) < 0.8 and 12.7 <= t <= 13.9:
        return CYAN
    return lerp(NAVY, (60, 84, 150), (s + hw) / (2 * hw) * 0.8) if abs(s) < hw - 0.4 else DARK


draw_shape(collar_profile, collar_color)


# ---- glowing crystal head: bright cyan at the tip fading to deep blue at the collar, white-hot core
def head_profile(t):
    if t < 0:
        return None
    if t < 3.6:
        return 0.55 + t * 0.78
    if t <= 12.3:
        return 3.3 - max(0.0, t - 9.5) * 0.2
    return None


def head_color(t, s, hw):
    base = lerp(CYAN, BLUE, (t / 12.3) ** 1.1)
    c = lerp(WHITE, base, min(1.0, abs(s) / hw * 1.15))
    c = lerp(c, WHITE, 0.25 * (1 - t / 12.3) * (1 - abs(s) / hw)) if s < 0 else c
    if s > 0:
        c = lerp(c, NAVY, 0.22 + 0.2 * (s / hw))                  # shaded side
    if abs(s) > hw - 0.55:
        c = lerp(c, DARK, 0.75)
    return c


draw_shape(head_profile, head_color)


# ---- silver crystal spikes around the collar and small detached shards, like the ones around the boss
def blob(tc, sc, length, width, color_a, color_b):
    def prof(t):
        if abs(t - tc) <= length / 2:
            return width
        return None

    def col(t, s, hw):
        return lerp(color_a, color_b, (t - (tc - length / 2)) / length)
    # shift the axis sideways by sc by drawing on a shifted copy
    for y in range(W):
        for x in range(W):
            dx, dy = x + 0.5 - TIP[0], y + 0.5 - TIP[1]
            t = dx * D[0] + dy * D[1]
            s = dx * N[0] + dy * N[1] - sc
            if abs(t - tc) <= length / 2 and abs(s) <= width:
                edge = abs(t - tc) > length / 2 - 0.7 or abs(s) > width - 0.45
                put(x, y, DARK if edge else col(t, s, width))


for sg in (-1, 1):
    blob(15.6, sg * 5.0, 6.0, 1.1, SILVER_L, SILVER_D)    # long spikes pointing back along the shaft
    blob(11.0, sg * 5.6, 4.4, 1.0, SILVER_L, SILVER)      # spikes pointing forward
    blob(5.5, sg * 6.6, 3.0, 0.95, CYAN, BLUE)            # floating cyan shards beside the head
blob(22.0, -3.6, 3.0, 0.95, CYAN, BLUE)                   # a shard drifting along the shaft
blob(30.0, 3.8, 3.0, 0.95, SILVER_L, SILVER)

im.save(OUT)
if len(sys.argv) > 2:
    bg = Image.new("RGBA", (W, W), (36, 40, 52, 255))
    bg.alpha_composite(im)
    bg.resize((W * 16, W * 16), Image.NEAREST).save(sys.argv[2])
