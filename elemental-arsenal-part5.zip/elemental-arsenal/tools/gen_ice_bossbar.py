#!/usr/bin/env python3
"""Glacial Warlord boss bar sprites (182x5): a frosted navy frame with cyan gems at both ends, and a glowing
white-hot / cyan crystal fill. They replace the vanilla WHITE bar (no vanilla boss uses it).

usage: gen_ice_bossbar.py <out_background.png> <out_progress.png>
"""
import random, sys
from PIL import Image

random.seed(9)
W, H = 182, 5


def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# ---------------------------------------------------------------- background / frame
bg = Image.new("RGBA", (W, H))
FRAME_LIGHT, FRAME_DARK = (170, 214, 250), (62, 96, 160)
NAVY_TOP, NAVY_BOT = (22, 40, 96), (8, 14, 40)
for y in range(H):
    for x in range(W):
        if y == 0:
            c = FRAME_LIGHT if (x // 3) % 2 == 0 else lerp(FRAME_LIGHT, FRAME_DARK, 0.45)   # frosty, faceted top edge
        elif y == H - 1:
            c = FRAME_DARK
        else:
            c = lerp(NAVY_TOP, NAVY_BOT, (y - 1) / 3)
            if (x + y * 5) % 13 == 0:
                c = lerp(c, (60, 110, 200), 0.45)        # faint crystal facets
            if random.random() < 0.025:
                c = (150, 220, 255)                       # tiny frost sparkles
        bg.putpixel((x, y), c + (255,))
# ornate end caps: bright frame ends with a cyan gem in the middle row
for x in list(range(0, 3)) + list(range(W - 3, W)):
    for y in range(H):
        bg.putpixel((x, y), FRAME_LIGHT + (255,))
for x in (1, W - 2):
    bg.putpixel((x, 2), (110, 240, 255, 255))
    bg.putpixel((x, 1), (60, 160, 235, 255))
    bg.putpixel((x, 3), (60, 160, 235, 255))
for x in (0, W - 1):
    for y in (0, H - 1):
        bg.putpixel((x, y), FRAME_DARK + (255,))
bg.save(sys.argv[1])

# ---------------------------------------------------------------- progress (the glowing fill)
pr = Image.new("RGBA", (W, H))
ROWS = [(52, 138, 230), (112, 222, 255), (244, 253, 255), (112, 222, 255), (36, 100, 200)]
for y in range(H):
    for x in range(W):
        c = ROWS[y]
        wave = ((x * 7) % 31) / 31.0
        c = lerp(c, (255, 255, 255), 0.18 * wave * (1 if y in (1, 2, 3) else 0.4))   # shimmer
        if y == 2 and (x % 23) in (0, 1):
            c = (255, 255, 255)                                                       # white-hot glints
        if y in (1, 3) and (x % 23) == 11:
            c = (255, 255, 255)
        if x % 23 == 11 and y == 2:
            c = (190, 240, 255)
        pr.putpixel((x, y), c + (255,))
pr.save(sys.argv[2])
