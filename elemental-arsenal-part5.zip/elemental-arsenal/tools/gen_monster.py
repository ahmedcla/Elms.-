#!/usr/bin/env python3
"""Generates the fire monster texture (PNG) and the Java model class from ONE box list,
so the UV offsets in the model always match the painted texture."""
import random, math, sys
from PIL import Image

OUT_TEX = sys.argv[1]
OUT_JAVA = sys.argv[2]
OUT_BAR_BG = sys.argv[3]
OUT_BAR_FG = sys.argv[4]

TEX_W, TEX_H = 256, 128
rnd = random.Random(1337)

# ---------------------------------------------------------------- palette
def c(r, g, b, a=255): return (r, g, b, a)
CHAR = [c(36, 25, 21), c(43, 30, 25), c(31, 21, 18), c(50, 36, 29), c(27, 18, 16)]
OBS = [c(27, 23, 40), c(34, 29, 50), c(21, 18, 32), c(42, 36, 62), c(18, 15, 27)]
OBS_EDGE = c(58, 50, 84)
L_DEEP = c(168, 52, 8)
L_MID = c(255, 122, 16)
L_HOT = c(255, 176, 40)
L_CORE = c(255, 226, 110)
L_WHITE = c(255, 248, 205)
TOOTH = c(236, 230, 214)

# ---------------------------------------------------------------- box list
# name, parent, kind, (w,h,d), box origin (x,y,z), pivot offset (x,y,z), rotation (x,y,z)
B = []
def box(name, parent, kind, size, origin, pivot=(0, 0, 0), rot=(0, 0, 0)):
    B.append(dict(name=name, parent=parent, kind=kind, size=size, origin=origin, pivot=pivot, rot=rot))

# torso
box("body", None, "torso", (24, 24, 12), (-12, -24, -6), (0, 4, 0))
box("belt", "body", "belt", (22, 5, 14), (-11, -3, -7))
box("core", "body", "core", (7, 7, 2), (-3.5, -17.5, -8))
box("backplate", "body", "backplate", (16, 14, 2), (-8, -20, 6))
# head
box("head", None, "head", (12, 12, 12), (-6, -12, -6), (0, -20, 0))
box("crown", "head", "crown", (14, 3, 14), (-7, -15, -7))
for side, sx in (("r", -1), ("l", 1)):
    # inner (tall) horn
    box(f"horn_a_{side}", "head", "horn", (3, 8, 3), (-1.5, -8, -1.5), (sx * 4.5, -14, 0), (0, 0, sx * 0.22))
    box(f"horn_a2_{side}", f"horn_a_{side}", "horn", (3, 6, 3), (-1.5, -6, -1.5), (0, -8, 0), (0, 0, sx * 0.30))
    box(f"horn_a3_{side}", f"horn_a2_{side}", "tip", (4, 3, 4), (-2, -3, -2), (0, -6, 0))
    # outer (short) horn
    box(f"horn_b_{side}", "head", "horn", (3, 6, 3), (-1.5, -6, -1.5), (sx * 7.5, -13, 0), (0, 0, sx * 0.75))
    box(f"horn_b2_{side}", f"horn_b_{side}", "tip", (4, 3, 4), (-2, -3, -2), (0, -6, 0))
# arms (right = -x)
for side, sx in (("r", -1), ("l", 1)):
    box(f"arm_{side}", None, "arm", (8, 18, 8), (-4, -2, -4), (sx * 16, -18, 0))
    box(f"pad_{side}", f"arm_{side}", "pad", (12, 6, 12), (-6, -6, -6))
    box(f"padhorn_{side}", f"pad_{side}", "horn", (3, 7, 3), (-1.5, -7, -1.5), (sx * 2.5, -6, 0), (0, 0, sx * 0.45))
    box(f"padhorn2_{side}", f"padhorn_{side}", "tip", (4, 3, 4), (-2, -3, -2), (0, -7, 0))
    box(f"fist_{side}", f"arm_{side}", "fist", (10, 8, 10), (-5, 0, -5), (0, 16, 0))
# legs
for side, sx in (("r", -1), ("l", 1)):
    box(f"leg_{side}", None, "leg", (8, 16, 8), (-4, 0, -4), (sx * 5.5, 4, 0))
    box(f"knee_{side}", f"leg_{side}", "knee", (9, 6, 2), (-4.5, 6, -5.5))
    box(f"boot_{side}", f"leg_{side}", "boot", (10, 4, 11), (-5, 16, -6))

# ---------------------------------------------------------------- UV packing
def box_extent(b):
    w, h, d = b["size"]
    return int(2 * d + 2 * w), int(d + h)

order = sorted(B, key=lambda b: -box_extent(b)[1])
x = y = shelf_h = 0
for b in order:
    bw, bh = box_extent(b)
    if x + bw > TEX_W:
        x = 0
        y += shelf_h
        shelf_h = 0
    b["u"], b["v"] = x, y
    x += bw
    shelf_h = max(shelf_h, bh)
if y + shelf_h > TEX_H:
    raise SystemExit("texture too small: need %d" % (y + shelf_h))

# ---------------------------------------------------------------- painting helpers
img = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
P = img.load()

def faces(b):
    w, h, d = [int(v) for v in b["size"]]
    u, v = b["u"], b["v"]
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "east": (u, v + d, d, h),       # model +x side (entity left)
        "front": (u + d, v + d, w, h),
        "west": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }

class Face:
    def __init__(self, rect):
        self.x0, self.y0, self.w, self.h = rect
    def put(self, x, y, col):
        if 0 <= x < self.w and 0 <= y < self.h:
            P[self.x0 + x, self.y0 + y] = col
    def get(self, x, y):
        return P[self.x0 + x, self.y0 + y]
    def fill(self, pal, shade=1.0):
        for yy in range(self.h):
            for xx in range(self.w):
                base = rnd.choice(pal)
                self.put(xx, yy, shade_col(base, shade))
    def rect(self, x, y, w, h, col):
        for yy in range(y, y + h):
            for xx in range(x, x + w):
                self.put(xx, yy, col)
    def outline(self, col):
        for xx in range(self.w):
            self.put(xx, 0, col); self.put(xx, self.h - 1, col)
        for yy in range(self.h):
            self.put(0, yy, col); self.put(self.w - 1, yy, col)

def shade_col(col, f):
    return (min(255, int(col[0] * f)), min(255, int(col[1] * f)), min(255, int(col[2] * f)), col[3])

def blend(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(4))

def lava_px(f, x, y, strength=1.0):
    """Paint one lava pixel with a soft dark-orange halo on the free neighbours."""
    f.put(x, y, L_HOT if rnd.random() < 0.55 * strength + 0.2 else L_MID)
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        nx, ny = x + dx, y + dy
        if 0 <= nx < f.w and 0 <= ny < f.h:
            cur = f.get(nx, ny)
            if cur[0] < 120:  # only halo onto dark pixels
                f.put(nx, ny, blend(cur, L_DEEP, 0.55))

def crack(f, x, y, length, bias=(0, 1), strength=1.0):
    """Pixel-art crack: random walk with mostly straight / diagonal steps."""
    dirs = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (-1, 1), (1, -1), (-1, -1)]
    dx, dy = bias
    for i in range(length):
        lava_px(f, x, y, strength)
        if rnd.random() < 0.35:
            dx, dy = rnd.choice(dirs)
            if rnd.random() < 0.6:
                dx, dy = bias if rnd.random() < 0.5 else (dx, dy)
        x += dx; y += dy
        if rnd.random() < 0.07:  # branch
            crack(f, x, y, max(2, length // 3), rnd.choice(dirs), strength * 0.8)
        if not (0 <= x < f.w and 0 <= y < f.h):
            break

def cracks(f, count, lmin, lmax, strength=1.0):
    for _ in range(count):
        crack(f, rnd.randrange(f.w), rnd.randrange(f.h), rnd.randint(lmin, lmax),
              rnd.choice([(0, 1), (1, 1), (-1, 1), (1, 0)]), strength)

def seams(f, step_x, step_y, col):
    for yy in range(step_y, f.h, step_y):
        for xx in range(f.w):
            if rnd.random() < 0.75: f.put(xx, yy, col)
    for xx in range(step_x, f.w, step_x):
        for yy in range(f.h):
            if rnd.random() < 0.75: f.put(xx, yy, col)

def edge_light(f, col, top=True):
    for xx in range(f.w):
        if top: f.put(xx, 0, col)

def dashes(f, y, x0, x1, dash, gap, col_a=L_MID, col_b=L_CORE, thick=1):
    xx = x0
    while xx + dash <= x1:
        for t in range(thick):
            for k in range(dash):
                f.put(xx + k, y + t, col_b if (t == 0 and 0 < k < dash - 1 and thick == 1) else col_a)
        xx += dash + gap

def dots(f, count, region=None):
    rx, ry, rw, rh = region if region else (0, 0, f.w, f.h)
    for _ in range(count):
        px_, py_ = rnd.randrange(rx, rx + rw), rnd.randrange(ry, ry + rh)
        f.put(px_, py_, rnd.choice([L_MID, L_HOT, L_DEEP]))

# ---------------------------------------------------------------- per-kind painting
def paint_charcoal(F, lava=1.0):
    for name, f in F.items():
        shade = {"top": 1.25, "bottom": 0.7, "east": 0.95, "west": 0.95, "front": 1.0, "back": 0.9}[name]
        f.fill(CHAR, shade)

def paint_obsidian(F):
    for name, f in F.items():
        shade = {"top": 1.3, "bottom": 0.7, "east": 0.95, "west": 0.95, "front": 1.0, "back": 0.9}[name]
        f.fill(OBS, shade)
        f.outline(shade_col(OBS_EDGE, shade * 0.85))

def paint(b):
    k = b["kind"]
    F = {n: Face(r) for n, r in faces(b).items()}
    w, h, d = [int(v) for v in b["size"]]

    if k == "torso":
        paint_charcoal(F)
        for n in ("front", "back", "east", "west"):
            seams(F[n], 8, 8, c(24, 16, 14))
        # chest: ribbed lava V-lines under the core + sun rays around it
        f = F["front"]
        cx, cy = 12, 10
        for ang in range(0, 360, 45):
            for r in range(5, 9):
                x_ = int(round(cx + math.cos(math.radians(ang)) * r))
                y_ = int(round(cy + math.sin(math.radians(ang)) * r))
                if r in (5, 6, 8): lava_px(f, x_, y_, 0.6)
        for i in range(0, 8):  # chevrons
            lava_px(f, 12 - i, 15 + i // 2, 0.4); lava_px(f, 11 + i, 15 + i // 2, 0.4)
        for yy in range(18, 24, 2):
            for xx in (3, 4, 19, 20): f.put(xx, yy, L_DEEP)
        cracks(f, 5, 4, 9, 0.6)
        for n in ("east", "west"):
            cracks(F[n], 3, 5, 10, 0.8)
        cracks(F["back"], 5, 5, 11, 0.7)
        # shoulder line
        cracks(F["top"], 3, 3, 8, 0.7)
    elif k == "belt":
        paint_obsidian(F)
        f = F["front"]
        for xx in (2, 7, 12, 17):
            f.rect(xx, 1, 4, 3, L_MID)
            f.rect(xx + 1, 2, 2, 1, L_WHITE)
        for n in ("east", "west", "back"):
            dashes(F[n], 2, 2, F[n].w - 2, 4, 3, L_MID, L_CORE)
    elif k == "core":
        for n, f in F.items():
            for yy in range(f.h):
                for xx in range(f.w):
                    dd = math.hypot(xx - (f.w - 1) / 2, yy - (f.h - 1) / 2) / (max(f.w, f.h) / 2)
                    f.put(xx, yy, blend(L_WHITE, L_MID, min(1, dd * 1.3)) if dd < 1 else L_DEEP)
    elif k == "backplate":
        paint_obsidian(F)
        f = F["back"]
        # dashed orange frame
        for xx in range(1, f.w - 1):
            if xx % 3 != 2: f.put(xx, 1, L_MID); f.put(xx, f.h - 2, L_MID)
        for yy in range(1, f.h - 1):
            if yy % 3 != 2: f.put(1, yy, L_MID); f.put(f.w - 2, yy, L_MID)
        f.rect(f.w // 2 - 1, f.h // 2 - 1, 2, 2, L_DEEP)
    elif k == "head":
        paint_charcoal(F)
        for n in ("east", "west", "back", "top"):
            seams(F[n], 6, 6, c(24, 16, 14))
            cracks(F[n], 3, 4, 8, 0.9)
        f = F["front"]
        f.fill(CHAR, 1.0)
        # brow shadow
        f.rect(0, 0, 12, 3, shade_col(OBS[0], 1.0))
        for xx in range(12): f.put(xx, 3, shade_col(OBS[1], 0.9))
        # eyes
        for ex in (2, 7):
            f.rect(ex, 4, 3, 2, L_CORE)
            f.put(ex + 1, 4, L_WHITE); f.put(ex + 1, 5, L_WHITE)
            for xx in range(ex - 1, ex + 4): f.put(xx, 6, blend(f.get(xx, 6), L_DEEP, 0.8)) if 0 <= xx < 12 else None
        # glowing mouth with fangs
        f.rect(1, 7, 10, 4, L_MID)
        f.rect(2, 8, 8, 2, L_HOT)
        f.rect(4, 8, 4, 1, L_CORE)
        for xx in (2, 4, 7, 9):
            f.put(xx, 7, TOOTH); f.put(xx, 8, TOOTH)
        for xx in (3, 5, 6, 8):
            f.put(xx, 10, TOOTH)
        for xx in range(0, 12):
            f.put(xx, 11, shade_col(OBS[2], 1.0))
        f.put(0, 7, L_DEEP); f.put(11, 7, L_DEEP)
        cracks(f, 1, 3, 5, 0.5)
    elif k == "crown":
        paint_obsidian(F)
        f = F["front"]
        for xx in range(2, 12, 3): f.rect(xx, 1, 2, 1, L_MID)
        for n in ("east", "west", "back"):
            for xx in range(2, F[n].w - 1, 3): F[n].rect(xx, 1, 2, 1, L_MID)
        cracks(F["top"], 3, 3, 7, 0.8)
    elif k == "horn":
        paint_obsidian(F)
        for n in ("east", "west", "front", "back"):
            f = F[n]
            for yy in range(f.h):  # lava creeping up toward the tip
                if yy < 2:
                    for xx in range(f.w): f.put(xx, yy, blend(f.get(xx, yy), L_DEEP, 0.6))
    elif k == "tip":
        for n, f in F.items():
            for yy in range(f.h):
                for xx in range(f.w):
                    t = (yy / max(1, f.h - 1))
                    col = blend(L_CORE, L_MID, t)
                    if n == "top": col = L_WHITE
                    if n == "bottom": col = L_DEEP
                    f.put(xx, yy, col)
    elif k == "arm":
        paint_charcoal(F)
        for n in ("front", "back", "east", "west"):
            seams(F[n], 8, 9, c(24, 16, 14))
        f = F["front"]
        # bright vertical vein + diagonal lava patch near the shoulder (as in the reference)
        for yy in range(3, 15):
            f.put(2, yy, L_HOT); f.put(3, yy, L_CORE if yy % 3 else L_MID)
            f.put(1, yy, blend(f.get(1, yy), L_DEEP, 0.7))
        for i in range(0, 6):
            for j in range(0, 6 - i):
                f.put(5 + i, 1 + j, L_HOT if (i + j) % 3 else L_CORE)
        cracks(f, 2, 3, 7, 0.6)
        for n in ("east", "west"):
            cracks(F[n], 3, 4, 9, 0.8)
            for yy in range(3, 14): F[n].put(3, yy, L_MID if yy % 2 else L_HOT)
        cracks(F["back"], 4, 4, 9, 0.7)
    elif k == "pad":
        paint_obsidian(F)
        for n in ("front", "back", "east", "west"):
            f = F[n]
            dashes(f, 2, 1, f.w - 1, 3, 1, L_MID, L_CORE)
            dashes(f, 4, 2, f.w - 2, 4, 1, L_MID, L_CORE)
        cracks(F["top"], 4, 4, 9, 0.8)
    elif k == "fist":
        paint_charcoal(F)
        for n in ("front", "back", "east", "west", "bottom"):
            f = F[n]
            seams(f, 5, 4, c(24, 16, 14))
            dots(f, f.w * f.h // 4, (0, f.h // 2, f.w, f.h - f.h // 2))
        cracks(F["front"], 2, 3, 6, 0.9)
        cracks(F["top"], 2, 3, 6, 0.8)
    elif k == "leg":
        paint_charcoal(F)
        for n in ("front", "back", "east", "west"):
            f = F[n]
            seams(f, 8, 8, c(24, 16, 14))
            cracks(f, 4, 5, 11, 0.9)
            # denser glow toward the ankle
            dots(f, 10, (0, f.h - 5, f.w, 5))
    elif k == "knee":
        paint_obsidian(F)
        f = F["front"]
        f.rect(1, 1, f.w - 2, f.h - 2, shade_col(OBS[2], 1.0))
        f.outline(OBS_EDGE)
        f.rect(f.w // 2 - 1, f.h // 2 - 1, 2, 2, L_DEEP)
    elif k == "boot":
        paint_obsidian(F)
        for n in ("front", "back", "east", "west"):
            f = F[n]
            dashes(f, 1 if n in ("east", "west") else 1, 2, f.w - 2, 3, 2, L_MID, L_CORE)
        cracks(F["top"], 2, 3, 6, 0.8)

for b in sorted(B, key=lambda b: 0):
    paint(b)

img.save(OUT_TEX)

# ---------------------------------------------------------------- boss bar sprites (182x5)
def bar(bg):
    im = Image.new("RGBA", (182, 5), (0, 0, 0, 0))
    p = im.load()
    for xx in range(182):
        for yy in range(5):
            if bg:
                base = OBS[(xx * 7 + yy * 3) % len(OBS)]
                col = shade_col(base, 0.9 if yy in (0, 4) else 1.0)
                if yy == 2 and xx % 14 < 2: col = blend(col, L_DEEP, 0.55)
                if xx in (0, 181): col = OBS_EDGE
                p[xx, yy] = col
            else:
                # molten gradient: deep red edges, orange body, bright core line, with moving-looking flecks
                rows = [L_DEEP, L_MID, L_CORE, L_MID, L_DEEP]
                col = rows[yy]
                if yy == 2 and (xx * 5) % 17 < 3: col = L_WHITE
                if yy in (1, 3) and (xx * 3) % 11 == 0: col = L_HOT
                p[xx, yy] = col
    return im
bar(True).save(OUT_BAR_BG)
bar(False).save(OUT_BAR_FG)

# ---------------------------------------------------------------- Java model generation
def f(v):
    s = ("%g" % v)
    return s + "F"

lines = []
for b in B:
    var = "p_" + b["name"]
    parent = "root" if b["parent"] is None else "p_" + b["parent"]
    ox, oy, oz = b["origin"]; w, h, d = b["size"]
    px_, py_, pz_ = b["pivot"]; rx, ry, rz = b["rot"]
    pose = ("PartPose.offset(%s, %s, %s)" % (f(px_), f(py_), f(pz_))) if (rx, ry, rz) == (0, 0, 0) else \
           ("PartPose.offsetAndRotation(%s, %s, %s, %s, %s, %s)" % (f(px_), f(py_), f(pz_), f(rx), f(ry), f(rz)))
    lines.append(
        '\t\tPartDefinition %s = %s.addOrReplaceChild("%s",\n'
        '\t\t\t\tCubeListBuilder.create().texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s),\n'
        '\t\t\t\t%s);' % (var, parent, b["name"], b["u"], b["v"], f(ox), f(oy), f(oz), f(w), f(h), f(d), pose))

java = '''package com.elementalarsenal.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Model of the Inferno Colossus.
 * NOTE: this file is generated together with the texture (tools/gen_monster.py) so every UV offset matches the PNG.
 */
public class FireMonsterModel extends EntityModel<FireMonsterRenderState> {
	private final ModelPart head;
	private final ModelPart rightArm;
	private final ModelPart leftArm;
	private final ModelPart rightLeg;
	private final ModelPart leftLeg;
	private final ModelPart body;

	public FireMonsterModel(ModelPart root) {
		super(root);
		this.body = root.getChild("body");
		this.head = root.getChild("head");
		this.rightArm = root.getChild("arm_r");
		this.leftArm = root.getChild("arm_l");
		this.rightLeg = root.getChild("leg_r");
		this.leftLeg = root.getChild("leg_l");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

%s

		return LayerDefinition.create(mesh, %d, %d);
	}

	@Override
	public void setupAnim(FireMonsterRenderState state) {
		super.setupAnim(state);

		float walkPos = state.walkAnimationPos;
		float walkSpeed = Math.min(state.walkAnimationSpeed, 1.0F);
		float age = state.ageInTicks;

		// Look direction
		this.head.yRot = state.yRot * Mth.DEG_TO_RAD;
		this.head.xRot = state.xRot * Mth.DEG_TO_RAD;

		// Heavy, slow walk cycle
		this.rightLeg.xRot = Mth.cos(walkPos * 0.5F) * 1.1F * walkSpeed;
		this.leftLeg.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 1.1F * walkSpeed;
		this.rightArm.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 0.7F * walkSpeed;
		this.leftArm.xRot = Mth.cos(walkPos * 0.5F) * 0.7F * walkSpeed;
		this.body.yRot = Mth.cos(walkPos * 0.5F) * 0.06F * walkSpeed;

		// Idle breathing
		this.rightArm.zRot = -0.05F - Mth.sin(age * 0.08F) * 0.03F;
		this.leftArm.zRot = 0.05F + Mth.sin(age * 0.08F) * 0.03F;

		switch (state.attackState) {
			case FireMonsterRenderState.STATE_NOVA -> {
				// Arms raised high while gathering energy
				float shake = Mth.sin(age * 1.6F) * 0.04F;
				this.rightArm.xRot = -2.6F + shake;
				this.leftArm.xRot = -2.6F - shake;
				this.rightArm.zRot = -0.35F;
				this.leftArm.zRot = 0.35F;
				this.head.xRot -= 0.35F;
			}
			case FireMonsterRenderState.STATE_LANCE -> {
				// Both fists pointed forward
				this.rightArm.xRot = -1.55F;
				this.leftArm.xRot = -1.55F;
				this.rightArm.zRot = -0.12F;
				this.leftArm.zRot = 0.12F;
			}
			case FireMonsterRenderState.STATE_ERUPTION -> {
				// Fists slammed down toward the ground
				float pulse = Mth.sin(age * 0.9F) * 0.12F;
				this.rightArm.xRot = -0.9F + pulse;
				this.leftArm.xRot = -0.9F - pulse;
				this.rightArm.zRot = -0.5F;
				this.leftArm.zRot = 0.5F;
				this.head.xRot += 0.25F;
			}
			default -> {
				// Regular melee swing
				if (state.attackAnim > 0.0F) {
					float swing = Mth.sin(state.attackAnim * Mth.PI);
					this.rightArm.xRot = -swing * 2.2F;
					this.leftArm.xRot = -swing * 2.2F;
				}
			}
		}
	}
}
''' % ("\n".join(lines), TEX_W, TEX_H)

open(OUT_JAVA, "w").write(java)
print("boxes:", len(B), "texture used height:", max(b["v"] + box_extent(b)[1] for b in B))
