#!/usr/bin/env python3
"""Ice spike used by the Glacial Warlord's special attacks (shown through an item_display entity, so it is never solid).
Generates the 16x16 texture and the 3D item model (a stack of tapering crystal layers + leaning side shards).

usage: gen_ice_spike.py <out_texture.png> <out_model.json>
"""
import json, random, sys
from PIL import Image

random.seed(3)
TEX, MODEL = sys.argv[1], sys.argv[2]


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


# one 4-pixel band per layer: deep blue base -> blue -> silver-cyan -> white-hot tip
BANDS = [((22, 70, 180), (40, 100, 210)), ((56, 130, 232), (96, 176, 246)),
         ((168, 218, 250), (214, 242, 255)), ((240, 252, 255), (255, 255, 255))]
im = Image.new("RGBA", (16, 16))
for b, (top, bottom) in enumerate(BANDS):
    for y in range(4):
        for x in range(16):
            c = lerp(top, bottom, y / 3)
            if (x + y * 3) % 7 == 0:
                c = lerp(c, (255, 255, 255), 0.35)
            if random.random() < 0.06:
                c = (255, 255, 255)
            im.putpixel((x, b * 4 + y), c + (255,))
im.save(TEX)

E = []


def box(frm, to, band, rot=None):
    el = {"from": frm, "to": to, "faces": {}}
    for f in ("north", "east", "south", "west", "up", "down"):
        el["faces"][f] = {"uv": [0, band * 4, 16, band * 4 + 4], "texture": "#0"}
    if rot:
        el["rotation"] = {"angle": rot[1], "axis": rot[0], "origin": rot[2]}
    E.append(el)


# tapering crystal tower (each layer doubled and turned 45 degrees -> an 8 sided spire)
for band, (y0, y1, hw) in enumerate(((0, 5, 4.2), (5, 10.5, 3.0), (10.5, 15.5, 1.9), (15.5, 20, 0.9))):
    box([8 - hw, y0, 8 - hw], [8 + hw, y1, 8 + hw], band)
    box([8 - hw, y0, 8 - hw], [8 + hw, y1, 8 + hw], band, ("y", 45, [8, (y0 + y1) / 2, 8]))
# four leaning side shards around the base
for ax, ang, dx, dz in (("z", -22.5, 3.6, 0), ("z", 22.5, -3.6, 0), ("x", 22.5, 0, 3.6), ("x", -22.5, 0, -3.6)):
    box([8 + dx - 0.9, 0, 8 + dz - 0.9], [8 + dx + 0.9, 9.5, 8 + dz + 0.9], 2, (ax, ang, [8 + dx, 0, 8 + dz]))
    box([8 + dx - 0.5, 8.5, 8 + dz - 0.5], [8 + dx + 0.5, 12, 8 + dz + 0.5], 3, (ax, ang, [8 + dx, 0, 8 + dz]))
json.dump({"textures": {"0": "elementalarsenal:item/ice_spike", "particle": "elementalarsenal:item/ice_spike"},
           "elements": E}, open(MODEL, "w"), indent=1)
print("elements:", len(E))
