#!/usr/bin/env python3
"""Glacial Warlord (ice boss) - generates the texture PNG and the Java model class from ONE part list,
so every UV offset in the model always matches the painted texture.

usage: gen_ice_monster.py <out_texture.png> <out_IceMonsterModel.java> [preview_prefix]
"""
import math, random, sys
from PIL import Image

OUT_TEX = sys.argv[1]
OUT_JAVA = sys.argv[2]
PREVIEW = sys.argv[3] if len(sys.argv) > 3 else None

TEX_W, TEX_H = 256, 256
PI = math.pi

# ------------------------------------------------------------------ part list
P = []          # ordered list of dicts
BYNAME = {}


def part(name, parent, mat, size=None, origin=(0, 0, 0), pivot=(0, 0, 0), rot=(0, 0, 0), tip_down=False):
    d = dict(name=name, parent=parent, mat=mat, size=size, origin=origin, pivot=pivot, rot=rot, tip_down=tip_down)
    P.append(d)
    BYNAME[name] = d
    return d


def mirror_rot(rot, s):
    # s = -1 right side, +1 left side. Geometry is authored for the left (+x) side.
    return (rot[0], rot[1] * s, rot[2] * s)


# ---------------------------------------------------------------- BODY
part("body", None, "cloth_armor", (14, 20, 10), (-7, -20, -5), (0, 4, 0))
part("chest", "body", "plate", (16, 11, 12), (-8, -19, -6))
part("belt", "body", "trim", (16, 4, 12), (-8, -3, -6))
part("buckle", "body", "gem", (6, 4, 2), (-3, -3, -8))
part("core_main", "body", "core", (4, 10, 3), (-2, -5, -3), (0, -14, -6))
for s, sx in (("l", 1), ("r", -1)):
    part(f"core_side_{s}", "body", "core", (3, 7, 3), (-1.5, -7, -1.5), (sx * 5, -11, -6.5), (0, 0, sx * 0.6))
part("collar", "body", "fur", (20, 5, 13), (-10, -20, -6.5))
for s, sx in (("l", 1), ("r", -1)):
    part(f"spire_a_{s}", "body", "crystal", (4, 12, 2), (-2, -12, -1), (sx * 7, -20, 3), (0.2, 0, sx * 0.3))
    part(f"spire_b_{s}", "body", "crystal", (3, 8, 2), (-1.5, -8, -1), (sx * 10, -19, 2), (0.15, 0, sx * 0.75))
# tassets / skirt (royal robe)
part("skirt_f", "body", "cloth_royal", (12, 11, 2), (-6, 0, -1), (0, 0, -6), (-0.10, 0, 0))
part("hem_f", "skirt_f", "trim", (14, 3, 4), (-7, 0, -2), (0, 9, 0))
part("skirt_b", "body", "cloth_royal", (12, 11, 2), (-6, 0, -1), (0, 0, 6), (0.10, 0, 0))
part("hem_b", "skirt_b", "trim", (14, 3, 4), (-7, 0, -2), (0, 9, 0))

# ---------------------------------------------------------------- HEAD
part("head", None, "face", (12, 12, 12), (-6, -12, -6), (0, -16, 0))
part("helm_back", "head", "plate", (14, 14, 8), (-7, -13, -1))
part("brow", "head", "plate_dark", (14, 3, 2), (-7, -10, -8))
part("cheek_l", "head", "plate", (3, 8, 9), (6, -8, -4))
part("cheek_r", "head", "plate", (3, 8, 9), (-9, -8, -4))
part("chin", "head", "crystal", (4, 9, 4), (-2, 0, -2), (0, 0, -5), (-0.22, 0, 0), tip_down=True)
for s, sx in (("l", 1), ("r", -1)):
    part(f"chin_{s}", "head", "crystal", (2, 5, 2), (-1, 0, -1), (sx * 3.5, 0, -5), (-0.20, 0, sx * 0.2), tip_down=True)
part("crown_ring", "head", "trim", (15, 3, 15), (-7.5, -15, -7.5))
part("crown_gem", "head", "gem", (4, 5, 2), (-2, -5, -1), (0, -12.5, -8))
part("crown_c", "head", "crystal", (4, 14, 4), (-2, -14, -2), (0, -15, 0))
for s, sx in (("l", 1), ("r", -1)):
    part(f"crown_f_{s}", "head", "crystal", (3, 11, 3), (-1.5, -11, -1.5), (sx * 4.5, -15, 0), (0, 0, sx * 0.30))
    part(f"crown_o_{s}", "head", "crystal", (3, 8, 3), (-1.5, -8, -1.5), (sx * 6.5, -14, 0), (0, 0, sx * 0.62))
    part(f"crown_b_{s}", "head", "crystal", (3, 9, 3), (-1.5, -9, -1.5), (sx * 3.5, -15, 5), (-0.45, 0, sx * 0.15))
part("crown_bc", "head", "crystal", (3, 10, 3), (-1.5, -10, -1.5), (0, -15, 6), (-0.6, 0, 0))

# ---------------------------------------------------------------- ARMS (+scepter on the right hand)
for s, sx in (("l", 1), ("r", -1)):
    part(f"arm_{s}", None, "cloth_armor", (6, 12, 6), (-3, -2, -3), (sx * 11, -12, 0))
    part(f"fore_{s}", f"arm_{s}", "plate", (7, 12, 7), (-3.5, 9, -3.5))
    part(f"hand_{s}", f"arm_{s}", "ice", (6, 3, 6), (-3, 21, -3))
    for i, (fx, fz, fr) in enumerate(((-2, -1.5, -0.10), (0, -2, -0.25), (2, -1.5, -0.10))):
        part(f"finger{i}_{s}", f"arm_{s}", "crystal", (2, 6, 2), (-1, 0, -1), (fx, 24, fz), (fr, 0, 0), tip_down=True)
    part(f"pauld1_{s}", f"arm_{s}", "plate", (11, 4, 11), (-5.5, -7, -5.5))
    part(f"pauld2_{s}", f"arm_{s}", "trim", (9, 3, 9), (-4.5, -10, -4.5))
    part(f"pspike_a_{s}", f"arm_{s}", "crystal", (4, 13, 4), (-2, -13, -2), (sx * 1, -10, 0), (0, 0, sx * 0.45))
    part(f"pspike_b_{s}", f"arm_{s}", "crystal", (3, 9, 3), (-1.5, -9, -1.5), (0, -9, 3), (-0.5, 0, sx * 0.2))
    part(f"pspike_c_{s}", f"arm_{s}", "crystal", (3, 8, 3), (-1.5, -8, -1.5), (sx * 1, -9, -3), (0.4, 0, sx * 0.2))
    part(f"elbow_{s}", f"arm_{s}", "crystal", (3, 8, 3), (-1.5, -8, -1.5), (sx * 3, 9, 0), (-0.3, 0, sx * 1.45))
# scepter (held in the right hand, in front of the fist)
part("scepter", "arm_r", "trim", (2, 56, 2), (-1, -45, -1), (0, 23, -6))
part("scepter_grip", "scepter", "plate_dark", (4, 6, 4), (-2, -3, -2), (0, 0, 0))
part("scepter_guard", "scepter", "trim", (8, 2, 8), (-4, -1, -4), (0, -45, 0))
part("scepter_gem", "scepter", "core", (6, 12, 6), (-3, -12, -3), (0, -46, 0))
for s, sx in (("l", 1), ("r", -1)):
    part(f"scepter_prong_{s}", "scepter", "crystal", (2, 9, 2), (-1, -9, -1), (sx * 4, -45, 0), (0, 0, sx * 0.6))
part("scepter_prong_f", "scepter", "crystal", (2, 9, 2), (-1, -9, -1), (0, -45, -4), (0.6, 0, 0))
part("scepter_prong_b", "scepter", "crystal", (2, 9, 2), (-1, -9, -1), (0, -45, 4), (-0.6, 0, 0))

# ---------------------------------------------------------------- LEGS
for s, sx in (("l", 1), ("r", -1)):
    part(f"leg_{s}", None, "plate_dark", (7, 20, 7), (-3.5, 0, -3.5), (sx * 5, 4, 0))
    part(f"thigh_{s}", f"leg_{s}", "plate", (9, 9, 9), (-4.5, 0, -4.5))
    part(f"cuff_{s}", f"leg_{s}", "trim", (10, 3, 10), (-5, 13, -5))
    part(f"boot_{s}", f"leg_{s}", "plate", (9, 5, 11), (-4.5, 15, -6.5))
    part(f"knee_{s}", f"leg_{s}", "crystal", (3, 3, 5), (-1.5, -1.5, -5), (0, 11, -4.5), (0.4, 0, 0))
    part(f"toe_{s}", f"leg_{s}", "crystal", (3, 2, 5), (-1.5, 0, -5), (0, 17, -6.5), (-0.2, 0, 0))

# ---------------------------------------------------------------- CAPE
part("cape", None, "cape", (16, 30, 2), (-8, 0, 0), (0, -15, 6.5), (0.08, 0, 0))
part("cape_hem", "cape", "fur", (18, 4, 4), (-9, 0, -1), (0, 28, 0))
part("cape_mantle", "cape", "fur", (18, 5, 4), (-9, -1, -1), (0, 0, 0))

# ---------------------------------------------------------------- WINGS (fan of crystal blades)
WING_BASE = dict(l=(0, -0.55, 0), r=(0, 0.55, 0))
for s, sx in (("l", 1), ("r", -1)):
    part(f"wing_{s}", None, None, None, pivot=(sx * 4, -13, 9), rot=WING_BASE[s])
    part(f"wroot_{s}", f"wing_{s}", "plate", (7, 7, 7), (-3.5, -3.5, -3.5))
    # back layer (darker, shorter) then front layer (bright, long): radiating from the shoulder blade
    for i, (ang, L) in enumerate(((55, 20), (80, 23), (105, 22), (130, 17))):
        part(f"wb{i}_{s}", f"wing_{s}", "crystal_dark", (3, L, 2), (-1.5, -L, -1), (0, 0, 3), (0, 0, sx * math.radians(ang)))
    for i, (ang, L) in enumerate(((42, 30), (66, 36), (92, 34), (118, 28), (140, 20))):
        part(f"wf{i}_{s}", f"wing_{s}", "wing", (4, L, 2), (-2, -L, -1), (0, 0, 0), (0, 0, sx * math.radians(ang)))

# ---------------------------------------------------------------- HALO (crown of rays behind the head)
part("halo", None, None, None, pivot=(0, -25, 11))
N_HALO = 12
for k in range(N_HALO):
    a = 2 * PI * k / N_HALO
    x, y = 12 * math.sin(a), -12 * math.cos(a)
    part(f"halo_seg{k}", "halo", "trim", (5, 4, 2), (-2.5, -2, -1), (x, y, 0), (0, 0, a))
    if k % 2 == 0:
        L = 11 if k % 4 == 0 else 7
        part(f"halo_ray{k}", "halo", "crystal_bright", (3, L, 2), (-1.5, -L, -1), (x, y, 0), (0, 0, a))

# ---------------------------------------------------------------- ORBITING SHARDS
part("orbit", None, None, None, pivot=(0, -6, 0))
for k in range(6):
    a = 2 * PI * k / 6
    R = 24
    y = -9 if k % 2 == 0 else 5
    phi = math.atan2(-math.cos(a), -math.sin(a))
    part(f"shard{k}", "orbit", "crystal_bright", (4, 12, 4), (-2, -6, -2), (R * math.cos(a), y, R * math.sin(a)), (0.35, phi, 0))

# ---------------------------------------------------------------- FROST SPIKES AROUND THE FEET (static)
for k in range(8):
    a = 2 * PI * (k + 0.5) / 8
    R = 17
    L = 9 if k % 2 == 0 else 6
    phi = math.atan2(-math.cos(a), -math.sin(a))
    part(f"floor{k}", None, "crystal", (4, L, 4), (-2, -L, -2), (R * math.cos(a), 24, R * math.sin(a)), (0.4, phi, 0))

# ------------------------------------------------------------------ UV packing
def extent(p):
    w, h, d = p["size"]
    return int(2 * d + 2 * w), int(d + h)


boxes = [p for p in P if p["size"]]
order = sorted(boxes, key=lambda p: (-extent(p)[1], -extent(p)[0]))
x = y = shelf = 0
for p in order:
    bw, bh = extent(p)
    if x + bw > TEX_W:
        x, y, shelf = 0, y + shelf, 0
    p["u"], p["v"] = x, y
    x += bw
    shelf = max(shelf, bh)
used_h = y + shelf
if used_h > TEX_H:
    raise SystemExit(f"texture too small: need {used_h} rows, have {TEX_H}")
print(f"parts={len(P)} boxes={len(boxes)} texture rows used={used_h}/{TEX_H}")

# ------------------------------------------------------------------ painting
def lerp(a, b, t):
    t = max(0.0, min(1.0, t))
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def h2(u, v, seed=0):
    n = (u * 374761393 + v * 668265263 + seed * 2147483647) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


DEEP = (20, 78, 205)
MID = (50, 165, 245)
PALE = (190, 242, 255)
NAVY = (14, 28, 70)
ROYAL = (30, 62, 140)
SILVER = (196, 216, 238)
CYAN = (110, 236, 255)

SNOW = []
for k in range(6):
    ang = k * PI / 3
    for r in range(0, 8):
        SNOW.append((round(r * math.cos(ang)), round(r * math.sin(ang))))
    for r in (4, 6):
        for sgn in (-1, 1):
            a2 = ang + sgn * PI / 4
            for q in range(1, 3):
                SNOW.append((round(r * math.cos(ang) + q * math.cos(a2)), round(r * math.sin(ang) + q * math.sin(a2))))
SNOW = set(SNOW)


def paint(p, face, fx, fy, fw, fh, seed):
    mat = p["mat"]
    n = h2(fx + seed, fy, seed + 7)
    n2 = h2(fx * 3 + seed, fy * 5, seed + 11)
    t = fy / max(1, fh - 1)
    tipness = (t if p["tip_down"] else 1 - t)
    lit = {"right": 0.82, "front": 1.0, "left": 0.9, "back": 0.74, "top": 1.12, "bottom": 0.6}[face]
    edge_l = fx == 0 or fy == 0
    edge_d = fx == fw - 1 or fy == fh - 1

    if mat in ("crystal", "crystal_bright", "crystal_dark", "wing"):
        def grad(c0, c1, c2, k):
            return lerp(c0, c1, k * 2) if k < 0.5 else lerp(c1, c2, (k - 0.5) * 2)
        if mat == "crystal_dark":
            c = grad((10, 34, 110), (30, 90, 215), (110, 190, 250), tipness)
        elif mat == "crystal_bright":
            c = grad((30, 120, 240), (90, 210, 255), (235, 252, 255), tipness)
        elif mat == "wing":
            c = grad((18, 80, 225), (70, 190, 255), (225, 250, 255), tipness ** 1.2)
        else:
            c = grad((16, 64, 205), (60, 175, 250), (205, 248, 255), tipness ** 1.1)
        c = shade(c, lit)
        if face in ("front", "back") and fx >= fw / 2:
            c = shade(c, 1.12)
        if face in ("front", "back") and fw > 2 and abs(fx - fw / 2) < 0.6:
            c = lerp(c, (240, 252, 255), 0.45)
        if edge_l:
            c = lerp(c, (235, 252, 255), 0.22)
        if edge_d:
            c = shade(c, 0.7)
        if n2 > 0.94:
            c = (240, 252, 255)
        return shade(c, 0.94 + n * 0.12)

    if mat in ("plate", "plate_dark"):
        base = (84, 110, 156) if mat == "plate" else (40, 56, 98)
        c = shade(lerp(base, shade(base, 1.25), 1 - t), lit)
        if edge_l:
            c = lerp(c, (170, 204, 238), 0.55)
        if edge_d:
            c = shade(c, 0.55)
        if fw >= 7 and fh >= 7:
            inset = (fx == 2 or fx == fw - 3 or fy == 2 or fy == fh - 3) and 2 <= fx <= fw - 3 and 2 <= fy <= fh - 3
            if inset:
                c = (30, 48, 96) if mat == "plate" else (24, 36, 72)
            if (fx, fy) in ((1, 1), (fw - 2, 1), (1, fh - 2), (fw - 2, fh - 2)):
                c = (200, 226, 248)
            if (fx + fy) % 6 == 0 and 3 <= fx <= fw - 4 and 3 <= fy <= fh - 4 and mat == "plate":
                c = lerp(c, CYAN, 0.35)
        return shade(c, 0.95 + n * 0.1)

    if mat in ("cloth_armor", "cloth_royal"):
        base = (24, 44, 100) if mat == "cloth_armor" else (28, 56, 128)
        c = shade(base, lit * (1.12 if fx % 2 == 0 else 0.96))
        if (fx + fy) % 5 == 0 or (fx - fy) % 5 == 0:
            c = lerp(c, ROYAL, 0.55)
        if (fx % 5 == 2 and fy % 5 == 2):
            c = lerp(c, CYAN, 0.5)
        if edge_d:
            c = shade(c, 0.6)
        if face == "front" and mat == "cloth_royal" and abs(fx - fw / 2) < 1:
            c = lerp(c, SILVER, 0.7)
        return shade(c, 0.94 + n * 0.12)

    if mat == "cape":
        c = lerp((24, 52, 124), (10, 20, 62), t)
        c = shade(c, lit)
        if (fx + fy * 2) % 9 == 0:
            c = lerp(c, ROYAL, 0.6)
        if n2 > 0.96:
            c = (210, 240, 255)
        if face == "back":
            if fx in (0, fw - 1):
                c = lerp(c, SILVER, 0.7)
            cx, cy = fw // 2, 11
            if (fx - cx, fy - cy) in SNOW:
                c = lerp((120, 220, 255), (240, 255, 255), 1 - abs(fx - cx) / 8)
            if (fx - cx, fy - 25) in {(a, b) for (a, b) in SNOW if abs(a) <= 3 and abs(b) <= 3}:
                c = lerp((90, 190, 245), (200, 245, 255), 0.4)
        return shade(c, 0.95 + n * 0.1)

    if mat == "fur":
        c = lerp((205, 226, 244), (246, 252, 255), n)
        if n2 > 0.8:
            c = (170, 200, 230)
        if edge_d:
            c = shade(c, 0.78)
        return shade(c, lit)

    if mat == "trim":
        c = shade(lerp((176, 198, 226), SILVER, 1 - t), lit)
        if edge_l:
            c = (238, 248, 255)
        if edge_d:
            c = shade(c, 0.6)
        if fw >= 6 and fx % 4 == 2 and fy == fh // 2:
            c = lerp((70, 220, 255), (200, 255, 255), n)
        return shade(c, 0.95 + n * 0.1)

    if mat in ("gem", "core"):
        dx = (fx + 0.5 - fw / 2) / (fw / 2)
        dy = (fy + 0.5 - fh / 2) / (fh / 2)
        dist = min(1.0, math.sqrt(dx * dx + dy * dy))
        c = lerp((250, 255, 255), (70, 215, 255), dist ** 0.8)
        if dist > 0.85:
            c = lerp(c, (30, 120, 225), (dist - 0.85) * 6)
        return shade(c, 0.97 + n * 0.06)

    if mat == "ice":
        c = lerp((150, 200, 232), (222, 244, 255), n)
        if edge_d:
            c = shade(c, 0.75)
        return shade(c, lit)

    if mat == "face":
        c = shade(lerp((92, 136, 188), (130, 176, 214), n), lit)
        if n2 > 0.92:
            c = (200, 230, 248)
        if face == "front":
            # two glowing eyes under a dark brow, nose shading, stern mouth, frost beard line
            for ex in (2, fw - 5):
                if ex <= fx <= ex + 2 and fy in (5, 6):
                    core = (fy == 5 and fx in (ex + 1, ex + 2)) if ex < fw / 2 else (fy == 5 and fx in (ex, ex + 1))
                    return (240, 255, 255) if core else (96, 232, 255)
                if ex - 1 <= fx <= ex + 3 and fy in (4, 7):
                    return lerp(c, (60, 190, 255), 0.65)
            if fy == 3 and (1 <= fx <= 4 or fw - 5 <= fx <= fw - 2):
                return (22, 36, 80)
            if fy == 4 and fx in (0, fw // 2 - 1, fw // 2, fw - 1):
                return (46, 76, 140)
            if fy in (7, 8) and fx in (fw // 2 - 1, fw // 2):
                return shade(c, 0.78)
            if fy == 9 and fw // 2 - 2 <= fx <= fw // 2 + 1:
                return (36, 60, 120)
            if fy == 11 and 2 <= fx <= fw - 3:
                return (232, 246, 255)
        if face == "right" or face == "left":
            if fy in (0, 1):
                c = shade(c, 0.8)
        return shade(c, 0.97 + n * 0.06)

    return (255, 0, 255)


img = Image.new("RGBA", (TEX_W, TEX_H), (0, 0, 0, 0))
px = img.load()
seed_i = 0
for p in boxes:
    seed_i += 1
    w, h, d = p["size"]
    u0, v0 = p["u"], p["v"]
    faces = {
        "right": (0, d, d, h),
        "front": (d, d, w, h),
        "left": (d + w, d, d, h),
        "back": (2 * d + w, d, w, h),
        "top": (d, 0, w, d),
        "bottom": (d + w, 0, w, d),
    }
    for fname, (fx0, fy0, fw, fh) in faces.items():
        for yy in range(fh):
            for xx in range(fw):
                col = paint(p, fname, xx, yy, fw, fh, seed_i)
                px[u0 + fx0 + xx, v0 + fy0 + yy] = tuple(int(v) for v in col) + (255,)
img.save(OUT_TEX)

# ------------------------------------------------------------------ Java output
def f(v):
    s = ("%.4f" % v).rstrip("0").rstrip(".")
    if s in ("-0", ""):
        s = "0"
    return s + "F"


lines = []
w = lines.append
w("package com.elementalarsenal.client;")
w("")
w("import net.minecraft.client.model.EntityModel;")
w("import net.minecraft.client.model.geom.ModelPart;")
w("import net.minecraft.client.model.geom.PartPose;")
w("import net.minecraft.client.model.geom.builders.CubeListBuilder;")
w("import net.minecraft.client.model.geom.builders.LayerDefinition;")
w("import net.minecraft.client.model.geom.builders.MeshDefinition;")
w("import net.minecraft.client.model.geom.builders.PartDefinition;")
w("import net.minecraft.util.Mth;")
w("")
w("/**")
w(" * Model of the Glacial Warlord (ice boss): a crowned ice king with crystal wings, a halo, a cape,")
w(" * a scepter and shards that orbit his body.")
w(" * NOTE: this file is generated together with the texture (tools/gen_ice_monster.py) so every UV offset matches the PNG.")
w(" */")
w("public class IceMonsterModel extends EntityModel<IceMonsterRenderState> {")
BONES = [("body", "body"), ("head", "head"), ("arm_r", "rightArm"), ("arm_l", "leftArm"), ("leg_r", "rightLeg"),
         ("leg_l", "leftLeg"), ("cape", "cape"), ("wing_r", "rightWing"), ("wing_l", "leftWing"),
         ("halo", "halo"), ("orbit", "orbit")]
for _, fld in BONES:
    w(f"\tprivate final ModelPart {fld};")
w("")
w(f"\tpublic IceMonsterModel(ModelPart root) {{")
w("\t\tsuper(root);")
for nm, fld in BONES:
    w(f"\t\tthis.{fld} = root.getChild(\"{nm}\");")
w("\t}")
w("")
w("\tpublic static LayerDefinition createBodyLayer() {")
w("\t\tMeshDefinition mesh = new MeshDefinition();")
w("\t\tPartDefinition root = mesh.getRoot();")
w("")
for p in P:
    parent = "root" if p["parent"] is None else "p_" + p["parent"]
    if p["size"]:
        wd, ht, dp = p["size"]
        ox, oy, oz = p["origin"]
        cube = f"CubeListBuilder.create().texOffs({p['u']}, {p['v']}).addBox({f(ox)}, {f(oy)}, {f(oz)}, {f(wd)}, {f(ht)}, {f(dp)})"
    else:
        cube = "CubeListBuilder.create()"
    px_, py_, pz_ = p["pivot"]
    rx, ry, rz = p["rot"]
    if abs(rx) + abs(ry) + abs(rz) > 1e-6:
        pose = f"PartPose.offsetAndRotation({f(px_)}, {f(py_)}, {f(pz_)}, {f(rx)}, {f(ry)}, {f(rz)})"
    else:
        pose = f"PartPose.offset({f(px_)}, {f(py_)}, {f(pz_)})"
    w(f"\t\tPartDefinition p_{p['name']} = {parent}.addOrReplaceChild(\"{p['name']}\",")
    w(f"\t\t\t\t{cube},")
    w(f"\t\t\t\t{pose});")
w("")
w(f"\t\treturn LayerDefinition.create(mesh, {TEX_W}, {TEX_H});")
w("\t}")
w("")
w("""\t@Override
\tpublic void setupAnim(IceMonsterRenderState state) {
\t\tsuper.setupAnim(state);

\t\tfloat walkPos = state.walkAnimationPos;
\t\tfloat walkSpeed = Math.min(state.walkAnimationSpeed, 1.0F);
\t\tfloat age = state.ageInTicks;

\t\t// Look direction
\t\tthis.head.yRot = state.yRot * Mth.DEG_TO_RAD;
\t\tthis.head.xRot = state.xRot * Mth.DEG_TO_RAD;

\t\t// Smooth, regal walk (the right arm holds the scepter, so it swings less)
\t\tthis.rightLeg.xRot = Mth.cos(walkPos * 0.5F) * 1.0F * walkSpeed;
\t\tthis.leftLeg.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 1.0F * walkSpeed;
\t\tthis.rightArm.xRot = Mth.cos(walkPos * 0.5F + Mth.PI) * 0.25F * walkSpeed;
\t\tthis.leftArm.xRot = Mth.cos(walkPos * 0.5F) * 0.6F * walkSpeed;
\t\tthis.body.yRot = Mth.cos(walkPos * 0.5F) * 0.05F * walkSpeed;

\t\t// Idle breathing
\t\tthis.rightArm.zRot = -0.05F - Mth.sin(age * 0.07F) * 0.03F;
\t\tthis.leftArm.zRot = 0.05F + Mth.sin(age * 0.07F) * 0.03F;

\t\t// Cape billows when he moves
\t\tthis.cape.xRot += walkSpeed * 0.35F + Mth.sin(age * 0.05F) * 0.03F;

\t\t// Slow crystal wing beat
\t\tfloat flap = Mth.sin(age * 0.09F) * 0.10F;
\t\tthis.rightWing.zRot += flap;
\t\tthis.leftWing.zRot -= flap;
\t\tthis.rightWing.yRot += flap * 0.6F;
\t\tthis.leftWing.yRot -= flap * 0.6F;

\t\t// Halo turns, shards orbit and bob
\t\tthis.halo.zRot += age * 0.02F;
\t\tthis.orbit.yRot += age * 0.035F;
\t\tthis.orbit.y += Mth.sin(age * 0.06F) * 2.0F;
\t}
}""")
open(OUT_JAVA, "w").write("\n".join(lines) + "\n")

# ------------------------------------------------------------------ preview renderer (numpy z-buffer)
if PREVIEW:
    import numpy as np

    def rot_m(rx, ry, rz):
        cx, sx_ = math.cos(rx), math.sin(rx)
        cy, sy = math.cos(ry), math.sin(ry)
        cz, sz = math.cos(rz), math.sin(rz)
        Rx = np.array([[1, 0, 0], [0, cx, -sx_], [0, sx_, cx]])
        Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
        Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
        return Rz @ Ry @ Rx

    world = {}

    def get_world(p):
        if p["name"] in world:
            return world[p["name"]]
        if p["parent"]:
            Rp, tp = get_world(BYNAME[p["parent"]])
        else:
            Rp, tp = np.eye(3), np.zeros(3)
        R = rot_m(*p["rot"])
        t = tp + Rp @ np.array(p["pivot"], dtype=float)
        res = (Rp @ R, t)
        world[p["name"]] = res
        return res

    tex = np.array(img)

    def render(yaw, pitch, scale, W, H, fname, yc=-12):
        cy_, sy_ = math.cos(yaw), math.sin(yaw)
        cp, sp = math.cos(pitch), math.sin(pitch)
        V = np.array([[cy_, 0, sy_], [0, 1, 0], [-sy_, 0, cy_]])
        Pm = np.array([[1, 0, 0], [0, cp, -sp], [0, sp, cp]])
        M = Pm @ V
        color = np.zeros((H, W, 3), dtype=np.float32) + np.array([226, 236, 246], dtype=np.float32)
        zbuf = np.full((H, W), 1e9, dtype=np.float32)
        for p in boxes:
            R, t = get_world(p)
            wd, ht, dp = p["size"]
            ox, oy, oz = p["origin"]
            x0, x1, y0, y1, z0, z1 = ox, ox + wd, oy, oy + ht, oz, oz + dp
            u0, v0 = p["u"], p["v"]
            # face: (name, corner origin, edge1, edge2, uv rect (x,y,w,h), u along edge1?)
            def C(x, y, z):
                return R @ np.array([x, y, z], dtype=float) + t
            fdefs = {
                "front": ((x0, y0, z0), (x1, y0, z0), (x0, y1, z0), (dp, dp, wd, ht)),
                "back": ((x1, y0, z1), (x0, y0, z1), (x1, y1, z1), (2 * dp + wd, dp, wd, ht)),
                "right": ((x0, y0, z1), (x0, y0, z0), (x0, y1, z1), (0, dp, dp, ht)),
                "left": ((x1, y0, z0), (x1, y0, z1), (x1, y1, z0), (dp + wd, dp, dp, ht)),
                "top": ((x0, y0, z1), (x1, y0, z1), (x0, y0, z0), (dp, 0, wd, dp)),
                "bottom": ((x0, y1, z0), (x1, y1, z0), (x0, y1, z1), (dp + wd, 0, wd, dp)),
            }
            for fn, (a, b, c, (fx0, fy0, fw, fh)) in fdefs.items():
                A, B_, Cc = C(*a), C(*b), C(*c)
                e1, e2 = B_ - A, Cc - A
                nrm = np.cross(e1, e2)
                nv = M @ nrm
                # camera looks along +z in view space (z grows away); visible if normal faces camera (nz<0)
                if nv[2] <= 0:
                    continue
                pa, pb, pc = M @ A, M @ B_, M @ Cc
                sxs = lambda q: (W / 2 + q[0] * scale, H * 0.50 + (q[1] - yc) * scale)
                (ax, ay), (bx, by), (cx2, cy2) = sxs(pa), sxs(pb), sxs(pc)
                minx = int(max(0, math.floor(min(ax, bx, cx2, bx + cx2 - ax) - 1)))
                maxx = int(min(W - 1, math.ceil(max(ax, bx, cx2, bx + cx2 - ax) + 1)))
                miny = int(max(0, math.floor(min(ay, by, cy2, by + cy2 - ay) - 1)))
                maxy = int(min(H - 1, math.ceil(max(ay, by, cy2, by + cy2 - ay) + 1)))
                if maxx < minx or maxy < miny:
                    continue
                m11, m12, m21, m22 = bx - ax, cx2 - ax, by - ay, cy2 - ay
                det = m11 * m22 - m12 * m21
                if abs(det) < 1e-6:
                    continue
                gx, gy = np.meshgrid(np.arange(minx, maxx + 1), np.arange(miny, maxy + 1))
                dx, dy = gx + 0.5 - ax, gy + 0.5 - ay
                s_ = (dx * m22 - dy * m12) / det
                t_ = (-dx * m21 + dy * m11) / det
                ok = (s_ >= 0) & (s_ < 1) & (t_ >= 0) & (t_ < 1)
                if not ok.any():
                    continue
                z = pa[2] + s_ * (pb[2] - pa[2]) + t_ * (pc[2] - pa[2])
                tu = np.clip((u0 + fx0 + s_ * fw).astype(int), 0, TEX_W - 1)
                tv = np.clip((v0 + fy0 + t_ * fh).astype(int), 0, TEX_H - 1)
                texel = tex[tv, tu]
                ok &= texel[..., 3] > 0
                ok &= z < zbuf[miny:maxy + 1, minx:maxx + 1]
                light = 0.62 + 0.38 * max(0.0, float(nv[2] / (np.linalg.norm(nv) + 1e-9)))
                sub = color[miny:maxy + 1, minx:maxx + 1]
                zs = zbuf[miny:maxy + 1, minx:maxx + 1]
                sub[ok] = texel[..., :3][ok] * light
                zs[ok] = z[ok]
        Image.fromarray(np.clip(color, 0, 255).astype(np.uint8)).save(fname)

    render(0.0, 0.0, 7.0, 760, 700, PREVIEW + "_front.png")
    render(0.6, 0.15, 7.0, 760, 700, PREVIEW + "_threequarter.png")
    render(PI, 0.0, 7.0, 760, 700, PREVIEW + "_back.png")
    render(-PI / 2 + 0.2, 0.1, 7.0, 760, 700, PREVIEW + "_side.png")
    render(0.0, 0.0, 22.0, 760, 700, PREVIEW + "_head.png", yc=-22)
    render(0.5, 0.1, 22.0, 760, 700, PREVIEW + "_head34.png", yc=-22)
