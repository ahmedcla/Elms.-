#!/usr/bin/env python3
"""Builds the Glacial Citadel structure template (.nbt) for the Elemental Arsenal mod: an ice castle with 7 halls.

  * 1 main hall (the only open one): grand gate, quartz pillars, ice throne, and the glacial seal in the arena.
  * 6 locked rooms (3 in each wing): fully enclosed by unbreakable frostbound bricks, no doors.

usage: gen_castle.py <out.nbt> [preview_prefix]
"""
import gzip, math, random, struct, sys

OUT = sys.argv[1]
PREVIEW = sys.argv[2] if len(sys.argv) > 2 else None
rng = random.Random(20261025)

W, H, D = 73, 58, 66
FL = 12                       # floor layer
CX = 36                       # centre axis (x)
ARENA = (36, 32)              # centre of the boss arena (x, z)
G = {}

AIR = "minecraft:air"
FROST = "elementalarsenal:frostbound_bricks"        # unbreakable
SEAL = "elementalarsenal:glacial_seal"              # unbreakable, glowing
GATE = "elementalarsenal:frostbound_gate"           # looks like FROST; IceHallTrigger removes it when the Warlord falls

SB = "minecraft:stone_bricks"
CSB = "minecraft:cracked_stone_bricks"
CSBX = "minecraft:chiseled_stone_bricks"
PI = "minecraft:packed_ice"
BI = "minecraft:blue_ice"
SNOW = "minecraft:snow_block"
Q = "minecraft:quartz_block"
QB = "minecraft:quartz_bricks"
SQ = "minecraft:smooth_quartz"
CQ = "minecraft:chiseled_quartz_block"
QP = "minecraft:quartz_pillar[axis=y]"
PD = "minecraft:polished_diorite"
PRB = "minecraft:prismarine_bricks"
DPR = "minecraft:dark_prismarine"
SEA = "minecraft:sea_lantern"
GLASS = "minecraft:light_blue_stained_glass"
CARPET = "minecraft:light_blue_carpet"
STONE = "minecraft:stone"
COBBLE = "minecraft:cobblestone"
ANDESITE = "minecraft:andesite"


def stairs(kind, facing, half="bottom"):
    return f"minecraft:{kind}_stairs[facing={facing},half={half},shape=straight,waterlogged=false]"


def slab(kind, typ="bottom"):
    return f"minecraft:{kind}_slab[type={typ},waterlogged=false]"


def pick(*weighted):
    total = sum(w for _, w in weighted)

    def f():
        r = rng.uniform(0, total)
        for b, w in weighted:
            r -= w
            if r <= 0:
                return b
        return weighted[-1][0]
    return f


WALL = pick((SB, 56), (CSB, 12), (PI, 10), (SNOW, 6), (PD, 6), (SB, 10))
FOUND = pick((STONE, 40), (COBBLE, 30), (ANDESITE, 15), (PI, 10), (SB, 5))
FLOOR = pick((SQ, 56), (QB, 26), (PD, 18))
ROOF = pick((PI, 54), (SNOW, 28), (BI, 18))
TOWER = pick((SB, 58), (CSB, 12), (PI, 14), (SNOW, 8), (PD, 8))


def put(x, y, z, b):
    if 0 <= x < W and 0 <= y < H and 0 <= z < D:
        G[(x, y, z)] = b() if callable(b) else b


def fill(x0, y0, z0, x1, y1, z1, b):
    for x in range(min(x0, x1), max(x0, x1) + 1):
        for y in range(min(y0, y1), max(y0, y1) + 1):
            for z in range(min(z0, z1), max(z0, z1) + 1):
                put(x, y, z, b)


def fill_keep(x0, y0, z0, x1, y1, z1, b):
    """like fill, but never overwrites the unbreakable frostbound shell"""
    for x in range(min(x0, x1), max(x0, x1) + 1):
        for y in range(min(y0, y1), max(y0, y1) + 1):
            for z in range(min(z0, z1), max(z0, z1) + 1):
                if G.get((x, y, z)) != FROST:
                    put(x, y, z, b)


def carve(x0, y0, z0, x1, y1, z1):
    fill(x0, y0, z0, x1, y1, z1, AIR)


def ring(x0, z0, x1, z1, y, b):
    for x in range(x0, x1 + 1):
        put(x, y, z0, b)
        put(x, y, z1, b)
    for z in range(z0, z1 + 1):
        put(x0, y, z, b)
        put(x1, y, z, b)


def crenellate(x0, z0, x1, z1, y, b=SB):
    """merlons on every second block of a rectangle's rim"""
    for x in range(x0, x1 + 1):
        for z in (z0, z1):
            if (x + z) % 2 == 0:
                put(x, y, z, b)
    for z in range(z0, z1 + 1):
        for x in (x0, x1):
            if (x + z) % 2 == 0:
                put(x, y, z, b)


def cone(cx, cz, half, y0, kind="prismarine_brick", block=PRB):
    """square pyramid roof of stairs; filled inside so it is solid"""
    for i in range(half + 1):
        r = half - i
        y = y0 + i
        if r == 0:
            put(cx, y, cz, block)
            break
        fill(cx - r + 1, y, cz - r + 1, cx + r - 1, y, cz + r - 1, block)
        for x in range(cx - r, cx + r + 1):
            for z in range(cz - r, cz + r + 1):
                dx, dz = x - cx, z - cz
                if max(abs(dx), abs(dz)) != r:
                    continue
                if abs(dx) == r and abs(dz) == r:
                    put(x, y, z, block)
                elif abs(dz) == r:
                    put(x, y, z, stairs(kind, "south" if dz < 0 else "north"))
                else:
                    put(x, y, z, stairs(kind, "east" if dx < 0 else "west"))
    return y0 + half


def spire(x, y, z, n=3):
    for i in range(n):
        put(x, y + i, z, "minecraft:end_rod[facing=up]" if i else BI)


def lantern(x, y, z, hanging=True, soul=True):
    put(x, y, z, f"minecraft:{'soul_' if soul else ''}lantern[hanging={'true' if hanging else 'false'},waterlogged=false]")


def window_slit(x, y, z, axis, sign):
    """glowing window set into a solid wall: glass at the face, sea lantern right behind it"""
    for dy in range(3):
        if axis == "x":
            put(x, y + dy, z, GLASS)
            put(x - sign, y + dy, z, SEA)
        else:
            put(x, y + dy, z, GLASS)
            put(x, y + dy, z - sign, SEA)


# ================================================================== 1. foundation, floor, terrace steps
for y in range(0, FL):
    inset = (FL - 1 - y) // 2
    fill(3 + inset, y, 2 + inset, 69 - inset, y, 61 - inset, FOUND)
    fill(24 + inset // 2, y, 0, 48 - inset // 2, y, 7, FOUND)          # front terrace
for x in range(4, 69):
    for z in range(6, 59):
        put(x, FL, z, FLOOR)
fill(24, FL, 3, 48, FL, 7, QB)
# four broad steps down to the ground in front of the gate
for i, (y, z) in enumerate(((FL, 4), (FL - 1, 3), (FL - 2, 2), (FL - 3, 1))):
    for x in range(26, 47):
        put(x, y, z, stairs("quartz", "south"))
        fill(x, 0, z, x, y - 1, z, FOUND)

# ================================================================== 2. wings (3 locked rooms each) - frostbound shell
WEST = (6, 21)
EAST = (51, 66)
WZ = (8, 56)
ROOM_Z = ((11, 23), (26, 38), (41, 53))
for (x0, x1) in (WEST, EAST):
    fill(x0, FL, WZ[0], x1, 23, WZ[1], FROST)                  # floor y12 .. ceiling y22-23: one solid block of frostbound
# ================================================================== 3. main hall shell
fill(22, FL + 1, 8, 50, 32, 56, WALL)
# ================================================================== 4. towers (solid) and gate turrets
TOWERS = [(8, 10), (64, 10), (8, 54), (64, 54)]
for (tx, tz) in TOWERS:
    fill_keep(tx - 4, FL + 1, tz - 4, tx + 4, 38, tz + 4, TOWER)
    ring(tx - 4, tz - 4, tx + 4, tz + 4, 39, SB)
    fill(tx - 3, 39, tz - 3, tx + 3, 39, tz + 3, ROOF)
    crenellate(tx - 4, tz - 4, tx + 4, tz + 4, 40)
    top = cone(tx, tz, 5, 41)
    spire(tx, top + 1, tz, 4)
GATE_TOWERS = [(29, 5), (43, 5)]
for (tx, tz) in GATE_TOWERS:
    fill(tx - 2, FL + 1, tz - 2, tx + 2, 29, tz + 2, TOWER)
    ring(tx - 2, tz - 2, tx + 2, tz + 2, 30, SB)
    crenellate(tx - 2, tz - 2, tx + 2, tz + 2, 31)
    top = cone(tx, tz, 3, 32)
    spire(tx, top + 1, tz, 4)

# ================================================================== 5. roofs of wings and hall
for (x0, x1) in (WEST, EAST):
    fill(x0, 24, WZ[0], x1, 24, WZ[1], ROOF)
    crenellate(x0, WZ[0], x1, WZ[1], 25)
    for z in (WZ[0] + 4, 32, WZ[1] - 4):                      # snow-capped lanterns on the roof
        cx_ = (x0 + x1) // 2
        put(cx_, 25, z, SB)
        put(cx_, 26, z, "minecraft:end_rod[facing=up]")
fill(22, 31, 8, 50, 32, 56, ROOF)
crenellate(22, 8, 50, 56, 33)
# stepped crown pyramid over the middle of the hall
for i, half in enumerate((9, 7, 5, 3, 1)):
    y = 33 + i
    fill(CX - half, y, ARENA[1] - half, CX + half, y, ARENA[1] + half, BI if i % 2 else QB)
    ring(CX - half, ARENA[1] - half, CX + half, ARENA[1] + half, y, SQ if i % 2 == 0 else PI)
spire(CX, 38, ARENA[1], 7)

# ================================================================== 6. carve the interiors
HX0, HX1, TOP = 27, 45, 26      # main hall interior: 19 wide, 45 long, 14 high (floor y12, ceiling y27); the rest of the keep is solid wall
carve(HX0, FL + 1, 10, HX1, TOP, 54)                                   # main hall
for (ix0, ix1) in ((9, 18), (54, 63)):
    for (z0, z1) in ROOM_Z:
        carve(ix0, FL + 1, z0, ix1, 21, z1)                            # the six locked rooms

# ================================================================== 7. main hall: floor, arena, aisle, dais
for x in range(HX0, HX1 + 1):
    put(x, FL, 10, PI)
    for z in range(10, 55):
        if x in (HX0, HX1) or z in (10, 54):
            put(x, FL, z, BI)
# arena pattern around the seal
for x in range(HX0, HX1 + 1):
    for z in range(ARENA[1] - 9, ARENA[1] + 10):
        dx, dz = x - ARENA[0], z - ARENA[1]
        r = math.hypot(dx, dz)
        ang = math.degrees(math.atan2(dz, dx)) % 45
        spoke = min(ang, 45 - ang) < 7 and r <= 8.5
        b = None
        if r <= 1.6:
            b = SEAL if abs(dx) <= 1 and abs(dz) <= 1 else CQ
        elif r <= 2.7:
            b = CQ
        elif r <= 3.7:
            b = BI
        elif r <= 4.7:
            b = SQ
        elif r <= 5.7:
            b = PI
        elif r <= 6.6:
            b = BI
        elif r <= 7.6:
            b = CQ if (x + z) % 2 == 0 else QB
        elif spoke:
            b = CQ
        if b:
            put(x, FL, z, b)
# aisle carpet
for z in range(11, ARENA[1] - 8):
    for x in range(CX - 2, CX + 3):
        put(x, FL + 1, z, CARPET)
for z in range(ARENA[1] + 9, 49):
    for x in range(CX - 2, CX + 3):
        put(x, FL + 1, z, CARPET)
# dais (3 tiers) and ice throne at the back
fill(HX0, FL + 1, 49, HX1, FL + 1, 54, QB)
fill(29, FL + 2, 51, 43, FL + 2, 54, SQ)
fill(32, FL + 3, 53, 40, FL + 3, 54, QB)
for x in range(HX0, HX1 + 1):
    put(x, FL + 1, 48, stairs("quartz", "south"))
for x in range(29, 44):
    put(x, FL + 2, 50, stairs("quartz", "south"))
for x in range(32, 41):
    put(x, FL + 3, 52, stairs("quartz", "south"))
fill(CX - 2, FL + 4, 54, CX + 2, FL + 9, 54, BI)                       # throne back
fill(CX - 1, FL + 10, 54, CX + 1, FL + 11, 54, PI)
for x in (CX - 2, CX, CX + 2):
    put(x, FL + 10, 54, BI)
    put(x, FL + 11, 54, PI)
put(CX, FL + 12, 54, BI)
put(CX - 3, FL + 4, 54, stairs("quartz", "south"))
put(CX + 3, FL + 4, 54, stairs("quartz", "south"))
put(CX, FL + 4, 53, stairs("packed_ice" if False else "quartz", "north"))     # the seat (back on the north side)
for x in (CX - 3, CX + 3):                                              # arm rests
    put(x, FL + 4, 53, slab("quartz"))

# ================================================================== 8. main hall: pillars, ribs, chandeliers, windows
PILLAR_Z = (13, 19, 25, 31, 37, 43, 49)
for px in (29, 43):
    for pz in PILLAR_Z:
        for y in range(FL + 1, TOP - 1):
            put(px, y, pz, QP)
        put(px, FL + 1, pz, CQ)
        put(px, TOP - 1, pz, CQ)
        put(px, TOP, pz, BI)
for pz in PILLAR_Z:
    for x in range(HX0, HX1 + 1):
        put(x, TOP, pz, PI if x % 2 else BI)
    for x in (HX0, HX0 + 1, HX1 - 1, HX1):
        put(x, TOP - 1, pz, stairs("quartz", "east" if x < 36 else "west", "top"))
    # chandelier on the aisle
    for y in range(TOP - 4, TOP):
        put(CX, y, pz, "minecraft:chain[axis=y,waterlogged=false]")
    lantern(CX, TOP - 5, pz)
    lantern(CX - 2, TOP - 3, pz)
    lantern(CX + 2, TOP - 3, pz)
WIN_X = list(range(22, HX0)) + list(range(HX1 + 1, 51))                 # clerestory windows cut through the thick walls
for z in (16, 22, 28, 34, 40, 46, 52):
    for x in WIN_X:
        for y in range(TOP - 4, TOP):
            if y == TOP - 1:
                put(x, y, z, GLASS)
                continue
            for dz in (-1, 0, 1):
                put(x, y, z + dz, GLASS)
    for x in WIN_X:
        for dz in (-1, 1):
            put(x, TOP - 1, z + dz, WALL)
# ceiling lanterns in a line of sea lanterns between the ribs
for z in (16, 22, 28, 34, 40, 46, 52):
    put(CX, TOP, z, SEA)

# ================================================================== 9. the gate (south wall z=8..9, open)
carve(32, FL + 1, 8, 40, 21, 9)
carve(33, 22, 8, 39, 22, 9)
carve(34, 23, 8, 38, 23, 9)
carve(35, 24, 8, 37, 24, 9)
for y in range(FL + 1, 25):
    for z in (8, 9):
        put(31, y, z, QP if y % 4 else CQ)
        put(41, y, z, QP if y % 4 else CQ)
for x in range(31, 42):
    put(x, 25, 8, CQ)
    put(x, 25, 9, CQ)
for x, y in ((32, 22), (33, 23), (34, 24), (40, 22), (39, 23), (38, 24)):
    put(x, y, 8, BI)
lantern(34, 21, 9)
lantern(38, 21, 9)
# rose window above the gate (glass with quartz spokes), cut through the 2 thick wall
for x in range(CX - 4, CX + 5):
    for y in range(24, 33):
        dx, dy = x - CX, y - 28
        r = math.hypot(dx, dy)
        if r <= 3.6 and y >= 26:
            for z in (8, 9):
                spoke = (abs(dx) <= 0 or abs(dy) <= 0 or abs(abs(dx) - abs(dy)) <= 0) and r > 1
                put(x, y, z, QB if (r > 3.0 or spoke) else GLASS)
    # (rows y<26 are the arch trim / lintel)

# ================================================================== 10. exterior details
# string courses and pilasters on the long fronts
for (x0, x1) in (WEST, EAST):
    for z in range(WZ[0], WZ[1] + 1):
        outer = x0 if x0 == 6 else x1
        for y in range(FL + 1, 24):
            put(outer, y, z, WALL)            # outer skin of the wing (the unbreakable layers lie behind it)
    for x in range(x0, x1 + 1):
        for z in (WZ[0], WZ[1]):
            for y in range(FL + 1, 24):
                put(x, y, z, WALL)
    # pilasters + glowing windows on the outer side and on the front / back
    for z in range(WZ[0] + 2, WZ[1], 6):
        outer = x0 if x0 == 6 else x1
        sign = 1 if outer == x0 else -1
        for y in range(FL + 1, 24):
            put(outer, y, z, QP if y not in (FL + 1, 23) else CQ)
        for off in (-3, 3):
            zz = z + off
            if WZ[0] + 1 < zz < WZ[1] - 1:
                for dy in range(4):
                    put(outer, 16 + dy, zz, GLASS)
                    put(outer + sign, 16 + dy, zz, SEA)
    for x in range(x0, x1 + 1):
        put(x, 23, WZ[0], PI)
        put(x, 23, WZ[1], PI)
        put(x, 17, WZ[0], PI)
        put(x, 17, WZ[1], PI)
    outer = x0 if x0 == 6 else x1
    for z in range(WZ[0], WZ[1] + 1):
        put(outer, 17, z, PI)
        put(outer, 23, z, PI)
# tower windows and rings (only on the faces that look outside, never into the locked wings)
for (tx, tz) in TOWERS:
    west = tx < CX
    front = tz < 32
    for y in (18, 27, 34):
        window_slit(tx - 4 if west else tx + 4, y, tz, "x", -1 if west else 1)
        window_slit(tx, y, tz - 4 if front else tz + 4, "z", -1 if front else 1)
    for y in (24, 31, 38):
        ring(tx - 4, tz - 4, tx + 4, tz + 4, y, PI if y != 38 else BI)
for (tx, tz) in GATE_TOWERS:
    for y in (18, 25):
        window_slit(tx, y, tz - 2, "z", -1)
        window_slit(tx - 2, y, tz, "x", -1)
        window_slit(tx + 2, y, tz, "x", 1)
    for y in (22, 29):
        ring(tx - 2, tz - 2, tx + 2, tz + 2, y, PI)
# hall roof: icy crown on the four corners of the parapet
for x, z in ((22, 8), (50, 8), (22, 56), (50, 56)):
    for y in range(34, 37):
        put(x, y, z, QP if y < 36 else BI)
    spire(x, 37, z, 3)

# ================================================================== 11. NBT writer
class Int(int):
    pass


class Str(str):
    pass


class Lst(list):
    def __init__(self, items, elem):
        super().__init__(items)
        self.elem = elem


# ================================================================== 11b. hidden gates + loot chests of the six locked rooms
# Every room is plugged by a 3x3 doorway of GATE blocks (same look as the frostbound bricks, unbreakable) through the
# 5-thick wall between room and hall. They open when the boss dies. Each room holds one loot chest and a lantern.
CHESTS = {}
for (ix0, ix1, gx0, gx1, chest_x, face) in ((9, 18, 19, HX0 - 1, 10, "east"), (54, 63, HX1 + 1, 53, 62, "west")):
    for (z0, z1) in ROOM_Z:
        zc = (z0 + z1) // 2
        for x in range(gx0, gx1 + 1):
            for y in range(FL + 1, FL + 4):
                for z in range(zc - 1, zc + 2):
                    put(x, y, z, GATE)
        put(chest_x, FL + 1, zc, "minecraft:chest[facing=%s,type=single,waterlogged=false]" % face)
        CHESTS[(chest_x, FL + 1, zc)] = "elementalarsenal:chests/ice_castle"
        put((ix0 + ix1) // 2, 21, zc, "minecraft:soul_lantern[hanging=true]")

TAG = {"end": 0, "int": 3, "string": 8, "list": 9, "compound": 10}


def w_name(s):
    b = s.encode("utf-8")
    return struct.pack(">H", len(b)) + b


def kind(v):
    if isinstance(v, Int):
        return TAG["int"]
    if isinstance(v, Str):
        return TAG["string"]
    if isinstance(v, Lst):
        return TAG["list"]
    if isinstance(v, dict):
        return TAG["compound"]
    raise TypeError(type(v))


def payload(v):
    if isinstance(v, Int):
        return struct.pack(">i", int(v))
    if isinstance(v, Str):
        return w_name(str(v))
    if isinstance(v, Lst):
        out = struct.pack(">bi", v.elem, len(v))
        return out + b"".join(payload(i) for i in v)
    if isinstance(v, dict):
        out = b""
        for k, val in v.items():
            out += struct.pack(">b", kind(val)) + w_name(k) + payload(val)
        return out + b"\x00"
    raise TypeError(type(v))


def parse_state(s):
    if "[" not in s:
        return s, {}
    name, rest = s.split("[", 1)
    props = dict(p.split("=") for p in rest.rstrip("]").split(","))
    return name, props


palette, index = [], {}
blocks = []
for (x, y, z), b in sorted(G.items()):
    if b not in index:
        index[b] = len(palette)
        name, props = parse_state(b)
        entry = {"Name": Str(name)}
        if props:
            entry["Properties"] = {k: Str(v) for k, v in props.items()}
        palette.append(entry)
    entry_b = {"pos": Lst([Int(x), Int(y), Int(z)], TAG["int"]), "state": Int(index[b])}
    if (x, y, z) in CHESTS:
        entry_b["nbt"] = {"id": Str("minecraft:chest"), "LootTable": Str(CHESTS[(x, y, z)])}
    blocks.append(entry_b)

root = {
    "DataVersion": Int(4671),
    "size": Lst([Int(W), Int(H), Int(D)], TAG["int"]),
    "palette": Lst(palette, TAG["compound"]),
    "blocks": Lst(blocks, TAG["compound"]),
    "entities": Lst([], TAG["compound"]),
}
data = struct.pack(">b", TAG["compound"]) + w_name("") + payload(root)
with gzip.GzipFile(OUT, "wb", mtime=0) as f:
    f.write(data)
print("blocks:", len(blocks), "palette:", len(palette), "seal:", sum(1 for b in G.values() if b == SEAL),
      "frostbound:", sum(1 for b in G.values() if b == FROST))

# ================================================================== 12. self check: every locked room is sealed
def solid_unbreakable(p):
    return G.get(p) in (FROST, GATE)


def check_rooms():
    bad = 0
    for (ix0, ix1) in ((9, 18), (54, 63)):
        for (z0, z1) in ROOM_Z:
            for x in range(ix0 - 1, ix1 + 2):
                for y in range(FL, 23):
                    for z in range(z0 - 1, z1 + 2):
                        inside = ix0 <= x <= ix1 and FL + 1 <= y <= 21 and z0 <= z <= z1
                        if inside:
                            if G.get((x, y, z), AIR) not in (AIR,) and not G[(x, y, z)].startswith(("minecraft:chest", "minecraft:soul_lantern")):
                                bad += 1
                            continue
                        # the cell is touching the room by a face -> must be unbreakable
                        for dx, dy, dz in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
                            q = (x + dx, y + dy, z + dz)
                            if ix0 <= q[0] <= ix1 and FL + 1 <= q[1] <= 21 and z0 <= q[2] <= z1:
                                if not solid_unbreakable((x, y, z)):
                                    bad += 1
                                break
    return bad


print("room shell holes:", check_rooms())

# ================================================================== 13. preview (isometric)
if PREVIEW:
    from PIL import Image, ImageDraw
    COL = {
        "stone_bricks": (122, 124, 132), "cracked_stone_bricks": (114, 116, 124), "packed_ice": (140, 180, 240),
        "snow_block": (240, 248, 252), "polished_diorite": (196, 198, 200), "quartz_block": (236, 232, 224),
        "quartz_bricks": (230, 226, 218), "smooth_quartz": (238, 234, 226), "chiseled_quartz_block": (232, 228, 220),
        "quartz_pillar": (234, 230, 222), "quartz": (232, 228, 220), "blue_ice": (90, 150, 240),
        "prismarine_bricks": (96, 170, 160), "prismarine_brick": (96, 170, 160), "dark_prismarine": (50, 90, 80),
        "sea_lantern": (190, 240, 240), "light_blue_stained_glass": (120, 190, 250), "light_blue_carpet": (100, 170, 230),
        "stone": (120, 120, 124), "cobblestone": (110, 110, 112), "andesite": (130, 132, 134),
        "frostbound_bricks": (60, 84, 150), "frostbound_gate": (60, 84, 150), "chest": (170, 120, 50), "soul_lantern": (90, 200, 230), "glacial_seal": (80, 240, 255), "end_rod": (255, 255, 255),
        "soul_lantern": (90, 200, 230), "chain": (60, 64, 80),
    }

    def base(b):
        return b.split("[")[0]

    def color(b):
        n = base(b).split(":")[1]
        if n.endswith("_stairs") or n.endswith("_slab"):
            n = n.rsplit("_", 1)[0]
        return COL.get(n, (140, 140, 150))

    def render(path, keep, s=6):
        im = Image.new("RGB", (int((W + D) * s * 0.87) + 40, int((W + D) * s * 0.5 + H * s) + 40), (22, 30, 48))
        dr = ImageDraw.Draw(im)
        ox, oy = D * s * 0.87 + 20, H * s + 20
        order = sorted((p for p in G if G[p] != AIR and keep(p)), key=lambda p: (p[0] + p[2], p[1]))
        occ = set(order)

        def sc(x, y, z):
            return (ox + (x - z) * s * 0.87, oy + (x + z) * s * 0.5 - y * s)
        for (x, y, z) in order:
            if (x + 1, y, z) in occ and (x, y + 1, z) in occ and (x, y, z + 1) in occ:
                continue
            c = color(G[(x, y, z)])
            top = [sc(x, y + 1, z), sc(x + 1, y + 1, z), sc(x + 1, y + 1, z + 1), sc(x, y + 1, z + 1)]
            left = [sc(x, y + 1, z + 1), sc(x + 1, y + 1, z + 1), sc(x + 1, y, z + 1), sc(x, y, z + 1)]
            right = [sc(x + 1, y + 1, z), sc(x + 1, y + 1, z + 1), sc(x + 1, y, z + 1), sc(x + 1, y, z)]
            dr.polygon(top, fill=tuple(min(255, int(v * 1.12)) for v in c))
            dr.polygon(left, fill=tuple(int(v * 0.82) for v in c))
            dr.polygon(right, fill=tuple(int(v * 0.62) for v in c))
        im.save(path)
    render(PREVIEW + "_outside.png", lambda p: True)
    render(PREVIEW + "_cutaway.png", lambda p: not (p[0] > 36 and p[1] > FL) )
